#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int maxn = 100000 + 5;

int n, k, m, f[maxn];
vector< pair<int, int> > p;
vector<int> ret;
bool v[maxn];

bool check()
{
    for (int i = 1, j = 0; i <= n; ++i) {
        if (!v[i])
            j = i;
        f[i] = j;
    }
    int _k = 0, i = 0;
    while (i < p.size()) {
        ++_k;
        int t = f[p[i].second];
        if (t < p[i].first)
            return false;
        while (i < p.size() && p[i].first <= t)
            ++i;
    }
    return _k <= k;
}

int main()
{
    //freopen("guard0.in", "r", stdin);
    //freopen("guard.out", "w", stdout);
    
    cin >> n >> k >> m;
    for (int i = 1; i <= m; ++i) {
        int a, b, c;
        cin >> a >> b >> c;
        if (c == 0)
            for (int j = a; j <= b; ++j)
                v[j] = true;
        else
            p.push_back(make_pair(a, b));
    }
    
    sort(p.begin(), p.end());
    int t = 0;
    for (int i = 0; i < p.size(); ++i) {
        while (t && p[i].second < p[t - 1].second)
            --t;
        p[t++] = p[i];
    }
    while (p.size() > t)
        p.pop_back();
    int _n = 0;
    for (int i = 1; i <= n; ++i)
        if (!v[i])
            ++_n;
    if (_n == k) {
        for (int i = 1; i <= n; ++i)
            if (!v[i])
                ret.push_back(i);
    }else
        for (int i = 1; i <= n; ++i)
            if (!v[i]) {
                v[i] = true;
                if (!check())
                    ret.push_back(i);
                v[i] = false;
            }
    if (ret.empty())
        cout << "-1" << endl;
    else
        for (int i = 0; i < ret.size(); ++i)
            cout << ret[i] << endl;
    //cerr << clock() << endl;
    
    return 0;
}

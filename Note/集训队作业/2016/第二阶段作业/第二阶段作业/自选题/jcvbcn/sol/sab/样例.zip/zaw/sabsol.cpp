#include "sabotaz.h"
#include "message.h"

#include <algorithm>
#include <iostream>

using namespace std;

int main() {

  long long N = NumberOfIsles();
  long long M = NumberOfBridges();
  
  long long res = 0;
  for(int i=0; i<M; i++) if(BridgeEndA(i) != BridgeEndB(i)) res++;
 
  if (MyNodeId() == 0) { 
    cout << res << endl;
  }
  return 0;
}

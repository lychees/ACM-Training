package main

const testerPath = "zeus\\tester.exe"
const hangerPath = "zeus\\hanger.exe"

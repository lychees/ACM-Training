#include "sabotaz.h"
#include "message.h"

#include <stdio.h>

int main(void) {

  long long N = NumberOfIsles();
  long long M = NumberOfBridges();
  
  long long res = 0;
  int i;
  for(i=0; i<M; i++) if(BridgeEndA(i) != BridgeEndB(i)) res++;
 
  if (MyNodeId() == 0) {
    printf("%lld\n", res);
  }
  return 0;
}

// +build darwin dragonfly freebsd linux netbsd openbsd solaris

package main

const testerPath = "zeus/tester"
const hangerPath = "zeus/hanger"

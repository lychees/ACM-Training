#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#include <set>
#define REP(i,n) for (int i=1;i<=(n);++i)
#define FOR(i,a,b) for (int i=(a);i<=(b);++i)
#define ROF(i,a,b) for (int i=(a);i>=(b);--i)
#define FEC(p,u) for (edge*p=head[u];p;p=p->nxt)
using namespace std;
typedef long long LL;
void read(int &x){
	char ch = getchar(); while (ch < '0' || ch > '9') ch = getchar();
	for (x = 0; ch >= '0' && ch <= '9'; ch = getchar()) x = x*10+ch-48;
}
int P(1000000007);
int Pow(LL x, int y){
	LL ret(1);
	for (; y; y >>= 1){
		if (y&1) ret = ret*x%P;
		x = x*x%P;
	}
	return ret;
}

int prm[11000], lp, mpf[11000];
LL fp[11000][30], pp[11000][30]; //fp=(a+1)p^a

int n, m, lq, a[2100000], b[2100000];

int cnt[11000][30], he[11000];
multiset<int> S;
LL sum, lcm, lcd;

struct node{
	node *c[2], *f;
	int size, v;
	int ctp(){ return this == f->c[1]; }
	void pushup(){ size = c[0]->size+c[1]->size+v; }
}T[2100000], *null, *rt;
void Build(int L, int R, node *&x){
	int u(L+R>>1);
	x = T+u;
	if (L < u) Build(L, u-1, x->c[0]); x->c[0]->f = x;
	if (R > u) Build(u+1, R, x->c[1]); x->c[1]->f = x;
	x->pushup();
}
void Rotate(node *u){
	node *v(u->f), *w(v->f);
	int d(u->ctp());
	v->c[d] = u->c[!d], v->c[d]->f = v;
	w->c[v->ctp()] = u, u->f = w;
	u->c[!d] = v, v->f = u;
	v->pushup(); u->pushup();
}
void Splay(node *x, node *to){
	int d;
	while (x->f != to){
		if (x->f->f == to) Rotate(x);
		else if (x->ctp() == x->f->ctp()) Rotate(x->f), Rotate(x);
		else Rotate(x), Rotate(x);
	}
}

void Insert(int x){
	LL t(Pow(x, P-2));
	REP(i,lp) if (x%prm[i] == 0){
		int q(0);
		while (x%prm[i] == 0){ x /= prm[i]; ++q; }
		++cnt[i][q];
		t = t*fp[i][q]%P;
		if (q > he[i]){
			lcm = lcm*pp[i][q-he[i]]%P;
			he[i] = q;
		}
		if (x == 1) break;
	}
	if (x != 1){
		t = t*(2*x-1)%P;
		if (S.find(x) == S.end()) lcm = lcm*x%P;
		S.insert(x);
	}
	sum = (sum+t)%P;
}
void Erase(int x){
	LL t(Pow(x, P-2));
	REP(i,lp) if (x%prm[i] == 0){
		int q(0);
		while (x%prm[i] == 0){ x /= prm[i]; ++q; }
		--cnt[i][q];
		t = t*fp[i][q]%P;
		if (!cnt[i][he[i]]){
			q = he[i]-1; while (q && !cnt[i][q]) --q;
			lcd = lcd*pp[i][he[i]-q]%P;
			he[i] = q;
		}
		if (x == 1) break;
	}
	if (x != 1){
		set<int>::iterator it = S.find(x);
		S.erase(it);
		t = t*(2*x-1)%P;
		if (S.find(x) == S.end()) lcd = lcd*x%P;
	}
	sum = (sum-t+P)%P;
}

void prepro(){
	int maxn = 10000;
	FOR(i,2,maxn){
		if (!mpf[i]){
			prm[++lp] = i;
			mpf[i] = lp;
		}
		REP(j,lp){
			if (i*prm[j] > maxn) break;
			mpf[i*prm[j]] = j;
			if (mpf[i] == j) break;
		}
	}
	REP(i,lp){
		pp[i][0] = 1;
		FOR(j,0,27) pp[i][j+1] = pp[i][j]*prm[i]%P;
		FOR(j,0,28) fp[i][j] = pp[i][j]*(j+1)%P;
		ROF(j,28,1) fp[i][j] = (fp[i][j]-fp[i][j-1]+P)%P; fp[i][0] = 0;
	}
}
void init(){
	scanf("%d%d", &n, &lq);
	m = 2*lq+1;
	REP(i,2*lq){ read(a[i]); b[i] = a[i]; }
	b[m] = 1;
	sort(b+1, b+m+1);
	m = unique(b+1, b+m+1)-b-1;
	b[m+1] = n+1;
	null = T;
	FOR(i,0,m) T[i].c[0] = T[i].c[1] = T[i].f = null, T[i].v = b[i+1]-b[i], T[i].size = 0;
	null->v = 0;
	sum = 0; lcm = lcd = 1;
	Build(1, m, rt);
	Insert(n);
}
void work(int x, int y){
	node *u(T+(lower_bound(b+1, b+m+1, x)-b)), *v(T+(lower_bound(b+1, b+m+1, y)-b));
	Splay(u, null); Splay(v, null);
	if (u->f == null){ // merge
		Erase(u->size); Erase(v->size);
		if (v->c[0] != null){
			node *w = v->c[0];
			while (w->c[0] != null) w = w->c[0];
			Splay(w, v);
			w->f = null; v->c[0] = null;
			w->c[0] = v; v->f = w;
			v->pushup(); w->pushup();
			v = w;
		}
		if (u->c[0] != null){
			node *w = u->c[0];
			while (w->c[1] != null) w = w->c[1];
			Splay(w, u);
			w->c[1] = v; v->f = w;
			w->pushup(); u->pushup();
		}else{
			u->c[0] = v; v->f = u;
			u->pushup();
		}
		Insert(u->size);
	}else{ // split
		Erase(v->size);
		node *w = u; while (w->f != v) w = w->f;
		if (w == v->c[1]){
			swap(u, v); Splay(v, null);
		}
		Splay(u, v);
		if (u->c[0] != null){
			w = u->c[0];
			while (w->c[1] != null) w = w->c[1];
			Splay(w, v);
			w->c[1] = null; u->f = null;
			w->pushup(); v->pushup();
		}else{
			v->c[0] = null; u->f = null;
			v->pushup();
		}
		Insert(u->size); Insert(v->size);
	}
	printf("%lld\n", sum*lcm%P*Pow(lcd, P-2)%P);
}
int main(){
	freopen("1.in", "r", stdin);
	freopen("2.out", "w", stdout);
	prepro();
	init();
	REP(i,lq){
		work(a[i*2-1], a[i*2]);
	}
	return 0;
}


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#include <set>
#include <vector>
#define REP(i,n) for (int i=1;i<=(n);++i)
#define FOR(i,a,b) for (int i=(a);i<=(b);++i)
#define ROF(i,a,b) for (int i=(a);i>=(b);--i)
#define FEC(p,u) for (edge*p=head[u];p;p=p->nxt)
#define rep(i,a,b) for (int i=(a);i<=(b);++i)
#define pb push_back
using namespace std;
typedef long long LL;
void read(int &x){
	char ch = getchar(); while (ch < '0' || ch > '9') ch = getchar();
	for (x = 0; ch >= '0' && ch <= '9'; ch = getchar()) x = x*10+ch-48;
}
int P(1000000007);
int Pow(LL x, int y, int mo = P){
	LL ret(1);
	for (; y; y >>= 1){
		if (y&1) ret = ret*x%mo;
		x = x*x%mo;
	}
	return ret;
}

int prm[110000], lp, mpf[110000];

namespace Factor {
	const int N=1100000;
	LL C,fac[10010],n,mut,a[1001000];
	int T,cnt,i,l,prime[N],p[N],psize,_cnt;
	LL _e[100],_pr[100];
	vector<LL> d;
	inline LL mul(LL a,LL b,LL p) {
		if (p<=1000000000) return a*b%p;
		else if (p<=1000000000000LL) return (((a*(b>>20)%p)<<20)+(a*(b&((1<<20)-1))))%p;
		else {
			LL d=(LL)floor(a*(long double)b/p+0.5);
			LL ret=(a*b-d*p)%p;
			if (ret<0) ret+=p;
			return ret;
		}
	}
	void prime_table(){
		int i,j,tot,t1;
		for (i=1;i<=psize;i++) p[i]=i;
		for (i=2,tot=0;i<=psize;i++){
			if (p[i]==i) prime[++tot]=i;
			for (j=1;j<=tot && (t1=prime[j]*i)<=psize;j++){
				p[t1]=prime[j];
				if (i%prime[j]==0) break;
			}
		}
	}
	void init(int ps) {
		psize=ps;
		prime_table();
	}
	LL powl(LL a,LL n,LL p) {
		LL ans=1;
		for (;n;n>>=1) {
			if (n&1) ans=mul(ans,a,p);
			a=mul(a,a,p);
		}
		return ans;
	}
	bool witness(LL a,LL n) {
		int t=0;
		LL u=n-1;
		for (;~u&1;u>>=1) t++;
		LL x=powl(a,u,n),_x=0;
		for (;t;t--) {
			_x=mul(x,x,n);
			if (_x==1 && x!=1 && x!=n-1) return 1;
			x=_x;
		}
		return _x!=1;
	}
	bool miller(LL n) {
		if (n<=psize) return p[n]==n;
		if (~n&1) return 0;
		for (int j=0;j<=7;j++) if (witness(rand()%(n-1)+1,n)) return 0;
		return 1;
	}
	LL gcd(LL a,LL b) {
		LL ret=1;
		while (a!=0) {
			if ((~a&1) && (~b&1)) ret<<=1,a>>=1,b>>=1;
			else if (~a&1) a>>=1; else if (~b&1) b>>=1;
			else {
				if (a<b) swap(a,b);
				a-=b;
			}
		}
		return ret*b;
	}
	LL rho(LL n) {
		for (;;) {
			LL X=rand()%n,Y,Z,T=1,*lY=a,*lX=lY;
			int tmp=20;
			C=rand()%10+3;
			X=mul(X,X,n)+C;*(lY++)=X;lX++;
			Y=mul(X,X,n)+C;*(lY++)=Y;
			for(;X!=Y;) {
				LL t=X-Y+n;
				Z=mul(T,t,n);
				if(Z==0) return gcd(T,n);
				tmp--;
				if (tmp==0) {
					tmp=20;
					Z=gcd(Z,n);
					if (Z!=1 && Z!=n) return Z;
				}
				T=Z;
				Y=*(lY++)=mul(Y,Y,n)+C;
				Y=*(lY++)=mul(Y,Y,n)+C;
				X=*(lX++);
			}
		}
	}
	void _factor(LL n) {
		for (int i=0;i<cnt;i++) {
			if (n%fac[i]==0) n/=fac[i],fac[cnt++]=fac[i];}
		if (n<=psize) {
			for (;n!=1;n/=p[n]) fac[cnt++]=p[n];
			return;
		}
		if (miller(n)) fac[cnt++]=n;
		else {
			LL x=rho(n);
			_factor(x);_factor(n/x);
		}
	}
	void dfs(LL x,int dep) {
		if (dep==_cnt) d.pb(x);
		else {
			dfs(x,dep+1);
			for (int i=1;i<=_e[dep];i++) dfs(x*=_pr[dep],dep+1);
		}
	}
	void norm() {
		sort(fac,fac+cnt);
		_cnt=0;
		rep(i,0,cnt) if (i==0||fac[i]!=fac[i-1]) _pr[_cnt]=fac[i],_e[_cnt++]=1;
			else _e[_cnt-1]++;
	}
	void factor(LL n) {
		cnt=0;
		_factor(n);
		sort(fac,fac+cnt);
		cnt = unique(fac, fac+cnt)-fac;
	}
}

LL pp[110000][30], fp[110000][30]; //(a+1)p^a

int n, m, lq, a[2100000], b[2100000];

int cnt[110000][30], he[110000];
multiset<int> S;
LL sum, lcm, lcd;

struct node{
	node *c[2], *f;
	int size, v;
	int ctp(){ return this == f->c[1]; }
	void pushup(){ size = c[0]->size+c[1]->size+v; }
}T[2100000], *null, *rt;
void Build(int L, int R, node *&x){
	int u(L+R>>1);
	x = T+u;
	if (L < u) Build(L, u-1, x->c[0]); x->c[0]->f = x;
	if (R > u) Build(u+1, R, x->c[1]); x->c[1]->f = x;
	x->pushup();
}
void Rotate(node *u){
	node *v(u->f), *w(v->f);
	int d(u->ctp());
	v->c[d] = u->c[!d], v->c[d]->f = v;
	w->c[v->ctp()] = u, u->f = w;
	u->c[!d] = v, v->f = u;
	v->pushup(); u->pushup();
}
void Splay(node *x, node *to){
	int d;
	while (x->f != to){
		if (x->f->f == to) Rotate(x);
		else if (x->ctp() == x->f->ctp()) Rotate(x->f), Rotate(x);
		else Rotate(x), Rotate(x);
	}
}

void Insert(int x){
	LL t(Pow(x, P-2));
	Factor::factor(x);
	FOR(i,0,Factor::cnt-1){
		int p(Factor::fac[i]), q(0);
		while (x%p == 0){ x /= p; ++q; }
		if (p <= 100000){
			++cnt[p][q];
			t = t*fp[p][q]%P;
			if (q > he[p]){
				lcm = lcm*pp[p][q-he[p]]%P;
				he[p] = q;
			}
		}else{
			t = t*(2*p-1)%P;
			if (S.find(p) == S.end()) lcm = lcm*p%P;
			S.insert(p);
		}
	}
	sum = (sum+t)%P;
}
void Erase(int x){
	LL t(Pow(x, P-2));
	Factor::factor(x);
	FOR(i,0,Factor::cnt-1){
		int p(Factor::fac[i]), q(0);
		while (x%p == 0){ x /= p; ++q; }
		if (p <= 100000){
			--cnt[p][q];
			t = t*fp[p][q]%P;
			if (!cnt[p][he[p]]){
				int q(he[p]-1); while (q && !cnt[p][q]) --q;
				lcd = lcd*pp[p][he[p]-q]%P;
				he[p] = q;
			}
		}else{
			t = t*(2*p-1)%P;
			set<int>::iterator it = S.find(p);
			S.erase(it);
			if (S.find(p) == S.end()) lcd = lcd*p%P;
		}
	}
	sum = (sum-t+P)%P;
}

void prepro(){
	int maxn = 100000;
	FOR(i,2,maxn){
		if (!mpf[i]){
			prm[++lp] = i;
			mpf[i] = i;
		}
		REP(j,lp){
			if (i*prm[j] > maxn) break;
			mpf[i*prm[j]] = prm[j];
			if (mpf[i] == prm[j]) break;
		}
	}
	REP(i,lp){
		int u = prm[i];
		pp[u][0] = 1;
		FOR(j,0,26) pp[u][j+1] = pp[u][j]*u%P;
		FOR(j,0,27) fp[u][j] = pp[u][j]*(j+1)%P;
		ROF(j,27,1) fp[u][j] = (fp[u][j]-fp[u][j-1]+P)%P; fp[u][0] = 0;
	}
}
void init(){
	Factor::init(500000);
	scanf("%d%d", &n, &lq);
	m = 2*lq+1;
	REP(i,2*lq){ read(a[i]); b[i] = a[i]; }
	b[m] = 1;
	sort(b+1, b+m+1);
	m = unique(b+1, b+m+1)-b-1;
	b[m+1] = n+1;
	null = T;
	FOR(i,0,m) T[i].c[0] = T[i].c[1] = T[i].f = null, T[i].v = b[i+1]-b[i], T[i].size = 0;
	null->v = 0;
	sum = 0; lcm = lcd = 1;
	Build(1, m, rt);
	Insert(n);
}
void work(int x, int y){
	node *u(T+(lower_bound(b+1, b+m+1, x)-b)), *v(T+(lower_bound(b+1, b+m+1, y)-b));
	Splay(u, null); Splay(v, null);
	if (u->f == null){ // merge
		Erase(u->size); Erase(v->size);
		if (v->c[0] != null){
			node *w = v->c[0];
			while (w->c[0] != null) w = w->c[0];
			Splay(w, v);
			w->f = null; v->c[0] = null;
			w->c[0] = v; v->f = w;
			v->pushup(); w->pushup();
			v = w;
		}
		if (u->c[0] != null){
			node *w = u->c[0];
			while (w->c[1] != null) w = w->c[1];
			Splay(w, u);
			w->c[1] = v; v->f = w;
			w->pushup(); u->pushup();
		}else{
			u->c[0] = v; v->f = u;
			u->pushup();
		}
		Insert(u->size);
	}else{ // split
		Erase(v->size);
		node *w = u; while (w->f != v) w = w->f;
		if (w == v->c[1]){
			swap(u, v); Splay(v, null);
		}
		Splay(u, v);
		if (u->c[0] != null){
			w = u->c[0];
			while (w->c[1] != null) w = w->c[1];
			Splay(w, v);
			w->c[1] = null; u->f = null;
			w->pushup(); v->pushup();
		}else{
			v->c[0] = null; u->f = null;
			v->pushup();
		}
		Insert(u->size); Insert(v->size);
	}
	printf("%lld\n", sum*lcm%P*Pow(lcd, P-2)%P);
}
int main(){
	freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
	prepro();
	init();
	REP(i,lq){
		work(a[i*2-1], a[i*2]);
	}
	return 0;
}


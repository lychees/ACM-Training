#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#include <map>
#define REP(i,n) for (int i=1;i<=(n);++i)
#define FOR(i,a,b) for (int i=(a);i<=(b);++i)
#define ROF(i,a,b) for (int i=(a);i>=(b);--i)
#define FEC(p,u) for (edge*p=head[u];p;p=p->nxt)
using namespace std;
typedef long long LL;
void read(int &x){
	char ch = getchar(); while (ch < '0' || ch > '9') ch = getchar();
	for (x = 0; ch >= '0' && ch <= '9'; ch = getchar()) x = x*10+ch-48;
}

int n, a[2000000], seq[110000];
LL ans;

struct edge{ int b; edge *nxt; }e[4000000], *le(e);
edge *head[2000000];
void add(int u, int v){ le->b = v, le->nxt = head[u], head[u] = le++; }
int size[2000000], sum[2000000];
int Rt, bel[2000000], nrt[2000000];

struct vset{
	LL ans;
	map<int, int> cnt[2000000];
	LL Query(int x){
		LL ret(0);
		int u(x), v(Rt);
		while (u != v){
			ret += cnt[v].find(a[v]-sum[u])->second-cnt[bel[u]].find(a[v]-sum[u])->second;
			v = nrt[bel[u]];
			u += n;
		}
		ret += cnt[v].find(a[v]-sum[u])->second;
		return ret;
	}
	void Insert(int x){
		ans += Query(x);
		int u(x), v(Rt);
		while (u != v){
			++cnt[v][sum[u]];
			++cnt[bel[u]][sum[u]];
			v = nrt[bel[u]];
			u += n;
		}
		++cnt[v][sum[u]];
	}
	void Erase(int x){
		int u(x), v(Rt);
		map<int, int>::iterator it;
		while (u != v){
			it = cnt[v].find(sum[u]);
			if (--it->second == 0) cnt[v].erase(it);
			it = cnt[bel[u]].find(sum[u]);
			if (--it->second == 0) cnt[bel[u]].erase(it);
			v = nrt[bel[u]];
			u += n;
		}
		it = cnt[v].find(sum[u]);
		if (--it->second == 0) cnt[v].erase(it);
		ans -= Query(x);
	}
}In, Out;

void init(){
	read(n);
	REP(i,n){
		read(a[i]);
		if (a[i] == 0) a[i] = -1;
		REP(j,18) a[i+j*n] = a[i];
	}
	REP(i,n-1){
		int u, v;
		read(u); read(v);
		add(u, v); add(v, u);
	}
	REP(i,n) read(seq[i]);
}

int ncur, cen, tcen;
void dfs1(int x, int pre){
	size[x] = 1;
	int t(0);
	FEC(p,x) if (p->b != pre){
		dfs1(p->b, x);
		size[x] += size[p->b];
		t = max(t, size[p->b]);
	}
	t = max(t, ncur-size[x]);
	if (t < tcen){ tcen = t; cen = x; }
}
void dfs2(int x, int pre, int B, int S){
	bel[x] = B; sum[x] = S+a[x];
	size[x] = 1;
	FEC(p,x) if (p->b != pre){
		add(x+n, p->b+n); add(p->b+n, x+n);
		dfs2(p->b, x, B, sum[x]);
		size[x] += size[p->b];
	}
}
void build(int x, int &rt){
	cen = 0; tcen = n; dfs1(x, 0);
	x = rt = cen;
	sum[x] = a[x]; size[x] = 1;
	FEC(p,x){
		dfs2(p->b, x, p->b, sum[x]);
		size[x] += size[p->b];
		ncur = size[p->b];
		build(p->b+n, nrt[p->b]);
	}
}

void work(){
	REP(i,n) Out.Insert(i);
	int r(0);
	REP(i,n){
		if (r < i) In.Insert(seq[++r]), Out.Erase(seq[r]);
		while (In.ans <= Out.ans && r < n){
			In.Insert(seq[++r]), Out.Erase(seq[r]);
		}
		if (In.ans <= Out.ans) break;
		ans += n-r+1;
		In.Erase(seq[i]), Out.Insert(seq[i]);
	}
	printf("%lld\n", ans);
}
int main(){
	init();
	ncur = n; build(1, Rt);
	work();
	return 0;
}


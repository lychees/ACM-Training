#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#define REP(i,n) for (int i=1;i<=(n);++i)
#define FOR(i,a,b) for (int i=(a);i<=(b);++i)
#define ROF(i,a,b) for (int i=(a);i>=(b);--i)
#define FEC(p,u) for (edge*p=head[u];p;p=p->nxt)
using namespace std;
typedef long long LL;
LL gcd(LL x, LL y){
	LL t;
	while (y){ t = x, x = y, y = t%y; }
	return x;
}

int n;
char tmp[20];

LL f[20][100], g[20][100], fs[20][100], gs[20][100];

void dp(LL x){
	f[0][0] = g[0][0] = 1;
	LL mi(1); int p;
	REP(i,n){
		p = x%10; x /= 10;
		FOR(j,0,54){
			f[i][j] = fs[i][j] = 0;
			FOR(t,0,9){
				int jj = i*2 > n ? j+t : j-t;
				if (0 <= jj && jj <= 54){
					f[i][j] += f[i-1][jj];
					fs[i][j] += fs[i-1][jj]+f[i-1][jj]*t*mi;
				}
			}
			g[i][j] = gs[i][j] = 0;
			FOR(t,0,p-1){
				int jj = i*2 > n ? j+t : j-t;
				if (0 <= jj && jj <= 54){
					g[i][j] += f[i-1][jj];
					gs[i][j] += fs[i-1][jj]+f[i-1][jj]*t*mi;
				}
			}
			int jj = i*2 > n ? j+p : j-p;
			if (0 <= jj && jj <= 54){
				g[i][j] += g[i-1][jj];
				gs[i][j] += gs[i-1][jj]+g[i-1][jj]*p*mi;
			}
		}
		mi *= 10;
	}
}
LL work(LL L, LL R){
	if (L > R) return 0;
	if (L == 0){ dp(R); return gs[n][0]+g[n][0]; }
	dp(R);
	LL ret = gs[n][0]-g[n][0]*(L-1);
	dp(L-1);
	ret -= gs[n][0]-g[n][0]*(L-1);
	return ret;
}
int main(){
	freopen("1.in", "r", stdin);
	int _; scanf("%d", &_); while (_--){
		LL L, R, k;
		scanf("%s", tmp);
		n = strlen(tmp);
		sscanf(tmp, "%lld", &L); scanf("%lld%lld", &R, &k);
		LL p = work(L, R+k-1)-work(R+1, R+k-1)-work(L+k, R+k-1), q = R-L+1, d = gcd(p, q);
		p /= d, q /= d;
		if (q > 1) printf("%lld/%lld\n", p, q); else printf("%lld\n", p);
	}
	return 0;
}


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>
#include <queue>
#define REP(i,n) for (int i=1;i<=(n);++i)
#define FOR(i,a,b) for (int i=(a);i<=(b);++i)
#define ROF(i,a,b) for (int i=(a);i>=(b);--i)
#define FEC(p,u) for (edge*p=head[u];p;p=p->nxt)
using namespace std;
typedef long long LL;
void read(int &x){
	char ch = getchar(); while (ch < '0' || ch > '9') ch = getchar();
	for (x = 0; ch >= '0' && ch <= '9'; ch = getchar()) x = x*10+ch-48;
}
LL inf = 1LL<<60;

int n, m, S, T;

struct edge{ int b; LL len; edge *nxt; }e[2000000], *le(e);
edge *head[410000];
void add(int u, int v, LL len){ le->b = v, le->len = len, le->nxt = head[u], head[u] = le++; }

LL a[410000];
vector<int> in[110000];
bool cpr(int x, int y){ return a[x] < a[y]; }

LL dis[1100000];
struct mypair{
	int x;
	LL d;
	mypair(){}
	mypair(int X, LL D){ x = X, d = D; }
};
bool operator<(mypair x, mypair y){ return x.d > y.d; }
priority_queue<mypair> H;

void init(){
	read(n); read(m); S = 0, T = m*2+1;
	int u, v, w;
	REP(i,m){
		read(u); read(v); read(w);
		a[i] = a[m+i] = w;
		add(i, m+i, w); add(m+i, i, w);
		in[u].push_back(i);
		in[v].push_back(m+i);
	}
	REP(i,n){
		sort(in[i].begin(), in[i].end(), cpr);
		int t(in[i].size()-2);
		FOR(j,0,t){
			add(in[i][j], in[i][j+1], 0);
			add(in[i][j+1], in[i][j], a[in[i][j+1]]-a[in[i][j]]);
		}
		if (i == 1) add(S, in[i][0], 0);
		if (i == n) add(in[i][0], T, a[in[i][0]]);
	}
}
void dijkstra(){
	FOR(i,S,T) dis[i] = inf;
	dis[S] = 0;
	H.push(mypair(S, 0));
	REP(h,T){
		if (H.empty()) break;
		mypair t = H.top(); H.pop();
		while (!H.empty() && t.d > dis[t.x]){ t = H.top(); H.pop(); }
		if (t.d > dis[t.x]) break;
		int u = t.x;
		FEC(p,u) if (dis[u]+p->len < dis[p->b]){
			dis[p->b] = dis[u]+p->len;
			H.push(mypair(p->b, dis[p->b]));
		}
	}
}
int main(){
	init();
	dijkstra();
	printf("%lld\n", dis[T]);
}

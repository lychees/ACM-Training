#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#define REP(i,n) for (int i=1;i<=(n);++i)
#define FOR(i,a,b) for (int i=(a);i<=(b);++i)
#define ROF(i,a,b) for (int i=(a);i>=(b);--i)
#define FEC(p,u) for (edge*p=head[u];p;p=p->nxt)
using namespace std;
typedef long long LL;
int mo(1000000007);
LL Pow(LL x, LL y){
	LL ret(1);
	for (; y; y >>= 1){
		if (y&1) ret = ret*x%mo;
		x = x*x%mo;
	}
	return ret;
}

int a1, a2, b1, b2, c;
LL P, Q;

int m, l[50];
LL ans[50];
int prm[35000000], fac[35000000], lp, cnt[35000000];
LL mul[35000000];
int afac[50], nxt[50];

void pretreat(){
	int maxn = 34000000;
	FOR(i,2,maxn){
		if (!fac[i]){ fac[i] = i; prm[++lp] = i; }
		for (int j = 1; j <= lp && i*prm[j] <= maxn; ++j){
			fac[i*prm[j]] = prm[j];
			if (fac[i] == prm[j]) break;
		}
	}
	mul[0] = 1; cnt[0] = 0;
	REP(i,maxn){ mul[i] = mul[i-1]*(i>36&&fac[i]==i ? i : 1)%mo; cnt[i] = cnt[i-1]+(fac[i]==i); }
	FOR(i,2,36){
		int t(i), p(fac[i]);
		afac[i] = 0;
		while (fac[t] == p){ t /= p, ++afac[i]; }
		nxt[i] = t;
	}
}
void work(int a, int b){
	LL rp(1), rq(1);
	for (m = 0; ; ++m){
		l[m] = ceil(pow((m+2.)/(m+1.), 1.*a/b));
		if (l[m] <= 2) break;
	}
	REP(i,36) ans[i] = 0;
	REP(i,m){
		LL k = 1LL*(cnt[l[i-1]-1]-cnt[l[i]-1])*a;
		if (!k) continue;
		for (int j = l[i]; j < l[i-1] && j <= 36; ++j) if (fac[j] == j) ans[j] -= i*b;
		for (int t = i+1; t != 1; t = nxt[t]) ans[fac[t]] += afac[t]*k;
		rq = rq*Pow(mul[l[i-1]-1]*Pow(mul[l[i]-1], mo-2)%mo, i*b)%mo;
	}
	REP(i,36) if (ans[i] > 0) rp = rp*Pow(i, ans[i])%mo; else if (ans[i] < 0) rq = rq*Pow(i, -ans[i])%mo;
	P += rp, Q += rq;
}
int main(){
	pretreat();
	int _; scanf("%d", &_); REP(casei, _){
		scanf("%d%d%d%d%d", &b1, &b2, &a1, &a2, &c);
		P = Q = 0;
		FOR(b,b1,b2) for (int a = a1; a <= a2 && a <= b*c; ++a) work(a, b);
		printf("Case #%d: %I64d %I64d\n", casei, P, Q);
	}
	return 0;
}


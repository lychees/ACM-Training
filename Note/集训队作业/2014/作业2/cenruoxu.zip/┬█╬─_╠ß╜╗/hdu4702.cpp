#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#define REP(i,n) for (int i=1;i<=(n);++i)
#define FOR(i,a,b) for (int i=(a);i<=(b);++i)
#define ROF(i,a,b) for (int i=(a);i>=(b);--i)
#define FEC(p,u) for (edge*p=head[u];p;p=p->nxt)
using namespace std;
typedef long long LL;
#define size 110

struct hugeint{
	int l, a[200];
	hugeint &operator*=(int y){
		REP(i,l) a[i] *= y;
		a[l+1] = 0;
		REP(i,l) a[i+1] += a[i]/10, a[i] %= 10;
		while (a[l+1]){ ++l; a[l+1] = a[l]/10, a[l] %= 10; }
	}
	void write(){ ROF(i,l,1) printf("%d", a[i]); printf("\n"); }
}ans;

int n;

struct permutation{
	int a[size];
	void read(){ REP(i,n) scanf("%d", &a[i]); }
	bool is1(){ REP(i,n) if (a[i] != i) return false; return true; }
};
permutation operator*(permutation x, permutation y){
	REP(i,n) x.a[i] = y.a[x.a[i]];
	return x;
}
permutation inv(permutation x){
	permutation ret;
	REP(i,n) ret.a[x.a[i]] = i;
	return ret;
}

int idx, m, ls[size], rid[size][size], lr[size], cs[size][size];
int b[size];
permutation s[size][size], r[size][size], rr[size][size];

int q[size];
bool vst[size][size];

void bfs(){
	int u(b[idx]), v, lq(0), rq(1);
	q[1] = u;
	REP(i,n) vst[idx][i] = false; vst[idx][u] = true;
	REP(i,n) r[idx][i].a[1] = 0;
	REP(i,n) r[idx][u].a[i] = rr[idx][u].a[i] = i;
	lr[idx] = 1, rid[idx][1] = u;
	cs[idx][1] = 1;
	permutation t;
	while (lq++ != rq){
		u = q[lq];
		REP(i,ls[idx]){
			t = r[idx][u]*s[idx][i];
			v = t.a[b[idx]];
			if (!vst[idx][v]){
				vst[idx][v] = true;
				q[++rq] = v;
				r[idx][v] = t;
				rr[idx][v] = inv(t);
				rid[idx][++lr[idx]] = v;
				cs[idx][lr[idx]] = 1;
			}
		}
	}
}
void add(){
	permutation t;
	int u, v, lq(0), rq(0);
	REP(i,n) if (vst[idx][i]) q[++rq] = i;
	while (lq++ != rq){
		u = q[lq];
		REP(i,ls[idx]){
			t = r[idx][u]*s[idx][i];
			v = t.a[b[idx]];
			if (!vst[idx][v]){
				vst[idx][v] = true;
				q[++rq] = v;
				r[idx][v] = t;
				rr[idx][v] = inv(t);
				rid[idx][++lr[idx]] = v;
				cs[idx][lr[idx]] = 1;
			}
		}
	}
}
permutation sift(permutation h){
	FOR(i,idx+1,m) if (h.a[b[i]] != b[i]){
		if (r[i][h.a[b[i]]].a[1] == 0) return h;
		h = h*rr[i][h.a[b[i]]];
	}
	return h;
}

void work(){
	REP(i,ls[1]) s[1][i].read();
	idx = m = 1;
	REP(i,ls[1]) REP(j,n) if (s[1][i].a[j] != j) b[1] = j;
	bfs();
	while (idx){
		permutation h;
		bool o(true);
		REP(i,lr[idx]){
			for (; cs[idx][i] <= ls[idx]; ++cs[idx][i]){
				int j(cs[idx][i]);
				h = r[idx][rid[idx][i]]*s[idx][j];
				h = h*rr[idx][h.a[b[idx]]];
				h = sift(h);
				if (!h.is1()){ o = false; break; }
			}
			if (!o) break;
		}
		if (o) --idx;
		else{
			if (++idx > m){
				++m;
				ls[idx] = 0, lr[idx] = 1, cs[idx][1] = 1;
				REP(j,n) if (h.a[j] != j) b[idx] = j;
				REP(i,n) vst[idx][i] = false; vst[idx][b[idx]] = true;
				REP(i,n) r[idx][i].a[1] = 0;
				REP(i,n) r[idx][b[idx]].a[i] = rr[idx][b[idx]].a[i] = i;
				rid[idx][1] = b[idx];
			}
			s[idx][++ls[idx]] = h;
			add();
		}
	}
	ans.a[1] = 1, ans.l = 1;
	REP(i,m) ans *= lr[i];
	ans.write();
}
int main(){
	freopen("1.in", "r", stdin);
	freopen("1.out", "w", stdout);
	while (scanf("%d%d", &n, &ls[1]) != EOF) work();
	return 0;
}


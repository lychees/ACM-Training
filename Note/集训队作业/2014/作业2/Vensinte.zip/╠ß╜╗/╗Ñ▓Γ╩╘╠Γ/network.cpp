#include <cstdio>
#include <cstdlib>
#include <algorithm>
#define son (k << 1)
#define mid ((l + r) >> 1)
const int inf = (int) 1e9 + 10;
using namespace std;

typedef int arr32[1000010];

arr32 c, next, g, e, ans, st, et, imt, dep, vis, cnt, pst, val, in, d, s, rk;
int n, m, ap = 1, id, p, a, b, dE, f[200010][20];

bool cmp(const int &a, const int &b)  {
	return s[a] < s[b];
}
void link(int x, int y, int t)  {
	c[++ap] = y, next[ap] = g[x], g[x] = ap;  e[ap] = t;
	c[++ap] = x, next[ap] = g[y], g[y] = ap;  e[ap] = t;
}
void dfs(int z, int ft, int d, int &id)  {
	for (int x = g[z]; x; x = next[x])
		if (c[x] != ft)  dfs(c[x], z, d + e[x], id);
	if (d > id)  id = d, a = z;
}
void dfs(int z, int ft, int d)  {
	st[z] = ++dE, dep[z] = d, in[dE] = z;
	f[z][0] = ft;
	for (int i = 0; i < 19; ++i)  f[z][i + 1] = f[f[z][i]][i];
	for (int x = g[z]; x; x = next[x])
		if (c[x] != ft)  dfs(c[x], z, d + e[x]);
	et[z] = dE;
}
int merge(int a, int b)  {
	return a  &&  b ? -1 : a | b;
}
void update(int k, int l, int r, int x, int y)  {
	if (l == r)  return (void) (imt[k] = y, cnt[k] = in[x]);
	if (x <= mid)  update(son, l, mid, x, y);
	else   update(son + 1, mid + 1, r, x, y);
	cnt[k] = merge(cnt[son], cnt[son + 1]);
	imt[k] = min(imt[son], imt[son + 1]);
}
void update(int k, int l, int r, int x, int y, int t)  {
	if (l > y  ||  r < x)  return;
	if (x <= l  &&  r <= y)  return (void) (pst[k] -= t, val[k] -= t);
	update(son, l, mid, x, y, t), update(son + 1, mid + 1, r, x, y, t);
	val[k] = max(val[son], val[son + 1]) + pst[k];
}
int ask()  {
	int k = 1, l = 1, r = n, s = 0;
	while (l != r)  {
		if (s += pst[k], val[son] > val[son + 1])  k = son, r = mid;
		else  k = son + 1, l = mid + 1;
	}
	return vis[in[l]] ? 0 : in[l];
}
int ask(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x)  return 0;
	if (x <= l  &&  r <= y)  return val[k];
	return max(ask(son, l, mid, x, y), ask(son + 1, mid + 1, r, x, y)) + pst[k];
}
int get(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x)  return 0;
	if (x <= l  &&  r <= y)  return cnt[k];
	return merge(get(son, l, mid, x, y), get(son + 1, mid + 1, r, x, y));
}
int Ask(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x)  return inf;
	if (x <= l  &&  r <= y)  return imt[k];
	return min(Ask(son, l, mid, x, y), Ask(son + 1, mid + 1, r, x, y));
}
void build(int k, int l, int r)  {
	imt[k] = inf, pst[k] = cnt[k] = 0;
	if (l == r)  return (void) (val[k] = dep[in[l]]);
	build(son, l, mid), build(son + 1, mid + 1, r);
	val[k] = max(val[son], val[son + 1]);
}
int fap(int z)  {
	for (int i = 20; i--; )
		if (f[z][i]  &&  !vis[f[z][i]])  z = f[z][i];
	return f[z][0];
}
void run(int rt)  {
	for (int i = 1; i <= n; ++i)  vis[i] = 0;
	dE = 0, dfs(rt, 0, 0), vis[rt] = 1, build(1, 1, n);
	
	int top = 1, res = 0;
	for (int i = 1; i <= n; ++i)  {
		int p = ask(), q = p;
		if (p == 0)  break;

		while (!vis[p])  {
			update(1, 1, n, st[p], et[p], dep[p] - dep[f[p][0]]);
			vis[p] = 1, p = f[p][0];
		}
		res += dep[q] - dep[p];
		
		int t = get(1, 1, n, st[p], et[p]);
		if (t >= 1)  update(1, 1, n, st[t], dep[t] - dep[p]);
		update(1, 1, n, st[q], dep[q] - dep[p]);
		
	  while (top <= m  &&  s[rk[top]] <= i + 1)  {
			int num = rk[top++], z = d[num];
		  if (vis[z])  {
				ans[num] = max(ans[num], res);
				continue;
			}
			int p = ask(1, 1, n, st[z], et[z]);  int h = fap(z);
		  int s = get(1, 1, n, st[h], et[h]);
			int r = Ask(1, 1, n, 1, n);
			if (s >= 1)  s = dep[s] - dep[h];  else  s = inf;
			ans[num] = max(ans[num], res - min(s, r) + p);
		}
	}
}
int main()  {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int x, y, z, tot = 0;
	
	scanf("%d %d", &n, &m);
	for (int i = 2; i <= n; ++i)  {
		scanf("%d %d %d", &x, &y, &z), link(x, y, z), tot += z;
	}
	for (int i = 1; i <= m; ++i)  {
		scanf("%d %d", d + i, s + i), s[i] <<= 1, rk[i] = i;
	}
	sort(rk + 1, rk + m + 1, cmp);
	
	dfs(1, 0, 0, id), run(a), b = a, id = 0;
	dfs(b, 0, 0, id), run(a);
	
	for (int i = 1; i <= m; ++i)  {
		if (ans[i] == 0)  printf("%d\n", tot);
		else  printf("%d\n", ans[i]);
	}
}

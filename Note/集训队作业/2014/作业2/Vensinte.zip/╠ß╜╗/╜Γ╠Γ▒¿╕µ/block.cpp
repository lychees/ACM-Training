#include <cstdio>
#include <cstdlib>
#include <algorithm>
#define son (k << 1)
#define mid ((l + r) >> 1)
const int inf = (int) 1e9 + 10, m = (int) 1e5;
using namespace std;

typedef int arr32[500010];

arr32 set, maxh, st, et, get, l, r, next;
int v, ap, d, h, cnt;

struct savet  {
	int st, et;
	void ins(int sd, int d, int h)  {
		if (d != sd)  l[et] = sd, r[et] = d, et = next[et] = ++ap;
		l[et] = d + h, r[et] = inf;
	}
	int manage(int d, int h)  {
		int ret = 0;
		for (int &i = st; i; i = next[i])  {
			if (l[i] <  d  &&  r[i] >  d + h)  return -1;
			if (l[i] >= d  &&  r[i] <= d + h)  ++cnt;
			if (l[i] <  d  &&  r[i] <= d + h  &&  r[i] > d)  ret = 1;
			if (r[i] >= d + h)  break;
		}
		return ret;
	}
	void init()  {
		st = et = ++ap, r[ap] = inf;
	}
} lef[200010], rig[200010];
void upd(int k, int l, int r, int x)  {
	set[k] = maxh[k] = x, st[k] = et[k] = get[k] = 0;
}
void merge(int k, int a, int b)  {
	maxh[k] = max(maxh[a], maxh[b]);  get[k] = 0;
	if (maxh[a] == maxh[k])  get[k] += get[a], st[k] = st[a];  else  st[k] = 1;
	if (maxh[b] == maxh[k])  get[k] += get[b], et[k] = et[b];  else  et[k] = 1;
	get[k] += (maxh[a] == maxh[b])  &&  (et[a]  ||  st[b]);
}
void push(int k, int l, int r)  {
	if (set[k])  upd(son, l, mid, set[k]), upd(son + 1, mid + 1, r, set[k]);
	set[k] = 0;
}
void update(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x)  return;
	if (x <= l  &&  r <= y)  {
		if (maxh[k] == d)  cnt += (v == 1  ||  (v == 0  &&  st[k] == 1)) + get[k], v = et[k];
		else  if (v >= 0)  v = 1;
		return upd(k, l, r, d + h);
	}
	push(k, l, r);
	update(son, l, mid, x, y), update(son + 1, mid + 1, r, x, y);
	merge(k, son, son + 1);
}
int ask(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x)  return 0;
	if (x <= l  &&  r <= y)  return maxh[k];
	push(k, l, r);
	int ret = max(ask(son, l, mid, x, y), ask(son + 1, mid + 1, r, x, y));
	return merge(k, son, son + 1), ret;
}
int ask(int k, int l, int r, int x)  {
	if (l == r)  return maxh[k];
	push(k, l, r);
	if (x <= mid)  return ask(son, l, mid, x);
	else   return ask(son + 1, mid + 1, r, x);
}
int main()  {
	for (int i = 0; i <= m; ++i)  lef[i].init(), rig[i].init();

	int n, l, r;
	
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)  {
		scanf("%d %d %d", &l, &r, &h);
		d = ask(1, 0, m, l, r - 1), v = rig[l].manage(d, h);
		int x = ask(1, 0, m, l), y = ask(1, 0, m, r - 1), endstat = lef[r].manage(d, h); 
		update(1, 0, m, l, r - 1);
		if ((v == 1  &&  endstat != -1)  ||  (v == 0  &&  endstat == 1))  ++cnt;
		printf("%d\n", cnt), cnt = 0;

		lef[l].ins(x, d, h), rig[r].ins(y, d, h);
	}
}

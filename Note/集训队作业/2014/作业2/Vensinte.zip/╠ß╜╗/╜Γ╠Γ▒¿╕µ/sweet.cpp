#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#define int64 long long
const int mod = (int) 1e9 + 7, k = 2000;
using namespace std;

typedef int arr32[1100010];

arr32 fra, inv, g, f, s;
int n, m, x;

void inc(int &a, const int &b)  {
	a += b;
	if (a < 0)  a += mod;
	if (a >= mod)  a -= mod;
}
int64 ex(int x, int y, int w)  {
	if ((w = (w % y + y) % y) % x == 0)  return w / x;
	return (ex(y % x, x, -w) * y + w) / x;
}
int C(int x, int y)  {
	return (int64) fra[x] * inv[x - y] % mod * inv[y] % mod; 
}
void prepare()  {
	fra[0] = f[0] = 1;
	for (int i = 1; i <= n + k; ++i)  fra[i] = (int64) fra[i - 1] * i % mod;
	inv[n + k] = ex(fra[n + k], mod, 1);
	for (int i = n + k; i >= 1; --i)  inv[i - 1] = (int64) inv[i] * i % mod;
}
int main()  {
	scanf("%d", &n), prepare();
	for (int i = 1; i <= n; ++i)  scanf("%d", &x), ++s[x];
	for (int i = 1; i <= k; ++i)  {
		if (s[i] == 0)  continue;
		for (int j = 0; j <= k; ++j)  g[j] = f[j], f[j] = 0;
		for (int j = 0; j <= s[i]; ++j)  {
			int64 sign = j & 1 ? -1 : 1;
			for (int p = 0; p <= k; ++p)
				if (p + (i + 1) * j > k)  break;
				else  inc(f[p + (i + 1) * j], sign * g[p] * C(s[i], j) % mod);
		}
	}
	for (int i = 0; i <= k; ++i)  s[i] = C(n + i - 1, i);

	scanf("%d", &m);
	for (int i = 1; i <= m; ++i)  {
		scanf("%d", &x);
		int ans = 0;
		for (int j = 0; j <= x; ++j)  inc(ans, (int64) f[j] * s[x - j] % mod);
		printf("%d\n", ans);
	}
}

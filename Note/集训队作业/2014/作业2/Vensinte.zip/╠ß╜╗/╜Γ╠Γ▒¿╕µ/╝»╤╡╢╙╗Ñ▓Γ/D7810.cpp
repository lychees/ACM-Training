#include <map>
#include <cmath>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <algorithm>
#define mid ((l + r) >> 1)
#define son (k << 1)
#define int64 long long
using namespace std;

typedef int arr32[1000010];

int *ask[50010];
double angel[200010];
arr32 c, next, g, run, vis, t, tot, type, msc, sv_ask, q, sv, sp, sz, ne, e, num, ct, nex, gt;
int n, m, cnt, ap = 1, dm = 1, id, start, sr;
vector <int> svt[200010];

struct ed  {
	int x, y;
} sve[200010];
struct point  {
	int x, y, d;
	void init()  {
		scanf("%d %d %d", &x, &y, &d);
	}
} p[50010];
int64 cx(const point &a, const point &b, const point &c)  {
	return (int64) (b.x - a.x) * (c.y - a.y) - (int64) (b.y - a.y) * (c.x - a.x);
}
struct compare  {
	bool operator () (const int &a, const int &b)  {
		return sve[a].x < sve[b].x  ||  sve[a].x == sve[b].x  &&  sve[a].y < sve[b].y;
	}
};
map <int, int, compare> T;

bool cmp_an(const int &a, const int &b)  {
	return angel[a] < angel[b];
}
bool cmp_pt(const int &a, const int &b)  {
	return vis[a] < vis[b];
}
int edge(int x, int y)  {
	if (x > y)  swap(x, y);
	sve[0] = (ed) {x, y};
	if (T.find(0) == T.end())  return sve[++sr] = *sve, T[sr] = ap + 1, 0;
	else  return T[0];
}
void link(int x, int y)  {
	if (edge(x, y))  return;
	c[++ap] = y, next[ap] = g[x], g[x] = ap;
	c[++ap] = x, next[ap] = g[y], g[y] = ap;
}
void Link(int x, int y, int t)  {
	ct[++dm] = y, nex[dm] = gt[x], gt[x] = dm;  e[dm] = t ^ 0;
	ct[++dm] = x, nex[dm] = gt[y], gt[y] = dm;  e[dm] = t ^ 1;
}
void sorted(int z)  {
	int tA = 0;
	for (int x = g[z]; x; x = next[x])  q[++tA] = x, angel[x] = atan2(p[c[x]].y - p[z].y, p[c[x]].x - p[z].x);
	sort(q + 1, q + tA + 1, cmp_an);
	for (int i = 1; i <= tA; ++i)  ne[q[i] ^ 1] = q[i % tA + 1];
}
void dfs(int z)  {
	num[z] = 1;
	int s = svt[z].size();
	for (int i = 0; i < s; ++i)  vis[svt[z][i]] = ++m; 
	for (int x = gt[z]; x; x = nex[x])
		if (!num[ct[x]])  {
			run[e[x ^ 0]] = ++m, dfs(ct[x]);
			run[e[x ^ 1]] = ++m;
		}
}
void update(int k, int l, int r, int x, int y)  {
	if (l == r)  return (void) (tot[k] += y, msc[k] += y);
	if (x <= mid)  update(son, l, mid, x, y);
	else   update(son + 1, mid + 1, r, x, y);
	tot[k] = tot[son] + tot[son + 1];
	msc[k] = max(msc[son], msc[son + 1]);
}
int asktot(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x  ||  x > y)  return 0;
	if (x <= l  &&  r <= y)  return tot[k];
	return asktot(son, l, mid, x, y) + asktot(son + 1, mid + 1, r, x, y);
}
int askdep(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x  ||  x > y)  return 0;
	if (x <= l  &&  r <= y)  return msc[k];
	return max(askdep(son, l, mid, x, y), askdep(son + 1, mid + 1, r, x, y));
}
int main()  {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int n, test, Q;
	
	scanf("%d", &test);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)  {
		p[i].init();
	}
	scanf("%d", &Q);
	for (int i = 1; i <= Q; ++i)  {
		char ch;
		while (scanf("%c", &ch), ch != 'H'  &&  ch != 'A');
		if (ch == 'H')  {
			type[i] = 1, ask[i] = sv_ask + id, id += 3;
			scanf("%d %d", ask[i], ask[i] + 1);
			continue;
		}
		
		scanf("%d", sz + i);
		ask[i] = sv_ask + id, id += sz[i] + 2;
		int *p = ask[i];
		for (int j = 1; j <= sz[i]; ++j)  scanf("%d", p + j);
	  p[0] = p[sz[i]];
		for (int j = 1; j <= sz[i]; ++j)  link(p[j], p[j - 1]);
	}
	for (int i = 1; i <= n; ++i)  sorted(i);
	for (int i = 2; i <= ap; ++i)  {
		if (t[i])  continue;

		int k = i, s = ++cnt;  int64 area = 0;
		while (!t[k])  t[k] = s, area += cx(p[c[i^1]], p[c[k^1]], p[c[k]]), k = ne[k];

		if (area > 0)  start = s;
	}
	for (int i = 1; i <= n; ++i)   svt[t[g[i]]].push_back(i);
	for (int i = 2; i <= ap; i += 2) Link(t[i], t[i ^ 1], i);
	dfs(start);
	for (int i = 1; i <= n; ++i)  update(1, 1, m, vis[i], p[i].d);
	for (int i = 1; i <= Q; ++i)  {
		if (type[i] == 1)  {
			update(1, 1, m, vis[*ask[i]], ask[i][1]), p[*ask[i]].d += ask[i][1];
			continue;
		}
		
		int *s = ask[i], id = 0, ip = 0;
		for (int j = 1; j <= sz[i]; ++j)  {
			int np = edge(s[j], s[j - 1]);
		  if (run[np])  sv[++id] = run[np], sv[++id] = run[np ^ 1];
			sp[++ip] = s[j];
		}
		if (sz[i] == 2)  {
			printf("%d %d\n", p[sp[1]].d + p[sp[2]].d, max(p[sp[1]].d, p[sp[2]].d));
			continue;
		}
		sort(sp + 1, sp + ip + 1, cmp_pt);
		sort(sv + 1, sv + id + 1);

		int top = 1, ans1 = 0, ans2 = 0;
		for (int j = 2; j <= id; j += 2)  {
			while (top <= ip  &&  vis[sp[top]] <= sv[j])  {
				int z = sp[top++];
				if (vis[z] < sv[j - 1])  ans1 += p[z].d, ans2 = max(ans2, p[z].d);
			}
			ans1 += asktot(1, 1, m, sv[j - 1], sv[j]), ans2 = max(ans2, askdep(1, 1, m, sv[j - 1], sv[j]));
		}
		while (top <= ip)  {
			int z = sp[top++];
			ans1 += p[z].d, ans2 = max(ans2, p[z].d);
		}
		printf("%d %d\n", ans1, ans2);
	}
}

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;

typedef int arr32[20010];
typedef int arrct[110][110];

arrct g, val, sv, dp;

int f[1 << 23];
arr32 a, b, in, to, vis, p, t;
int n, cnt, id, ans1 = 0, ans2 = 0;

int sum(const int &x, const int &y)  {
	if (x == -1  ||  y == -1)  return -1;
	return x + y;
}
int chkmin(const int &x, const int &y)  {
	if (x == -1)  return y;
	if (y == -1)  return x;
	return x < y ? x : y;
}
void prepare(int id)  {
	for (int i = 1; i <= id; ++i)  {
		int *s = sv[i], n = s[0];
		val[i][0] = -1;
		for (int j = 1; j <= n; ++j)  {
			int nt = j, v = 0;
			for (int k = 1; k < nt; ++k)  v = sum(v, g[s[k]][s[nt]]), --nt;
			nt = n;
			for (int k = j + 1; k < nt; ++k)  v = sum(v, g[s[k]][s[nt]]), --nt;
		  nt = j - 1;
			for (int k = 1; k < nt; ++k)  v = sum(v, g[s[k]][s[nt]]), --nt;
			nt = n;
			for (int k = j; k < nt; ++k)  v = sum(v, g[s[k]][s[nt]]), --nt;
			val[i][0] = chkmin(val[i][0], v);
		}
	}
	for (int i = 1; i <= id; ++i)
		for (int j = i + 1; j <= id; ++j)  {
			val[i][j] = val[j][i] = -1;
			if (sv[i][0] != sv[j][0])  continue;
			int *a = sv[i], *b = sv[j], n = sv[i][0];
			for (int k = 1; k <= n; ++k)  {
				int v = 0;
				for (int p = 1; p <= n; ++p)  v = sum(v, g[a[p]][b[(k - p + n) % n + 1]]), v = sum(v, g[a[p]][b[(k - p + n - 1) % n + 1]]);
				val[i][j] = val[j][i] = chkmin(val[i][j], v);
			}
		}
}
int dfs(int z)  {
	int nt = ++cnt;
	vis[z] = 1;
	dp[nt][1] = val[z][0];
	for (int i = 1; i <= n; ++i)
		if (val[z][i] != -1  &&  !vis[i])  {
			int p = dfs(i);
			++cnt;
			dp[cnt][0] = dp[nt][0] + dp[p][1];
			dp[cnt][1] = chkmin(sum(dp[nt][1], dp[p][1]), sum(sum(dp[nt][0], dp[p][0]), val[z][i]));
			nt = cnt;
		}
	return nt;
}
int main()  {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n;
	for (int i = 1; i <= n; ++i)  cin >> a[i];
	for (int i = 1; i <= n; ++i)  cin >> b[i], to[a[i]] = b[i];
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			cin >> g[i][j];

	for (int i = 1; i <= n; ++i)  {
		if (vis[a[i]])  continue;
		int k = a[i], *s = sv[++id];  s[0] = 0;
		while (!vis[k])  s[++s[0]] = k, vis[k] = 1, k = to[k];

		if (s[0] == 1)  --id;
		if (s[0] <= 2)  ans1 = max(ans1, s[0] - 1);
		else  ans1 = max(ans1, 2);
	}
	if (ans1 == 0)  printf("0\n0"), exit(0);
	if (ans1 == 1)  {
		for (int i = 1; i <= id; ++i)  ans2 = sum(ans2, g[sv[i][1]][sv[i][2]]);
		printf("%d\n%d", ans1, ans2), exit(0);
	}
	for (int i = 1; i <= id; ++i)  vis[i] = 0;
	if (ans1 == 2)  {
		prepare(id);
		if (id == 1)  printf("%d\n%d\n", ans1, val[1][0]), exit(0);
		if (id <= 23)  {
			int msc = 1 << (id - 1);
			for (int i = 1; i < msc; ++i)  {
				f[i] = -1;
				for (int j = 0; j < id - 1; ++j)
					if ((i >> j) & 1)  {
						f[i] = chkmin(f[i], sum(f[i - (1 << j)], val[j + 1][0]));
						for (int k = j + 1; k < id - 1; ++k)
							if ((i >> k) & 1)  f[i] = chkmin(f[i], sum(f[i - (1 << j) - (1 << k)], val[j + 1][k + 1]));
						break;
					}
			}
			ans2 = chkmin(-1, sum(f[msc - 1], val[id][0]));
			for (int i = 0; i < id - 1; ++i)
				ans2 = chkmin(ans2, sum(f[msc - 1 - (1 << i)], val[i + 1][id]));

			printf("%d\n%d", ans1, ans2), exit(0);
		}
		for (int i = 1; i <= id; ++i)
			if (!vis[i])  {
				int cnt = dfs(i);
				ans2 = sum(ans2, dp[cnt][1]);
			}
	  printf("%d\n%d", ans1, ans2);
	}
}

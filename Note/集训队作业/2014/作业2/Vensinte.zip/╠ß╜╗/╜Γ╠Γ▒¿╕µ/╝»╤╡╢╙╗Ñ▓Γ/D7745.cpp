#include <set>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#define mid ((l + r) >> 1)
#define son (k << 1)
const int mod = (int) 1e9 + 7, inf = (int) 1e9 + 10;
using namespace std;
typedef int arr32[1000010];
vector <int> ask[100010], upd[100010];
vector < pair <int, int> > change[100010];
arr32 sz, val, rank, mt, f, pre, rtA, rtB, svA, svB, bp, ap, L, x, y, mark, get;
long long w[1000010] = {1};
int c[1000010][2], id, cnt, n, m;
char S[100010], Sv[100010], *s = S, *sv = Sv, type[100010];
void update(int k)  {
	if (k == 0)  return;
	sz[k] = sz[c[k][0]] + sz[c[k][1]] + 1;
	mt[k] = (mt[c[k][0]] * w[sz[c[k][1]] + 1] + val[k] * w[sz[c[k][1]]] + mt[c[k][1]]) % mod;
}
void rota (int &rt, int x)  {
	int y = f[x], p = c[y][1] == x, q = !p;
	if (rt == y)  rt = x;
	else  c[f[y]][c[f[y]][1] == y] = x;
	f[x] = f[y];
	c[y][p] = c[x][q], f[c[x][q]] = y;
	c[x][q] = y, f[y] = x;
	update(y);
}
void splay(int &rt, int x)  {
	int y, z;
	for (; x != rt; rota(rt, x))
		if  (y = f[x], y != rt)
			if(z = f[y], (c[y][0] == x) ^ (c[z][0] == y))
				rota(rt, x);  else  rota(rt, y);
	update(x);
}
struct save_splay  {
	int rt;
	void init()  {
		rt = ++cnt, rank[cnt] = inf, sz[cnt] = 1;
	}
	int find(int x)  {
		int k = rt, res = 0;
		while (k)  {
			if  (rank[k] > x)  res = k, k = c[k][1];
			else  k = c[k][0];
		}
		splay(rt, res);
		return x;
	}
	int getin(int x)  {
		int k = c[rt][1];
		if (sz[k] == x)  return k;
		for (; sz[c[k][0]] != x; )
			if (sz[c[k][0]] > x)  k = c[k][0];
			else  x -= sz[c[k][0]] + 1, k = c[k][1];
		splay(c[rt][1], k);
		return c[c[rt][1]][0];
	}
	int &get(int x)  {
		find(x);
		if (x == 0)  return c[rt][1];
		else  {
			int k = c[rt][1], res = 0;
			while (k)  {
				if (rank[k] < x)  res = k, k = c[k][0];
				else  k = c[k][1];
			}
			splay(c[rt][1], res);
			return c[c[rt][1]][0];
		}
	}
} rta, rtb;
void build(int &k, int l, int r, int x, int ft)  {
	if (l > r)   return;
	k = ++cnt, mt[k] = val[k] = s[mid] - 'a', rank[k] = x, sz[k] = 1, f[k] = ft;
	if (l == r)  return;
	build(c[k][0], l, mid - 1, x, k);
	build(c[k][1], mid + 1, r, x, k);
	update(k);
}
void Set(int k, int p)  {
	mark[k] += p, pre[k] += p;
}
void push(int k)  {
	if (mark[k])  Set(son, mark[k]), Set(son + 1, mark[k]), mark[k] = 0;
}
void update(int k, int l, int r, int x, int y)  {
	if (l == r)  return (void) (pre[k] = y);
	push(k);
	if (x <= mid)  update(son, l, mid, x, y);
	else   update(son + 1, mid + 1, r, x, y);
	pre[k] = min(pre[son], pre[son + 1]);
}
void update(int k, int l, int r, int x, int y, int p)  {
	if (l > y  ||  r < x  ||  x > y)  return;
	if (x <= l  &&  r <= y)  return Set(k, p);
	push(k);
	update(son, l, mid, x, y, p), update(son + 1, mid + 1, r, x, y, p);
	pre[k] = min(pre[son], pre[son + 1]);
}
void alladd(int k, int l, int r, int x, int y, int p)  {
	if (l > y  ||  r < x  ||  x > y)  return;
	if (x <= l  &&  r <= y)  return (void) (get[k] += p);
	alladd(son, l, mid, x, y, p), alladd(son + 1, mid + 1, r, x, y, p);
}
int Ask(int k, int l, int r, int x)  {
	if (l == r)  return get[k];
	if (x <= mid)  return Ask(son, l, mid, x) + get[k];
	else   return Ask(son + 1, mid + 1, r, x) + get[k];
}
int Ask(int k, int l, int r, int x, int y)  {
	if (l > y  ||  r < x  ||  x > y)  return inf;
	if (x <= l  &&  r <= y)  return pre[k];
	push(k);
	return min(Ask(son, l, mid, x, y), Ask(son + 1, mid + 1, r, x, y));
}
void update(int k, save_splay &t, int *a, int *b, int *in)  {
	t.find(0);
	c[t.rt][1] = b[k], f[b[k]] = t.rt, update(t.rt);
	int N = upd[k].size();
	for (int i = 0; i < N; ++i)  {
		int s = upd[k][i];
		int &p = t.get(s);
		int ft = c[t.rt][1] ? c[t.rt][1] : t.rt;
		if (in[s] == 0)  in[s] = 1, p = a[s], f[a[s]] = ft, update(t.rt), update(c[t.rt][1]);
		else  p = 0, update(t.rt), update(c[t.rt][1]);
	}
}
int Ask(save_splay &a, save_splay &b)  {
	int len = min(sz[c[a.rt][1]], sz[c[b.rt][1]]);
	int l = 1, r = len, j, an = 0;
	for (; j = (l + r) >> 1, l <= r; )  {
		int A = a.getin(j), B = b.getin(j);
		if (mt[A] == mt[B])  an = j, l = j + 1;
		else  r = j - 1;
	}
	return an;
}
int lcp(char *a, char *b)  {
	int res = 0;
	while (*a  &&  *b  &&  *a == *b)  ++res, ++a, ++b;
	return res;
}
int main()  {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	rta.init(), rtb.init();
	for (int i = 1; i <= 300000; ++i)  w[i] = w[i - 1] * 101203 % mod;
	scanf("%d %d\n", &n, &m);
	for (int i = 1; i <= n; ++i)  {
		scanf("%s", s + 1);
		int len = strlen(s + 1);
		build(rtA[i], 1, len, 0, 0);
		build(rtB[i], 1, len, 0, 0);
		update(1, 1, n, i, lcp(s + 1, sv + 1));
		alladd(1, 1, n, i, i, len);
		swap(s, sv);
	}
	int xt, yt;
	for (int j = 1; j <= m; ++j)  {
		char ch;
		while (scanf("%c", &ch), ch != 'Q'  &&  ch != 'I');
		if (ch == 'Q')  {
			scanf("%d %d", &xt, &yt);
		}
		else  {
			scanf("%d %d %s", &xt, &yt, s + 1);
			upd[xt + 0].push_back(j);
			upd[yt + 1].push_back(j);
			ask[xt - 1].push_back(j);
			ask[yt - 0].push_back(j);
			int len = strlen(s + 1);
			build(ap[j], 1, len, j, 0);
			build(bp[j], 1, len, j, 0);
			L[j] = len;
		}
		type[j] = ch, x[j] = xt, y[j] = yt;
	}
	update(1, rtb, bp, rtB, svB);
	for (int i = 1; i < n; ++i)  {
		update(i, rta, ap, rtA, svA), update(i + 1, rtb, bp, rtB, svB);
        
		int k = ask[i].size();
		for (int j = 0; j < k; ++j)  {
			int s = ask[i][j];
			rta.find(s), rtb.find(s);
			int p = Ask(rta, rtb);
			change[s].push_back(make_pair(i + 1, p));
		}
	}
	for (int i = 1; i <= m; ++i)  {
		if (type[i] == 'Q')  {
			if (x[i] == y[i])  printf("%d\n", Ask(1, 1, n, x[i]));
			else  printf("%d\n", Ask(1, 1, n, x[i] + 1, y[i]));
		}
		else  {
			int k = change[i].size();
			for (int j = 0; j < k; ++j)  update(1, 1, n, change[i][j].first, change[i][j].second);
			if (i == 0)  continue;
			update(1, 1, n, x[i] + 1, y[i], L[i]);
			alladd(1, 1, n, x[i], y[i], L[i]);
		}
	}
}

#include <set>
#include <map>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#define lef(x) c[x][0]
#define rig(x) c[x][1]
#define int64 long long
const int mod = (int) 1e9 + 7;
using namespace std;

struct compare  {
	bool operator () (const int &a, const int &b)  {
		return a > b;
	}
};

map <int, int> to;
map <int, multiset<int, compare> *> t;
multiset <int, compare> svmap[500010];
multiset <int, compare> :: iterator T;
int svmap_cnt;

typedef int arr32[500010];

arr32 val, sz, f, prime, s, x, y;
int n, m, cnt, q, id, rt, c[500010][2];
int64 ans1, ans2 = 1;

int64 ex(int x, int y, int w)  {
	if ((w = (w % y + y) % y) % x == 0)  return w / x;
	return (ex(y % x, x, -w) * y + w) / x;
}
int fpm(int x, int y)  {
	int res = 1;
	for (; y; y >>= 1, x = (int64) x * x % mod)
		if  (y & 1)  res = (int64) res * x % mod;
	return res;
}
void update(int x)  {
	sz[x] = sz[lef(x)] + sz[rig(x)] + val[x];
}
void build(int &k, int l, int r, int ft)  {
	if (l > r)  return;
	int mid = (l + r) >> 1;
	k = mid, f[mid] = ft, sz[mid] = val[mid];
	if (l == r)  return;
	build(lef(k), l, mid - 1, mid), build(rig(k), mid + 1, r, mid);
	update(mid);
}
void rota(int x)  {
	int y = f[x], p = c[y][1] == x, q = !p;
	c[f[y]][c[f[y]][1] == y] = x;
	f[x] = f[y];
	c[y][p] = c[x][q], f[c[x][q]] = y;
	c[x][q] = y, f[y] = x;
	update(y);
}
void splay(int rt, int x)  {
	int y, z;
	for (; f[x] != rt; rota(x))
		if (y = f[x], f[y] != rt)
			if (z = f[y], (c[z][0] == y) ^ (c[y][0] == x))
				rota(x);  else  rota(y);
	update(x);
}
int take_tail(int x)  {
	int k = x;
	while (rig(k))  k = rig(k);
	return splay(0, k), k;
}
void ins(int x, int y)  {
	if (t.find(x) == t.end())  t[x] = svmap + svmap_cnt++;
	multiset <int, compare> *s = t.find(x)->second;
	if (!s->empty())  ans2 = ans2 * ex(fpm(x, *s->begin()), mod, 1) % mod;
	s->insert(y);
	ans2 = ans2 * fpm(x, *s->begin()) % mod;
}
void del(int x, int y)  {
	multiset <int, compare> *s = t.find(x)->second;
	ans2 = ans2 * ex(fpm(x, *s->begin()), mod, 1) % mod;
	T = s->find(y), s->erase(T); 
	if (!s->empty())  ans2 = ans2 * fpm(x, *s->begin()) % mod;
}
int worker(int x, int y, int z, int t)  {
	int res = 0, p = y;
	for (int i = 0; i <= z; ++i)
		res = (res + (int64) x * (p / y)) % mod, x /= t - (i == z - 1), y /= t;
	return res;
}
void update(int z, int sign)  {
	if (f[z])  return;
	int tmp = (int) sqrt((double) sz[z]) + 1, svt = sz[z];
	int64 res = 1;
	
	for (int i = 1; i <= cnt; ++i)
		if (prime[i] > tmp)  break;
		else  {
			int sv = 0, tp = 1, st = 1;
			while (svt % prime[i] == 0)  st *= (prime[i] - !sv), tp *= prime[i], ++sv, svt /= prime[i];
			if (sv == 0)  continue;
			int tot = worker(st, tp, sv, prime[i]);
		  res = (int64) res * tot % mod;
			if (sign == -1)  del(prime[i], sv);
			else  ins(prime[i], sv);
		}
	if (svt != 1)  {
		res = (int64) res * worker(svt - 1, svt, 1, svt) % mod;
		if (sign == -1)  del(svt, 1);
		else  ins(svt, 1);
	}
	ans1 = (ans1 + res * ex(sz[z], mod, 1) * sign % mod + mod) % mod;
}
void prepare()  {
	for (int i = 2; i <= 10000; ++i)  {
		int t = min(i - 1, 100), ok = true;
		for (int j = 2; j <= t; ++j)  {
			if (i % j == 0)  {
				ok = false;  break;
			}
		}
		if (ok)  prime[++cnt] = i;
	}
}
int main()  {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	prepare();

	scanf("%d %d", &n, &q);
	for (int i = 1; i <= q; ++i)  {
		scanf("%d %d", x + i, y + i);
		s[++id] = x[i], s[++id] = y[i];
	}
	sort(s + 1, s + id + 1);
	
	int nt = 1, cnt = 0;
	for (int i = 1; i <= id; ++i)  {
		if (s[i] == s[i - 1])  continue;
		if (s[i] != nt)  val[++cnt] = s[i] - nt; 
		val[++cnt] = 1, nt = s[i] + 1, to[s[i]] = cnt;
	}
	if (nt <= n)  val[++cnt] = n - nt + 1;
	build(rt, 1, cnt, 0), update(rt, 1);

	for (int i = 1; i <= q; ++i)  {
		int u = to[x[i]], v = to[y[i]], s, t;
		
		splay(0, u), s = sz[lef(u)];
		splay(0, v), t = sz[lef(v)];
		update(u, -1), update(v, -1);

		if (f[u] == 0)  {
			swap(lef(u), lef(v)), f[lef(u)] = u, f[lef(v)] = v, update(u), update(v);
			int rt = take_tail(v);
			rig(rt) = u, f[u] = rt, update(rt);
			update(rt, 1);
		}
		else  {
			if (s > t)  swap(u, v);
			splay(0, u), splay(u, v);
			swap(lef(u), lef(v)), f[lef(u)] = u, f[lef(v)] = v, rig(u) = 0, f[v] = 0;
			update(u), update(v);
			update(u, 1), update(v, 1);
		}
		printf("%I64d\n", (int64) ans1 * ans2 % mod);
	}
}

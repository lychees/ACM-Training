#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#define son (k << 1)
#define mid ((L + R) >> 1)
#define sqr(x) ((x) * (x))
const int base = (1 << 16) - 1, inf = (int) 1e9 + 10;
using namespace std;
typedef int arr32[200010];
typedef int arrct[10000010];
arrct c, next;
arr32 cnt, g, Lx, Ly, Rx, Ry;
int sv[35010][1100], pre[1 << 17];
int n, m, k, msc, pmark, ap, tmp;
struct point  {
	int x, y, r, sqr_r, sr, num, a, b;
	void init(int sp)  {
		a = (sp - 1) / 32, b = (sp - 1) % 32;
		scanf("%d %d %d %d %d", &x, &y, &r, &sr, &num);
		sqr_r = sqr(r);
	}
} pt[50010], *p[50010];
bool cmp(point *a, point *b)  {
	if (pmark)  return a->x < b->x;
	else  return a->y < b->y;
}
void build(int k, int L, int R)  {
	Lx[k] = Ly[k] = inf, Rx[k] = Ry[k] = -inf;
	for (int i = L; i <= R; ++i)  {
		Lx[k] = min(Lx[k], p[i]->x);
		Ly[k] = min(Ly[k], p[i]->y);
		Rx[k] = max(Rx[k], p[i]->x);
		Ry[k] = max(Ry[k], p[i]->y);
	}
	if (L == R)  return;
	pmark ^= 1;
	sort(p + L, p + R + 1, cmp);
	build(son, L, mid), build(son + 1, mid + 1, R);
	pmark ^= 1;
}
int check(int k, const point &r)  {
	int dx = max(0, max(Lx[k] - r.x, r.x - Rx[k])), dy = max(0, max(Ly[k] - r.y, r.y - Ry[k]));
	if (sqr(dx) + sqr(dy) >  r.sqr_r  &&  dx + dy >  r.sr)  return -1;
	dx = max(abs(Lx[k] - r.x), abs(Rx[k] - r.x)), dy = max(abs(Ly[k] - r.y), abs(Ry[k] - r.y));
	if (sqr(dx) + sqr(dy) <= r.sqr_r  ||  dx + dy <= r.sr)  return 1;
	return 0;
}
void cover(int k, int L, int R, const point &r)  {
	if (L == R)  {
		if (check(k, r) == 1)  sv[p[L]->num][r.a] |= 1 << r.b;
		return;
	}
	int tmp = check(k, r);
	if (tmp == -1)  return;
	else  if (tmp == 1)  c[++ap] = &r - pt, next[ap] = g[k], g[k] = ap;
	else  cover(son, L, mid, r), cover(son + 1, mid + 1, R, r);
}
void dfs(int k, int L, int R)  {
	for (int x = g[k]; x; x = next[x])
		if (cnt[c[x]]++);
		else  sv[0][pt[c[x]].a] |= 1 << pt[c[x]].b;
	if (L == R)  {
		for (int i = 0; i <= msc; ++i)  sv[p[L]->num][i] |= sv[0][i];
		return;
	}
	dfs(son, L, mid), dfs(son + 1, mid + 1, R);
	for (int x = g[k]; x; x = next[x])
		if (--cnt[c[x]]);
		else  sv[0][pt[c[x]].a] ^= 1 << pt[c[x]].b;
}
double fpm(double x, int y)  {
	double ret = 1;
	for (; y; y >>= 1, x = x * x)
		if  (y & 1)  ret = ret * x;
	return ret;
}
int main()  {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	for (int i = 1; i <= base; ++i)
		pre[i] = pre[i - (i & -i)] + 1;
	scanf("%d %d %d", &n, &m, &k), msc = (n - 1) / 32;
	for (int i = 1; i <= n; ++i)  {
		pt[i].init(i), p[i] = pt + i;
	}
	build(1, 1, n);
	for (int i = 1; i <= n; ++i)  {
		cover(1, 1, n, pt[i]);
	}
	dfs(1, 1, n);
	for (int i = 1; i <= n; ++i)  {
		sv[p[i]->num][p[i]->a] ^= 1 << p[i]->b;
	}
	double ans = 0;
	for (int i = 1; i <= k; ++i)  {
		int cnt = 0, *s = sv[i];
		for (int j = 0; j <= msc; ++j)  if (s[j])  cnt += pre[s[j] & base] + pre[(s[j] >> 16) & base];
		ans += fpm((double) (n - cnt) / n, m);
	}
	printf("%.10lf\n", ans);
}

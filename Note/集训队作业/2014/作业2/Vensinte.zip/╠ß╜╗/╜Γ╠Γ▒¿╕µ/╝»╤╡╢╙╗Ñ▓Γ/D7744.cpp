#include <set>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#define int64 long long
#define son (k << 1)
#define mid ((l + r) >> 1)
using namespace std;

typedef int64 arr[1100010];
typedef int arr32[1100010];

arr val, f, las, d, tot;
arr32 next, lt, rk, svrk;
int n, m, k;
int nodecnt, pointcnt, segncnt;

struct compare  {
	bool operator () (const int &a, const int &b)  {
		return val[a] < val[b]  ||  val[a] == val[b]  &&  a < b;
	}
};
set <int, compare> t;

struct node  {
	int L, R;
	node *lef, *rig;
} node_null, *root[100010], p_node[10000010];
int64 Lef(int x)  {
	return f[x] - tot[x] - d[x == 0 ? 0 : x - 1];
}
int64 Rig(int x)  {
	return f[x] - tot[x] + d[x == 0 ? 0 : x - 1];
}
int cmp(int s, int x, int y)  {
	if (s)  return Lef(x) < Lef(y) ? x : y;
	else    return Rig(x) < Rig(y) ? x : y;
}
int ask(node *&rt, int l, int r, int x, int y)  {
	if (l > y  ||  r < x  ||  x > y)  return 0;
	if (x <= l  &&  r <= y)  return x == 1 ? rt->L : rt->R;
	return cmp(x == 1, ask(rt->lef, l, mid, x, y), ask(rt->rig, mid + 1, r, x, y));
}
void reget(node *&rt)  {
	node *np = p_node + ++nodecnt;
	*np = *rt;  rt = np; 
}
void update(node *&rt, int l, int r, int x, int y)  {
	reget(rt);
	if (l == r)  return (void) (rt->L = rt->R = y);
	if (x <= mid)  update(rt->lef, l, mid, x, y);
	else  update(rt->rig, mid + 1, r, x, y);
	rt->L = cmp(1, rt->lef->L, rt->rig->L);
	rt->R = cmp(0, rt->lef->R, rt->rig->R);
}
struct point  {
	node *rt;
	int tp, L;
	int64 val;
	void Ask()  {
		int a = ask(rt, 1, m, 1, rk[tp] - 1), b = ask(rt, 1, m, rk[tp] + 1, m);
		if (Lef(a) + d[tp] < Rig(b) - d[tp])  L = a, val = Lef(a) + d[tp];
		else  L = b, val = Rig(b) - d[tp];
		val += tot[tp - 1];
	}
	void init(int x)  {
		tp = x, rt = root[x], Ask();
	}
	void upd()  {
		update(rt, 1, m, rk[L - 1], 0), Ask();
	}
} point_null, p_point[2000010];
struct segn {
	point *rt;
	segn *lef, *rig;
} segn_null, *nrt[1100010], *svt[100010], p_segn[10000010];
void reget(segn *&rt)  {
	segn *np = p_segn + ++segncnt;
	*np = *rt;  rt = np; 
}
void reget(point *&rt)  {
	point *np = p_point + ++pointcnt;
	*np = *rt,  rt = np;
}
bool cmp(point *a, point *b)  {
	return a->val - f[a->tp] < b->val - f[b->tp];
}
void update(segn *&rt, int l, int r, int x, int y)  {
	reget(rt);
	if (l == r)  {
		reget(rt->rt);
		if (y)  rt->rt->upd();
		else  rt->rt->init(x);
		return;
	}
	if (x <= mid)  update(rt->lef, l, mid, x, y);
	else  update(rt->rig, mid + 1, r, x, y);
	if (cmp(rt->lef->rt, rt->rig->rt))  rt->rt = rt->lef->rt;
	else  rt->rt = rt->rig->rt;
}
bool cmp_svrk(const int &a, const int &b)  {
	return d[a] < d[b];
}
int main()  {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int64 base = 0, ans = 0;
	int cnt = 0;
	
	f[0] = (int64) 1e16;
	node_null.lef = node_null.rig = &node_null;
	point_null.rt = &node_null, point_null.val = (int64) 1e18;
	segn_null.lef = segn_null.rig = &segn_null;
	segn_null.rt  = &point_null;

	scanf("%d %d", &n, &k), k = (k + 1) / 2;
	for (int i = 1; i <= n; ++i)  {
		scanf("%I64d", d + i), svrk[i] = i;
	}
	sort(svrk, svrk + n + 1, cmp_svrk);
	for (int i = 0; i <= n; ++i)  rk[svrk[i]] = i + 1;
	m = n + 1;

	tot[1] = abs(d[1]);
	f[1] = abs(d[1]), root[1] = &node_null, svt[1] = &segn_null;
	update(root[0] = root[1], 1, m, rk[0], 1), update(svt[1], 1, n, 1, 0);

	point svtp;
	for (int i = 2; i <= n; ++i)  {

		tot[i] = tot[i - 1] + abs(d[i] - d[i - 1]);
		svtp.rt = root[0], svtp.tp = i, svtp.Ask();
		f[i] = svtp.val;

		int s = svtp.L;

		svt[i] = svt[s];
		root[i] = root[0], update(root[i], 1, m, rk[s - 1], 0), update(svt[i], 1, n, i, 0);
		update(root[0], 1, m, rk[i - 1], i);
	}
	f[n + 1] = (int64) 1e16;
	for (int i = 1; i <= n; ++i)  f[n + 1] = min(f[n + 1], f[i] + tot[n] - tot[i]);  base = f[n + 1];
	for (int i = 1; i <= n; ++i)  {
		if (base == f[i] + tot[n] - tot[i])  {
			int p = ++cnt;
			nrt[p] = svt[i], next[p] = nrt[p]->rt->L, lt[p] = 1;
			val[p] = nrt[p]->rt->val - f[nrt[p]->rt->tp], las[p] = nrt[p]->rt->val - f[nrt[p]->rt->tp];
			update(nrt[p], 1, n, nrt[p]->rt->tp, 1);
			t.insert(p);
			base = -1;
			continue;
		}
		int p = ++cnt;
		nrt[p] = svt[i], next[p] = i, val[p] = f[i] + tot[n] - tot[i] - f[n + 1];
		t.insert(p);
	}
	ans = 0;
	for (int i = 1; i < k; ++i)  {
		int p = *t.begin();
		ans = val[p], t.erase(p);

		if (lt[p])  {
			int np = ++cnt;
			nrt[np] = nrt[p], next[np] = nrt[p]->rt->L, lt[np] = 1;
			val[np] = val[p] - las[p] + nrt[p]->rt->val - f[nrt[p]->rt->tp], las[np] = nrt[p]->rt->val - f[nrt[p]->rt->tp];
			update(nrt[np], 1, n, nrt[p]->rt->tp, 1);
			t.insert(np);
		}
		if (next[p] == 0)  continue;

		int np = ++cnt;
		nrt[np] = svt[next[p]], next[np] = nrt[np]->rt->L, lt[np] = 1;
		val[np] = val[p] + nrt[np]->rt->val - f[nrt[np]->rt->tp], las[np] = nrt[np]->rt->val - f[nrt[np]->rt->tp];
		update(nrt[np], 1, n, nrt[np]->rt->tp, 1);
		t.insert(np);
	}
	printf("%I64d\n", ans + f[n + 1]);
}

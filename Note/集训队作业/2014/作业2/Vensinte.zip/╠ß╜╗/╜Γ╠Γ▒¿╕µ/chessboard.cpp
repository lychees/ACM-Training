/*
	��������ݴ������ɵ����ݡ�
  ����POJ�ϣ���Ϊ�ύ����� RE ��ջ�ռ䲻�㣩
 */
#include <set>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#define mid ((l + r) >> 1)
#define son (k << 1)
using namespace std;

typedef int arr32[600010];
typedef int arrct[6000010];

arr32 s, g, a1, a2, b1, b2, to, num, lef, rig, slf, dmp, rk, in, q, t, cert, x, y;
arrct c, next;
int n, ap, dm, *L, *R, tA, dE, rt, k;

struct compare  {
	bool operator () (const int &a, const int &b)  {
		return R[a] < R[b]  ||  R[a] == R[b]  &&  a < b;
	}
};
set <int, compare> w;
bool cmp(const int &a, const int &b)  {  return L[a] < L[b];  }
void link(int &x, int &y)  {
	if (!x)  x = ++dm;
	if (!y)  y = ++dm;
	c[++ap] = y, next[ap] = g[x], g[x] = ap;
}
void link(int &k, int l, int r, int x, int &p)  {
	link(k, p);
	if (l == r)  return;
  if (x <= mid)  link(lef[k], l, mid, x, p);
	else  link(rig[k], mid + 1, r, x, p);
}
void link(int &k, int l, int r, int x, int y, int &p)  {
	if (l > y  ||  r < x  ||  x > y)  return;
	if (x <= l  &&  r <= y)  return link(p, k);
	link(lef[k], l, mid, x, y, p), link(rig[k], mid + 1, r, x, y, p);
}
void build(int &k, int l, int r)  {
	if (!k)  k = ++dm, lef[k] = rig[k] = 0;
	if (l == r)  return;
	build(lef[k], l, mid), build(rig[k], mid + 1, r);
}
void dfs(int z)  {
	t[z] = in[z] = 1, slf[z] = dmp[z] = ++dE, q[++tA] = z;
	for (int x = g[z]; x; x = next[x])
		if (!t[c[x]])  dfs(c[x]), slf[z] = min(slf[z], slf[c[x]]);
		else  if (in[c[x]])       slf[z] = min(slf[z], dmp[c[x]]);
	
	if (slf[z] == dmp[z])  {
		++k;
		do num[q[tA]] = k, in[q[tA]] = 0; while (q[tA--] != z);
	}
}
bool workans(int *a, int *b, int *to)  {
	L = a, R = b;
	memset(g, 0, sizeof(g)), memset(t, 0, sizeof(t)), memset(s, 0, sizeof(s)), memset(num, 0, sizeof(num));
	for (int i = 1; i <= n; ++i)  rk[i] = i;
	sort(rk + 1, rk + n + 1, cmp), k = 0, rt = 0;

	int m = 1;   w.clear();
	for (int i = 1; i <= n; ++i)  {
		while (m <= n  &&  L[rk[m]] == i)  w.insert(rk[m++]);
		if (w.empty()) return false;
		
		int k = *w.begin();
		if (R[k] < i)  return false;
		w.erase(k), to[k] = i;
	}
	dm = 0, ap = 0, build(rt, 1, n);
	for (int i = 1; i <= n; ++i)  link(rt, 1, n, L[i], to[i] - 1, s[i]), link(rt, 1, n, to[i] + 1, R[i], s[i]), link(rt, 1, n, i, s[i + n]), link(s[to[i] + n], s[i]);
	for (int i = 1; i <= n; ++i)  if (!t[s[i]])  dfs(s[i]);
	for (int i = 1; i <= n; ++i)  if (num[s[to[i] + n]] != num[s[i]])  cert[i]++;
	return true;
}
int main()  {
	while (scanf("%d", &n) != EOF)  {
		for (int i = 1; i <= n; ++i)  cert[i] = 0;
		for (int i = 1; i <= n; ++i)  scanf("%d %d %d %d", a1 + i, b1 + i, a2 + i, b2 + i);

		if (workans(a1, a2, x)  &&  workans(b1, b2, y))  {
			printf("%d\n", count(cert + 1, cert + n + 1, 2));
			for (int i = 1; i <= n; ++i)  if (cert[i] == 2)  printf("%d %d %d\n", i, x[i], y[i]);
		}
		else  printf("-1\n");
	}
}

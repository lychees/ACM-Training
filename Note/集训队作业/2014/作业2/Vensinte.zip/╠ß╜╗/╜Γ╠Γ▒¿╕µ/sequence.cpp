#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#define uns unsigned short
using namespace std;

typedef int arr32[100010];

arr32 x, y, L, R;
int n;

void swapx(int *x, int l, int r)  {
	int mid = (r - l + 1) >> 1;
	for (int i = 1; i <= mid; ++i)  swap(x[l + i - 1], x[r - i + 1]);
}
void dfs(int z, int w, int v, int *x)  {
	if (z == v)  {
		for (int i = 1; i <= n; ++i)  if (x[i] != i)  return;
       
		cout << 3 << endl;
		for (int i = 1; i <= 3; ++i)  cout << L[i] << " " << R[i] << endl;
		exit(0);
	}
    
	bool t = 0;
	for (int i = 1; i <= n; ++i)
		if (x[i] != i)   {
			t = 1;
			for (int j = i + 1; j <= n; ++j)
				if (x[j] == i  ||  x[i] == j)  L[z] = i, R[z] = j, swapx(x, i, j), dfs(z + w, w, v, x), swapx(x, i, j);
			break;
		}
    
	for (int i = n; i; --i)
		if (x[i] != i)  {
			t = 1;
			for (int j = i - 1; j; --j)
				if (x[j] == i  ||  x[i] == j)  L[z] = j, R[z] = i, swapx(x, j, i), dfs(z + w, w, v, x), swapx(x, j, i);
			break;
		}
    
	if (!t)  {
		cout << z - 1 << endl;
		for (int i = 1; i < z; ++i)  cout << L[i] << " " << R[i] << endl;
		exit(0);
	}
}
int a;
int main()  {
	cin >> n;
	int cnt = 0;
	for (int i = 1; i <= n; ++i)  {
		cin >> a;
		x[a] = i;
		if (i == a)  ++cnt;
	}
	if (cnt == n)  {  printf("0");  exit(0);  }
  
	dfs(1, 1, 4, x);
	for (int i = 1; i <= n; ++i)  y[x[i]] = i;
    
	dfs(3, -1, 0, y);
}

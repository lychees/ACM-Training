#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;

typedef int arr32[600010];

arr32 c, next, g, t, in, x, y, d, f;
long long ans, cnt, p, st[100010];
int n, m, ap;

void link(int x, int y)  {
	c[++ap] = y, next[ap] = g[x], g[x] = ap;
	c[++ap] = x, next[ap] = g[y], g[y] = ap;
}
long long Random()  {
	return ((long long) rand() << 48) + ((long long) rand() << 32) + ((long long) rand() << 16) + rand();
}
void dfs(int z)  {
	t[z] = 1;
	for (int x = g[z]; x; x = next[x])
		if (!t[c[x]])  f[c[x]] = z, d[c[x]] = d[z] + 1, dfs(c[x]);
}
void dfs(int z, int ft)  {
	for (int x = g[z]; x; x = next[x])
		if (f[c[x]] == z)  dfs(c[x], z), st[z] ^= st[c[x]], in[z] += in[c[x]];
	if (in[z] == 1)  ++cnt;
	if (in[z] == 2)  ++ans;
}
int main()  {
	srand(173);

	scanf("%d %d", &n, &m);
	for (int i = 1; i <= m; ++i)  scanf("%d %d", x + i, y + i), link(x[i], y[i]);

	dfs(1);
	for (int i = 1; i <= m; ++i)  {
	  int u = x[i], v = y[i];
		if (d[u] < d[v])  swap(u, v);
		in[u]++, in[v]--; 
		if (d[u] == d[v] + 1)  continue;
		p = Random(), st[u] ^= p, st[v] ^= p;
	}
	dfs(1, 0);

	sort(st + 1, st + n + 1);

	int nt = 0;
	for (int i = 1; i <= n; ++i)  {
		if (st[i] == 0)  continue;
		if (st[i] == st[i - 1])  ans += nt++;
		else  nt = 1;
	}
	cout << ans + cnt * (m - 1) - cnt * (cnt - 1) / 2 << endl;
}

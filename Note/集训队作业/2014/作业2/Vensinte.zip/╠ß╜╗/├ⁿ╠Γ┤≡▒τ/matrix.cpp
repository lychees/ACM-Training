#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
const double eps = 1e-7, inf = 1e9;
using namespace std;

typedef int arr32[200010];
typedef double db[200010];

struct task_2nd  {
	db d, f;
	arr32 t, in;
	int n, ap, S, T, Y;
	double E[310][310], pay[310][310], tmp, imp, ntd, svt, flow;
	
	double dfs(int z, int et, double p, double &cost)  {
		if (z == et  ||  p < eps)  return flow -= p, cost += p * d[et], p;
		double fl = 0, id, *e = E[z], *pt = pay[z];
		in[z] = 1, t[z] = Y;
		for (int i = z == S  ||  z <= n; i <= n; ++i)  {
       int x = i == 0 ? et : z <= n ? i + n : i;
       if (e[x] > eps)  {
          id = d[z] + pt[x] - d[x];
          if (id < f[x])  f[x] = id;
          if (abs(id) < eps  &&  p > eps  &&  !in[x])  {
             double flt = dfs(x, et, p < e[x] ? p : e[x], cost);
             fl += flt, p -= flt, e[x] -= flt, E[x][z] += flt;
             if (p < eps)  break;
          }
       }
    }
    in[z] = 0;
    return fl;
	}
	double run(double dE)  {
    for (int i = 1; i <= n; ++i)  E[S][i+0] = 1 - dE, E[i+0][S] = 0;
    for (int i = 1; i <= n; ++i)  E[i+n][T] = 1 + dE, E[T][i+n] = 0;
    for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= n; ++j)  
        E[i][j+n] = min(1 + dE, 1 - dE), E[j+n][i] = 0;

		int m = n + n + 2;
		for (int i = 1; i <= m; ++i)  d[i] = 0;
		
		int cnt = 0;
		ntd = 0, imp = 0, flow = min(1 + dE, 1 - dE) * n;
		double cost = 0;
		do  {
			++Y;
			for (int i = 1; i <= m; ++i)  f[i] = 1e17;
			dfs(S, T, inf, cost);
			imp = 1e17;
			for (int i = 1; i <= m; ++i)
			  if (t[i] < Y  &&  f[i] < imp)
				 	imp = f[i];
			for (int i = 1; i <= m; ++i)
			  if (t[i] < Y)  d[i] += imp;
			ntd += imp;
			++cnt;
		}
		while (imp < 1e16  &&  flow > eps);
		return cost - (1 - abs(dE)) * tmp;
 	}
	void mainwork(int test)  {
		scanf("%d", &n), S = n << 1 | 1, T = S + 1, ap = 1;
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= n; ++j)  {
				scanf("%lf", pay[i] + j + n);
				tmp = max(tmp, pay[i][j + n]);
			}
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= n; ++j)  {
				pay[i][j + n] = -pay[i][j + n] + tmp;
				pay[j + n][i] = -pay[i][j + n];
      }
		svt = tmp, tmp *= n;

		if (test == 1)  {
			double l = -1, r = 1, L, R;
			for (; L = l + (r - l) * 0.499997, R = r - (r - l) * 0.499997,  r - l > eps; )
				if (run(L) < run(R))  r = R;
				else  l = L;
			printf("%.4lf\n", -run((l + r) / 2) / 2);
		}
		else  printf("%.4lf\n", -run(0) / 2);
	}
} task1, task2;
int main()  {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);

	task1.mainwork(0);
	task2.mainwork(1);
}

#include <cstdio>
#include <algorithm>
using namespace std;

typedef long long LL;
const int N = 131072;

inline LL fpow (LL x, LL y, LL m) {
	LL r(1);
	for (; y; y >>= 1, x = x * x % m) if (y & 1) r = r * x % m;
	return r;
}

const LL modu = LL(1e9) + 7, inv2 = fpow(2, modu - 2, modu);

void trans (LL A[], int n) {
	if (n == 1) return;
	int m = n >> 1;
	trans(A, m);
	trans(A + m, m);
	for (int i = 0; i < m; ++i) {
		LL a = A[i], b = A[i + m];
		A[i] = (a - b + modu) % modu;
		A[i + m] = (a + b) % modu;
	}
}
void untrans (LL A[], int n) {
	if (n == 1) return;
	int m = n >> 1;
	for (int i = 0; i < m; ++i) {
		LL a = A[i], b = A[i + m];
		A[i] = (a + b) * inv2 % modu;
		A[i + m] = (b - a + modu) * inv2 % modu;
	}
	untrans(A, m);
	untrans(A + m, m);
}/*
void covolution (LL A[], LL B[], int n) {
	trans(A, n);
	if (A != B) trans(B, n);
	for (int i = 0; i < n; ++i) A[i] = A[i] * B[i] % modu;
	untrans(B, n);
	if (B != A) untrans(A, n);
}
LL R[N + 50];
void covolution (LL A[], int n, LL k) {
	for (int i = 0; i < n; ++i) R[i] = A[i];
	for (--k; k; k >>= 1, covolution(R, R, n)) if (k & 1) covolution(A, R, n);
}*/
void covolution (LL A[], int n, LL k) {
	trans(A, n);
	k %= modu - 1;
	for (int i = 0; i < n; ++i) A[i] = fpow(A[i], k, modu);
	untrans(A, n);
}

LL A[N + 50], S[N + 50];

class Nim {
public:
	int count (int K, int L) {
		fill(S, S + L + 1, 1);
		S[0] = S[1] = 0;
		for (int i = 2; i <= L; ++i) {
			if (! S[i]) continue;
			for (int j = i * 2; j <= L; j += i) S[j] = 0;
		}
		fill(S + L + 2, S + N + 50, 0);
		int maxbit = 1;
		while (maxbit <= L) maxbit <<= 1;
		covolution(S, maxbit, K);
		return int(S[0]);
	}
};


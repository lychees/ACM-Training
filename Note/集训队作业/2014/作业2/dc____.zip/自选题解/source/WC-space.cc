#include <bits/stdc++.h>
using namespace std;

namespace topl
{
	const int N = int(1e5) + 50, C = 21, modu = 10007;

	int F[C][N], SF[C][C][N], pow[N];

	int comb[N][C], mu[N], primes[N], nonpr[N];
	void init ()
	{
		int pcnt = 0;
		mu[1] = 1;
		for (int i = 2; i < N; ++i)
		{
			if (!nonpr[i])
				primes[++pcnt] = i, mu[i] = -1;
			
			for (int j = 1; j <= pcnt; ++j)
			{
				if (primes[j] * i >= N) break;
				nonpr[primes[j] * i] = 1;
				mu[primes[j] * i] = -mu[i];
				if (i % primes[j] == 0)
				{
					mu[primes[j] * i] = 0;
					break;
				}
			}
		}

		comb[0][0] = 1;
		for (int i = 1; i < N; ++i)
		{
			comb[i][0] = 1;
			for (int j = 1; j <= i && j < C; ++j)
				comb[i][j] = (comb[i - 1][j - 1] + comb[i - 1][j]) % modu;
		}


		for (int k = 0; k < C; ++k)
		{
			for (int i = 1; i < N; ++i)
				for (int j = 1; i * j < N; ++j)
					(F[k][i * j] += comb[i - 1][k] * mu[j]) %= modu;
		}

		fill(pow, pow + N, 1);
		for (int i = 0; i < C; ++i)
		{
			for (int k = 0; k < C; ++k)
				for (int j = 1; j < N; ++j)
					SF[i][k][j] = (SF[i][k][j - 1] + F[k][j] * pow[j]) % modu;

			for (int j = 1; j < N; ++j)
				(pow[j] *= j) %= modu;
		}
	}

	int n, c, M[C], mmin, X[C], Y[C], coef[C][C];

	void solve ()
	{
		scanf("%d%d", &c, &n);
		mmin = N;
		for (int i = 1; i <= c; ++i)
			scanf("%d", M + i), mmin = min(mmin, M[i]);

		int ans = 0;
		for (int de = 1; de <= mmin; )
		{
			int nde = N;
			for (int i = 1; i <= c; ++i)
				nde = min(nde, M[i] / (M[i] / de));

			for (int i = 1; i <= c; ++i)
			{
				long long t = (M[i] - 1) / de;
				X[i] = t * M[i] % modu;
				Y[i] = t * (t + 1) / 2 % modu;
			}
			coef[0][0] = 1;
			for (int i = 1; i <= c; ++i)
			{
				coef[i][0] = coef[i - 1][0] * X[i] % modu;
				for (int j = 1; j <= i; ++j)
					coef[i][j] = (coef[i - 1][j] * X[i] + coef[i - 1][j - 1] * (-Y[i])) % modu;
			}
			int f = 0;
			for (int i = 0; i <= c; ++i)
				(f += coef[c][i] * (SF[i][n - 2][nde] - SF[i][n - 2][de - 1])) %= modu;

			(ans += f) %= modu;
			de = nde + 1;
		}
		printf("%d\n", (ans + modu) % modu);
	}

	int run ()
	{
		int t;
		init ();
		scanf("%d", &t);
		while (t--) solve();
		return 0;
	}
}

int main ()
{
#ifdef LOCAL
	freopen("in", "r", stdin);
#endif
	return topl::run();
}


#include <cstdio>
#include <cassert>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long LL;

const LL modu = LL(1e9) + 7;
const int N = int(2e5) + 50;

inline LL M (LL x, LL y) {
	assert(x < modu && y < modu);
	return x * y % modu;
}

LL f[N];
int vis[N], deg[N], dep[N], size[N], last[N], n;
vector<int> g[N];

void init (int x, int ax = 0) {
	for (int i = 0; i < deg[x]; ++i) {
		if (g[x][i] == ax) { swap(g[x][i], g[x][deg[x] - 1]); break; }
	}
	++size[x];
	dep[x] = dep[ax] + 1;
	for (int i = 0, ie = ax ? deg[x] - 1 : deg[x]; i < ie; ++i) {
		init(g[x][i], x);
		size[x] += size[g[x][i]];
		if (! last[x] && last[g[x][i]]) last[x] = last[g[x][i]];
	}
	if (deg[x] != 2) last[x] = x;
}

LL calc (int, int) ;

LL calc (int x) { // x on topleft corner
	// trivival cases
	assert(x);
	if (vis[x]) return f[x];
	vis[x] = 1;
	LL &res = f[x]; res = 0;
	if (size[x] % 2 == 1) return 0; // odd number of vertices
	if (deg[last[x]] == 1) return res = size[x] / 2; // line : s_x / 2 turning points
	// down
	if (deg[x] == 2) {
		if (deg[g[x][0]] == 1) res ++;
		else if (deg[g[x][0]] == 2) res += calc(g[g[x][0]][0]);
	}
	// right
	int y = last[x], l = g[y][0], r = g[y][1], d = dep[y] - dep[x];
	assert(l && r);
	// y locates on the second row
	for (int i = 0; i < 2; ++i) {
		if (deg[last[l]] == 1 && d - 1 == size[l]) res += calc(r), res %= modu;
		swap(l, r);
	}
	// y locates on the first row
	for (int i = 0; i < 2; ++i) {
		if (deg[last[l]] == 1 && d + 1 == size[l]) {
			res += calc(r), res %= modu;
		}
		if (y == x && deg[l] == 2) {
			res += calc(r, g[l][0]), res %= modu;
		}
		if (deg[l] == 3) {
			int a = g[l][0], b = g[l][1];
			for (int j = 0; j < 2; ++j) {
				if (deg[last[a]] == 1 && d == size[a])
					res += calc(b, r), res %= modu;
				swap(a, b);
			}
		}
		swap(l, r);
	}
	return res %= modu;
}

LL calc (int x, int y) {
	assert(x && y);
	if ((size[x] + size[y]) % 2 == 1) return 0;
	if (deg[x] == 1 && deg[y] == 1) return 1;
	if (deg[x] > 2 || deg[y] > 2) return 0;
	if (deg[x] == 2 && deg[y] == 2) return calc(g[x][0], g[y][0]);
	if (deg[x] == 2 && deg[y] == 1) return calc(g[x][0]);
	if (deg[x] == 1 && deg[y] == 2) return calc(g[y][0]);
	assert(false);
}

void solve () {
	int rt = -1;
	for (int i = 1; i <= n; ++i) {
		if (deg[i] > 3) {
			printf("0\n");
			return;
		}
		if (deg[i] == 3) {
			rt = i;
		}
	}
	if (rt == -1) {
		printf("%lld\n", n == 2 ? 2 : (1LL * n * n / 2 - n + 4) % modu);
		return;
	}
	init (rt);
	int l[3] = {g[rt][0], g[rt][1], g[rt][2]};
	sort(l, l + 3);
	LL res = 0;
	do {
		int p = l[1];
		if (deg[p] == 1) {
			res += M(calc(l[0]), calc(l[2]));
		}
		else if (deg[p] == 2) {
			res += M(calc(l[0]), calc(l[2], g[p][0])) + M(calc(l[0], g[p][0]), calc(l[2]));
		}
		else {
			res += M(calc(l[0], g[p][0]), calc(l[2], g[p][1])) + 
			       M(calc(l[0], g[p][1]), calc(l[2], g[p][0]));
		}
		res %= modu;
//		printf("%lld\n", res);
	} while (next_permutation(l, l + 3));
	res = (res * 2 % modu + modu) % modu;
	printf("%lld\n", res);
//	for (int i = 1; i <= n; ++i) {
//		if (vis[i]) printf("(%d, %d), ", i, (int)f[i]);
//	}
//	puts("");
}

int main () {
#ifdef LOCAL
	freopen("in", "r", stdin);
#endif
	scanf("%d", &n); n *= 2;
	for (int i = 1, a, b; i < n; ++i) {
		scanf("%d%d", &a, &b);
		g[a].push_back(b); ++deg[a];
		g[b].push_back(a); ++deg[b];
	}
	solve();
	return 0;
}

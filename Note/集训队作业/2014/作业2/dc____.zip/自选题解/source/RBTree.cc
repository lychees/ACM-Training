// �㷨2
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

typedef long long LL;

const LL inf = ~0ULL >> 4;
const short infs = 1 << 13;
const int N = 505;

// (root, assistance, count); (root, count)
short dp[N][N][N], best[N][N];
LL dis[N][N], lim;
int size[N], n, color[N];
vector<int> e[N];

inline void update (short &x, short y) { if (y < x) x = y; }
inline void update (LL &x, LL y) { if (y < x) x = y; }
inline int contain (int x, int y) { return dis[1][x] + dis[x][y] == dis[1][y]; }

void solve (int x, int ax)
{
	size[x] = 1;
	for (int y : e[x]) if (y != ax)
	{
		solve(y, x);
		size[x] += size[y];
	}

	short tmp[2][N];

	for (int c = 1; c <= n; ++c)
	{
		if (dis[x][c] > lim)
		{
			fill(dp[x][c], dp[x][c] + 1 + n, infs);
			continue;
		}

		short *prev = tmp[0], *cur = tmp[1];
		fill(cur, cur + 1 + n, infs);
		cur[1] = !color[x];
		if (x != c)
			cur[0] = 0;

		int csize = 1;
		for (int y : e[x]) if (y != ax)
		{
			swap(cur, prev);
			fill(cur, cur + 1 + n, infs);
			for (int i = 0; i <= csize; ++i)
				for (int j = 0; j <= size[y]; ++j)
				{
					update(cur[i + j], prev[i] + dp[y][c][j]);
					if (!contain(y, c))
						update(cur[i + j], prev[i] + best[y][j]);
				}
			csize += size[y];
		}

		copy(cur, cur + 1 + csize, dp[x][c]);
	}
	
	for (int i = 0; i <= size[x]; ++i)
	{
		best[x][i] = infs;
		for (int j = 1; j <= n; ++j)
			if (contain(x, j)) update(best[x][i], dp[x][j][i]);
	}
}

int main ()
{
#ifdef LOCAL
	freopen("in", "r", stdin);
#endif
	cin >> n >> lim;

	for (int i = 1; i <= n; ++i)
		cin >> color[i];

	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			dis[i][j] = i == j ? 0 : inf;

	for (int i = 1; i < n; ++i)
	{
		int a, b, c;
		cin >> a >> b >> c;
		dis[a][b] = dis[b][a] = c;
		e[a].push_back(b);
		e[b].push_back(a);
	}
	
	for (int i = 1; i <= n; ++i)
		for (int x = 1; x <= n; ++x)
			for (int y = 1; y <= n; ++y)
				update(dis[x][y], dis[x][i] + dis[i][y]);

	solve(1, 0);

	int m = 0;
	for (int i = 1; i <= n; ++i)
		m += color[i];

	cout << (best[1][m] >= infs ? -1 : best[1][m]) << endl;
	return 0;
}

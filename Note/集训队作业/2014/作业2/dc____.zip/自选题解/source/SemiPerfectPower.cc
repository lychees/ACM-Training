
// {{{ Boilerplate Code <--------------------------------------------------
// vim:filetype=cpp:foldmethod=marker:foldmarker={{{,}}}

#include <bits/stdc++.h>
using namespace std;

#define for_(it,W) for(__typeof(W.begin())it=W.begin();it!=W.end();++it)

typedef long long LL;

// }}}

const int N = int(5e5), M = 2e4;

struct PTable
{
	LL *T[M];
	int primes[N], nonpr[N], mu[N], smu[N], p3[N], pcnt;
	vector<int> divisors[M];
	PTable () {
		smu[1] = mu[1] = 1;
		for (int i = 2; i < N; ++i) {
			if (!nonpr[i]) {
				primes[++pcnt] = i;
				smu[i] = 1;
				mu[i] = -1;
			}
			for (int j = 1; j <= pcnt; ++j) {
				int k = primes[j] * i;
				if (k >= N) break;
				nonpr[k] = 1;
				mu[k] = -mu[i];
				smu[k] = smu[i];
				if (i % primes[j] == 0) {
					smu[k] = mu[k] = 0;
					break;
				}
			}
		}
		for (int i = 1; i < M; ++i) {
			T[i] = new LL[N / i + 5];
			T[i][0] = 0;
			for (int j = 1; i * j < N; ++j)
				T[i][j] = T[i][j - 1] + smu[i * j];
		}
		for (int i = 1; i < M; ++i)
			for (int j = 1; i * j < M; ++j)
				if (smu[i * j])
					divisors[i * j].push_back(i);

		for (int i = 2; i * i * i < N; ++i) {
			int k = i * i * i;
			for (int j = 1; j * k < N; ++j) p3[j * k] = 1;
		}
		
	}
	LL* operator[] (int a) { return T[a]; }
} PT;

inline LL cbrt0 (LL n) {
	LL lo = 0, hi = LL(1e6);
	while (lo + 1 != hi) {
		LL mi = (lo + hi) >> 1;
		if (mi * mi * mi <= n) lo = mi;
		else hi = mi;
	}
	return lo;
}
inline LL sqrt0 (LL n) {
	LL lo = 0, hi = LL(1e9);
	while (lo + 1 != hi) {
		LL mi = (lo + hi) >> 1;
		if (mi * mi <= n) lo = mi;
		else hi = mi;
	}
	return lo;
}

inline LL gcd (LL a, LL b) { return b ? gcd(b, a % b) : a; }
inline LL count (LL r) {
	LL re2 = 0, re3 = 0;

	for (LL a = 1; a * a * a < r; ++a) {
		if (!PT.smu[a]) continue;
		// a j^2 <= r && a < j
		LL jlo = sqrt0(r / a);
		re2 += jlo - a;
	}

	for (LL a = 1; a * a * a * a < r; ++a) {
		if (PT.p3[a]) continue;
		LL bz = cbrt0(r / a);

		for (LL m = 1; m * m * m <= a; ++m) {
			LL g = gcd(a, m * m), z = m * m / g, w = a / g, cur = 0;

			if (!PT.smu[w]) continue;
			for_(it, PT.divisors[w]) {
				LL d = *it, 
				   lo = a / z, hi = bz / z;
				lo /= d, hi /= d;
				cur += PT.mu[d] * (PT.T[d][hi] - PT.T[d][lo]);
			}
			re3 += cur;
//			cerr << re2 + re3 << ' ';
		}
	}

	return re2 + re3;
}

class SemiPerfectPower
{
public:
	LL count(LL L, LL R)
	{
		LL re = ::count(R) - ::count(L - 1);
		return re;
	}
};


#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
const int LIM = int(4e7), inf = ~0u >> 2;

struct node {
	static node NBf[LIM], *NCr, *nil;
	node *lc, *rc;
	int s, tag, maxt, mint;
	LL sumt, delt;
	static void init () {
		nil = NBf; NCr = NBf + 1;
		nil->lc = nil->rc = nil;
		nil->maxt = -inf, nil->mint = inf;
	}
	static node* get () {
		assert(NCr - NBf < LIM);
		NCr->lc = NCr->rc = nil;
		return NCr++;
	}
	static node* getLeaf (int l, int r, int p, int w) {
		node *re = get();
		if (l == r) {
			re->s = 1;
			re->tag = re->maxt = re->mint = re->sumt = w;
		}
		else {
			int m = (l + r) >> 1;
			if (p <= m) re->lc = getLeaf(l, m, p, w);
			else re->rc = getLeaf(m + 1, r, p, w);
			re->update();
		}
		return re;
	}
	void add (int d) {
		assert(this != nil);
		delt += d, sumt += (LL)s * d;
		maxt += d, mint += d;
	}
	void push () {
		assert(this != nil);
		if (delt) {
			if (lc != nil) lc->add(delt);
			if (rc != nil) rc->add(delt);
			delt = 0;
		}
	}
	void update () {
//		assert(!delt && this != nil);
		s = lc->s + rc->s;
		sumt = lc->sumt + rc->sumt;
		maxt = max(lc->maxt, rc->maxt);
		mint = min(lc->mint, rc->mint);
	}
	void print (int l, int r) {
		if (l == r) {
			assert(s);
			cerr << l << ' ';
		}
		else {
			int m = (l + r) >> 1;
			if (lc != nil) lc->print(l, m);
			if (rc != nil) rc->print(m + 1, r);
		}
	}
	void split (int l, int r, int v, node *&rl, node *&rr) {
		if (this == nil) {
			rl = rr = nil;
			return;
		}
		if (v >= r) {
			rl = this, rr = nil;
			return;
		}
		if (v < l) {
			rl = nil, rr = this;
			return;
		}
		push();
		int m = (l + r) >> 1;
		rl = node::get(), rr = node::get();
		lc->split(l, m, v, rl->lc, rr->lc);
		rc->split(m + 1, r, v, rl->rc, rr->rc);
		if (rl->lc == nil && rl->rc == nil) rl = nil; else rl->update();
		if (rr->lc == nil && rr->rc == nil) rr = nil; else rr->update();
	}
	static node* merge (int l, int r, node *a, node *b) {
		if (a == nil) return b;
		if (b == nil) return a;
		a->push(); b->push();
		node *re = node::get();
		int m = (l + r) >> 1;
		re->lc = merge(l, m, a->lc, b->lc);
		re->rc = merge(m + 1, r, a->rc, b->rc);
		re->update();
		assert(re->s);
		return re;
	}
} node::NBf[LIM], *node::NCr, *node::nil;

namespace TOPL
{

	const int sqN = 700, N = int(1e6);

	typedef pair<int, int> pi;
#define Px first
#define Py second

	int W[N];
	pair<pi, int> A[N];
	set<int> S[N << 1];
	int n;

	struct Block {
		unordered_map<int, node*> tree;
		vector<int> axis0, axis1;
		int reversed, id, m;

		void init (int que[], int qc, int id)
		{
			this->id = id;
			axis0.push_back(-inf);
			axis1.push_back(-inf);
			m = qc + 2;
			for (int i = qc; i >= 1; --i)
			{
				int u = que[i];
			//	printf("(%d, %d) ", A[u].Px.Px, A[u].Px.Py);
				axis0.push_back(A[u].Px.Px);
				axis1.push_back(A[u].Px.Py);
				tree[A[u].Py] = node::getLeaf(0, m, axis0.size() - 1, W[A[u].Py]);
				S[A[u].Py].insert(id);
			}
			axis0.push_back(inf);
			axis1.push_back(inf);
			//puts("");

			reversed = !(axis1[1] < axis1[2]);
			if (reversed)
				for (int i = 1; i + 1 < axis1.size(); ++i) axis1[i] *= -1;
		}
		inline void merge (int x, int y)
		{
//			cerr << id << ' ' << x << ' ' << y << " Merge\n";
			if (!tree.count(x))
			{
				tree[x] = tree[y];
				S[x].insert(id);
			}
			else
			{
//				tree[x]->print(0, m); cerr << "\n";
//				tree[y]->print(0, m); cerr << "\n";
				tree[x] = node::merge(0, m, tree[x], tree[y]);
			}
			tree.erase(y);
		}
		inline void _split (int x, int v, int a, int b)
		{
			node *ra, *rb;
//			fprintf(stderr, "Split %d->%d %d k=%d: \n", x, a, b, v);
//			tree[x]->print(0, m); fputs("\n", stderr);
			tree[x]->split(0, m, v, ra, rb);
//			if (ra != node::nil) ra->print(0, m); fputs("\n", stderr);
//			if (rb != node::nil) rb->print(0, m); fputs("\n", stderr);
			if (ra != node::nil) tree[a] = ra, S[a].insert(id);
			if (rb != node::nil) tree[b] = rb, S[b].insert(id);
			tree.erase(x);
		}
		inline void split (int id, int dim, int value, int a, int b)
		{
			int pos = value;
			if (dim == 0)
				pos = upper_bound(axis0.begin(), axis0.end(), value) - axis0.begin() - 1;
			else if (!reversed)
				pos = upper_bound(axis1.begin(), axis1.end(), value) - axis1.begin() - 1;
			else
			{
				pos = lower_bound(axis1.begin(), axis1.end(), -value) - axis1.begin() - 1;
				swap(a, b);
			}
			_split(id, pos, a, b);
		}
		inline void query (int x, int &maxv, int &minv, LL &sum)
		{
			node *t = tree[x];
			sum += t->sumt;
			maxv = max(maxv, t->maxt);
			minv = min(minv, t->mint);
		}
		inline void add (int x, LL delt)
		{
			tree[x]->add(delt);
		}
	} B[sqN];

	int q, cid, bcnt;

	namespace LIS
	{
		int d[N];
		int solve (int value[], int n, int f[], int pre[])
		{
			fill(d, d + 1 + n, 0);
			int res = 1;
			for (int i = 1; i <= n; ++i)
			{
				int lo = 0, hi = n;
				while (lo + 1 != hi) // [lo, hi)
				{
					int mi = (lo + hi) >> 1;
					if (d[mi] && value[d[mi]] < value[i]) lo = mi;
					else hi = mi;
				}
				pre[i] = d[lo];
				f[i] = lo + 1;
				d[lo + 1] = i;
				if (f[i] >= f[res]) res = i;
			}
			return res;
		}
	}

	namespace SPLIT
	{
		int tvalue[2][N], tf[2][N], tpre[2][N], removed[N], orig[N], que[N];
		void solve ()
		{
			sort(A + 1, A + 1 + n);
			while (true)
			{
				int m = 0;
				for (int i = 1; i <= n; ++i)
				{
					if (!removed[i])
					{
						++m;
						orig[m] = i;
						tvalue[0][m] = A[i].first.second;
						tvalue[1][m] =-A[i].first.second;
					}
				}
				if (! m) break;
				int last[2] = {
					LIS::solve(tvalue[0], m, tf[0], tpre[0]),
					LIS::solve(tvalue[1], m, tf[1], tpre[1])
				};
				int z = tf[1][last[1]] > tf[0][last[0]], qc = 0;
				for (int i = last[z]; i; i = tpre[z][i])
					removed[que[++qc] = orig[i]] = 1;
			
				++bcnt;	
				B[bcnt].init(que, qc, bcnt);
			}
		}
	}

	int solve ()
	{
		scanf("%d", &n);
		for (int i = 1, x, y; i <= n; ++i)
		{
			scanf("%d%d%d", &x, &y, W +i);
			A[i] = make_pair(pi(x, y), i);
		}
		cid = n;
		
		node::init();
		SPLIT::solve();

		scanf("%d", &q);
		for (int _ = 1; _ <= q; ++_)
		{
			char op[20];
			int x, y, z;
			scanf("%s%d", op, &x);
			if (op[0] == 'M') // Merge x y
			{
				scanf("%d", &y);
				for (int p : S[y])
					B[p].merge(x, y);
				S[y].clear();
			}
			else if (op[0] == 'S') // Split x d v
			{
				scanf("%d%d", &y, &z);
				for (int p : S[x])
					B[p].split(x, y, z, cid + 1, cid + 2);
				S[x].clear();
				assert(S[cid + 1].size() && S[cid + 2].size());
				cid += 2;
			}
			else if (op[0] == 'A') // Add x d
			{
				scanf("%d", &y);
				for (int p : S[x])
					B[p].add(x, y);
			}
			else if (op[0] == 'Q') // Query x
			{
				int rx = -inf, rn = inf;
				LL rs = 0;
				for (int p : S[x])
					B[p].query(x, rx, rn, rs);

				printf("%d %d %lld\n", rx, rn, rs);
			}
			else assert(false);
		}
		return 0;
	}
}

int main ()
{
#ifdef LOCAL
	freopen("in", "r", stdin);
#endif
	TOPL::solve();
	cerr << node::NCr - node::NBf << endl;
	return 0;
}


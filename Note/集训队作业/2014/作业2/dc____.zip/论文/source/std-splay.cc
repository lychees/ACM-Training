#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
const int LIM = int(1e6), intMax = ~0u >> 2, intMin = -intMax;

struct node {
	static node *nil, *cur, T[LIM];
	node *f, *c[2];
	int s, w, maxw, minw, tag, maxt, mint, delt;
	LL sumt;
	node () {}
	inline int ty () { return this == f->c[1]; }
	inline void sc (node *t, int k) { c[k] = t; if (t != nil) t->f = this; }
	inline void cut (int k) { c[k]->f = nil; c[k] = nil; }
	inline void update () {
		assert(this != nil && !delt);
		s = c[0]->s + c[1]->s + 1;
		maxw = max(c[1]->maxw, w);
		minw = min(c[0]->minw, w);
		sumt = c[0]->sumt + c[1]->sumt + tag;
		maxt = max(max(c[0]->maxt, c[1]->maxt), tag);
		mint = min(min(c[0]->mint, c[1]->mint), tag);
	}
	inline void add (int d) {
		sumt += (LL)s * d;
		delt += d, tag += d;
		mint += d, maxt += d;
	}
	inline void push () {
		if (delt) {
			if (c[0] != nil) c[0]->add(delt);
			if (c[1] != nil) c[1]->add(delt);
			delt = 0;
		}
	}
	inline void zig () {
		int w = this->ty(); node *y = f;
		y->sc(c[!w], w);
		if (y->f != nil) y->f->sc(this, y->ty());
		else f = y->f;
		sc(y, !w); y->update();
	}
	inline node* splay (node *y) {
		static node* s[LIM];
		int top = 0;
		for (node *t = this; t != y; t = t->f) s[top++] = t;
		for (y->push(); top; s[--top]->push()) ;
		for (; f != y; zig()) if (f->f != y)
			if (ty() == f->ty()) f->zig(); else zig();
		update();
		return this;
	}
	static node* find (node *t, int v)
	{
		if (t->minw > v) return nil;
		for (node *r = t; r != nil; )
		{
			if (v < r->w) r = r->c[0];
			else if (v < r->c[1]->minw) { t = r; break; }
			else r = r->c[1];
		}
		t->splay(nil);
		return t;
	}
	static void split (node *t, int v, node *&retl, node *&retr)
	{
		retl = find(t, v);
		if (retl == nil) retr = t;
		else
		{
			retr = retl->c[1];
			retl->cut(1); retl->update();
		}
		//  dump(retl); dump(retr);
		//  assert(retl->maxw <= v && retr->minw > v);
		//  assert(retl->f == nil && retr->f == nil);
	}
	static node* merge (node *x, node *y)
	{
		node *ret = nil;
		//  assert(x && y && x->f == nil && y->f == nil);
		while (x != nil && y != nil)
		{
			//  dump(x); fputs("\n", stderr);
			//  dump(y); fputs("\n", stderr);
			if (x->minw > y->minw) swap(x, y);
			if (x->maxw < y->minw)
			{
				node *r = find(x, x->maxw);
				r->sc(y, 1); r->update();
				x = nil; y = r;
				break;
			}
			node *tl, *tr;
			split(x, y->minw, tl, tr);
			(x = find(tl, tl->maxw))->sc(y, 1);
			x->update();
			y = tr;
		}
		ret = x == nil ? y : x;
		// dump(ret); fputs("\n\n", stderr);
		// assert(ret->f == nil && ret->f == nil);
		return ret;
	}
	static node* newLeaf (int w, int t) {
		cur->f = cur->c[0] = cur->c[1] = nil;
		cur->w = w; cur->tag = t; cur->update();
		return cur++;
	}
	static void init () {
		nil = T;
		nil->f = nil->c[0] = nil->c[1] = nil;
		nil->s = 0;
		nil->maxw = nil->maxt = intMin;
		nil->minw = nil->mint = intMax;
		cur = T + 1;
	}/*
		static void dump (node* t) {
		if (t == nil) return;
		assert(t->c[0] == nil || t->c[0]->f == t && t->c[0]->w < t->w); dump(t->c[0]);
		fprintf(stderr, "x%d n%d w%d\t", t->maxw, t->minw, t->w);
		assert(t->c[1] == nil || t->c[1]->f == t && t->c[1]->w > t->w); dump(t->c[1]);
		assert(t->s == t->c[0]->s + t->c[1]->s + 1);
		}*/
} *node::nil, node::T[LIM], *node::cur;

namespace TOPL
{

	const int sqN = 700, N = int(1e6);

	typedef pair<int, int> pi;
#define Px first
#define Py second

	int W[N];
	pair<pi, int> A[N];
	set<int> S[N << 1];
	int n;

	struct Block {
		unordered_map<int, node*> tree;
		map<int, int> d01, d10;
		int reversed, id;
		void init (int que[], int qc, int id)
		{
			this->id = id;
			for (int i = 1; i <= qc; ++i)
			{
				int u = que[i];
				//  printf("(%d, %d) ", A[u].Px.Px, A[u].Px.Py);
				d01[A[u].Px.Px] = A[u].Px.Py;
				d10[A[u].Px.Py] = A[u].Px.Px;
				S[A[u].Py].insert(id);
				tree[A[u].Py] = node::newLeaf(A[u].Px.Py, W[A[u].Py]);
			}
			//puts("");
			reversed = d01.begin()->Py > d01.rbegin()->Py;
			if (reversed)
			{
				d01[intMin] = d10[intMin] = intMax;
				d01[intMax] = d10[intMax] = intMin;
			}
			else
			{
				d10[intMin] = d01[intMin] = intMin;
				d10[intMax] = d01[intMax] = intMax;
			}
		}
		inline void merge (int x, int y)
		{
			if (!tree.count(x))
			{
				tree[x] = tree[y];
				S[x].insert(id);
			}
			else tree[x] = node::merge(tree[x], tree[y]);
			tree.erase(y);
		}
		inline void _split (int x, int v, int a, int b)
		{
			node *ra, *rb;
			node::split(tree[x], v, ra, rb);
			if (ra != node::nil) tree[a] = ra, S[a].insert(id);
			if (rb != node::nil) tree[b] = rb, S[b].insert(id);
			tree.erase(x);
		}
		inline void split (int id, int dim, int value, int a, int b)
		{
			int pos = value;
			if (dim == 0)
			{
				__typeof(d01.begin()) it = d01.lower_bound(value);
				if (it->first != value) --it;
				if (reversed)
				{
					pos = (++it)->second;
					swap(a, b);
				}
				else
					pos = it->second;
			}
			_split(id, pos, a, b);
		}
		inline void query (int x, int &maxv, int &minv, LL &sum)
		{
			node *t = tree[x];
			sum += t->sumt;
			maxv = max(maxv, t->maxt);
			minv = min(minv, t->mint);
		}
		inline void add (int x, LL delt)
		{
			tree[x]->add(delt);
		}
	} B[sqN];
	
	int q, cid, bcnt;

	namespace LIS
	{
		int d[N];
		int solve (int value[], int n, int f[], int pre[])
		{
			fill(d, d + 1 + n, 0);
			int res = 1;
			for (int i = 1; i <= n; ++i)
			{
				int lo = 0, hi = n;
				while (lo + 1 != hi) // [lo, hi)
				{
					int mi = (lo + hi) >> 1;
					if (d[mi] && value[d[mi]] < value[i]) lo = mi;
					else hi = mi;
				}
				pre[i] = d[lo];
				f[i] = lo + 1;
				d[lo + 1] = i;
				if (f[i] >= f[res]) res = i;
			}
			return res;
		}
	}

	namespace SPLIT
	{
		int tvalue[2][N], tf[2][N], tpre[2][N], removed[N], orig[N], que[N];
		void solve ()
		{
			sort(A + 1, A + 1 + n);
			while (true)
			{
				int m = 0;
				for (int i = 1; i <= n; ++i)
				{
					if (!removed[i])
					{
						++m;
						orig[m] = i;
						tvalue[0][m] = A[i].first.second;
						tvalue[1][m] =-A[i].first.second;
					}
				}
				if (! m) break;
				int last[2] = {
					LIS::solve(tvalue[0], m, tf[0], tpre[0]),
					LIS::solve(tvalue[1], m, tf[1], tpre[1])
				};
				int z = tf[1][last[1]] > tf[0][last[0]], qc = 0;
				for (int i = last[z]; i; i = tpre[z][i])
					removed[que[++qc] = orig[i]] = 1;
			
				++bcnt;	
				B[bcnt].init(que, qc, bcnt);
			}
		}
	}

	int solve ()
	{
		scanf("%d", &n);
		for (int i = 1, x, y; i <= n; ++i)
		{
			scanf("%d%d%d", &x, &y, W +i);
			A[i] = make_pair(pi(x, y), i);
		}
		cid = n;
		
		node::init();
		SPLIT::solve();

		scanf("%d", &q);
		for (int _ = 1; _ <= q; ++_)
		{
			char op[20];
			int x, y, z;
			scanf("%s%d", op, &x);
			if (op[0] == 'M') // Merge x y
			{
				scanf("%d", &y);
				for (int p : S[y])
					B[p].merge(x, y);
				S[y].clear();
			}
			else if (op[0] == 'S') // Split x d v
			{
				scanf("%d%d", &y, &z);
				for (int p : S[x])
					B[p].split(x, y, z, cid + 1, cid + 2);
				S[x].clear();
				assert(S[cid + 1].size() && S[cid + 2].size());
				cid += 2;
			}
			else if (op[0] == 'A') // Add x d
			{
				scanf("%d", &y);
				for (int p : S[x])
					B[p].add(x, y);
			}
			else if (op[0] == 'Q') // Query x
			{
				int rx = intMin, rn = intMax;
				LL rs = 0;
				for (int p : S[x])
					B[p].query(x, rx, rn, rs);

				printf("%d %d %lld\n", rx, rn, rs);
			}
			else assert(false);
		}
	//	cerr << bcnt << endl;
		return 0;
	}
}

int main ()
{
#ifdef LOCAL
	freopen("in", "r", stdin);
#endif
	TOPL::solve();
	return 0;
}


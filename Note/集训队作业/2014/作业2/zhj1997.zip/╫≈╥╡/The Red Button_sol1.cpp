#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#define N 120000
using namespace std;
int ans[N],fa[N],i,j,k,l,n,m,n2;
int get(int x){
	return fa[x]==x?x:(fa[x]=get(fa[x]));
}
int main(){
	scanf("%d",&n);
	if(n&1)return puts("-1"),0;
	for(i=0;i<n;++i)fa[i]=i;
	n2=n/2;
	for(i=0;i<n2;++i){
		ans[i]=i*2;
		ans[i+n2]=i*2+1;
		fa[get(i)]=get(i*2);
		fa[get(i+n2)]=get(i*2+1);
	}
	for(i=0;i<n2;++i)if(get(i)!=get(i+n2)){
		swap(ans[i],ans[i+n2]);
		fa[get(i)]=get(i+n2);
	}
	for(i=0;;){
		printf("%d ",i);
		i=ans[i];
		if(!i)break;
	}
	printf("0\n");
}
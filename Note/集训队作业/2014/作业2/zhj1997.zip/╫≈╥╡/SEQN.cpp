#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<iostream>
#define int64 long long
using namespace std;
int64 a[120],b[120],c[120],tmp,i,j,k,n,m,fac[120000],tot,phi,x,y,z,ans,f[120000];
int T,tim;
int64 pow(int64 x,int64 y,int64 p){
	int64 res=1;
	while(y){
		if(y&1)res=res*x%p;
		x=x*x%p;
		y/=2;
	}
	return res;
}
int64 calc(int64 n,int64 &x){
	int64 res=1;
	if(n==0)return 1;
	res=res*pow(fac[b[i]],n/b[i],b[i])%b[i];
	res=res*fac[n%b[i]]%b[i]*calc(n/a[i],x)%b[i];
	x+=n/a[i];
	return res;
}
void getC(){
	tmp=m;
	tot=0;
	for(i=2;i*i<=tmp;++i)if(tmp%i==0){
		a[++tot]=i;
		b[tot]=1;
		while(tmp%i==0){
			tmp/=i;
			b[tot]*=i;
		}
	}
	if(tmp!=1)a[++tot]=b[tot]=tmp;
	for(i=1;i<=tot;++i){
		for(j=1;j<=b[i];++j){
			if(j%a[i]==0)fac[j]=fac[j-1];
			else fac[j]=fac[j-1]*j%b[i];
		}
		x=y=z=0; phi=b[i]/a[i]*(a[i]-1);
		c[i]=calc(n,x)*pow(calc(k,y),phi-1,b[i])%b[i]*
			 pow(calc(n-k,z),phi-1,b[i])%b[i]*pow(a[i],x-y-z,b[i])%b[i];
	}
	ans=0;
	for(i=1;i<=tot;++i){
		tmp=b[i]/a[i]*(a[i]-1);
		x=pow(m/b[i],tmp-1,b[i]);
		ans=(ans+m/b[i]*x%m*c[i])%m;
	}
//	printf("C(%I64d,%I64d)=%I64d(%% %I64d)\n",n,k,ans,m);
}
int64 getT(){
	n-=k;
	f[1]=0; if(n/m*m%2==0)f[0]=1;else f[0]=m-1;
	for(i=2;i<=n%m;++i)f[i]=(f[i-1]+f[i-2])*(i-1)%m;
	return f[n%m];
}
int main(){
	fac[0]=1;
	for(scanf("%d",&T);T;T--){
		cin>>n>>k>>m;
		tim++;
		getC();
		printf("Case %d: %lld\n",tim,ans*getT()%m);
	}
}

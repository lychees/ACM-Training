#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
int f[120000],i,n,q[120000],tot;
void dfs(int x){
	f[x]=1;
	if(!f[x*2%n])dfs(x*2%n);
	if(!f[(x*2+1)%n])dfs((x*2+1)%n);
	q[++tot]=x;
}
int main(){
	scanf("%d",&n);
	if(n&1)return puts("-1"),0;
	dfs(0);
	printf("0");
	for(;tot--;)printf(" %d",q[tot]);
	for(;;);
}

#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctime>
#define sqr(x) (x)*(x)
using namespace std;
struct point{
	double x,y,z;
}a[1200],b[1200],o,v1,v2,v;
const point O={0,0,0};
int n,m,i,j,k,x,y;
double len,l,R,tmp[1200];
double dist(const point &a,const point &b){
	return sqrt(sqr(a.x-b.x)+sqr(a.y-b.y)+sqr(a.z-b.z));
}
void work(double a,double b,double c,double d,double e,double f){
	o.y=(c*d-a*f)/(e*a-b*d);
	o.x=(c*e-f*b)/(d*b-a*e);
}
int main(){
	srand(time(0));
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;++i)scanf("%lf%lf%lf",&a[i].x,&a[i].y,&a[i].z);
	for(i=1;i<=m;++i){
		scanf("%lf%lf%lf",&v.x,&v.y,&v.z);
		len=dist(O,v);
		for(j=1;j<=n;++j){
			l=((a[j].x*v.x+a[j].y*v.y+a[j].z*v.z)/len)/len;
			b[j].x=a[j].x-v.x*l;
			b[j].y=a[j].y-v.y*l;
			b[j].z=a[j].z-v.z*l;
		}
		if(v.z<1e-9){
			bool flag=0;
			if(v.x>1e-9)flag=1;
			for(j=1;j<=n;++j)swap(b[j].z,flag?b[j].x:b[j].y);
			swap(v.z,flag?v.x:v.y);
		}
		random_shuffle(b+1,b+n+1);
		for(j=1;j<=n;++j)tmp[j]=sqr(b[j].x)+sqr(b[j].y)+sqr(b[j].z);
		R=0;
		for(j=2;j<=n;++j)if(dist(o,b[j])>R+1e-9){
			o=b[j]; R=0;
			for(x=1;x<j;++x)if(dist(o,b[x])>R+1e-9){
				o.x=(b[j].x+b[x].x)/2;
				o.y=(b[j].y+b[x].y)/2;
				o.z=(b[j].z+b[x].z)/2;
				R=dist(o,b[j]);
				for(y=1;y<x;++y)if(dist(o,b[y])>R+1e-9){
					double t1=-v.x/v.z,t2=-v.y/v.z;
					work(-2*b[j].x-2*b[j].z*t1 +2*b[x].x+2*b[x].z*t1 , -2*b[j].y-2*b[j].z*t2 +2*b[x].y+2*b[x].z*t2 , tmp[j]-tmp[x],
						 -2*b[j].x-2*b[j].z*t1 +2*b[y].x+2*b[y].z*t1 , -2*b[j].y-2*b[j].z*t2 +2*b[y].y+2*b[y].z*t2 , tmp[j]-tmp[y]);
					o.z=t1*o.x+t2*o.y;
					R=dist(o,b[j]);
				}
			}
		}
		printf("%.9lf\n",R);
	}
}
#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;
int A,B,pf,pj,pb,C,x;
bool check(int pa,int pb,int pc,int a,int b,int c,int d){
	// a for pa-1,pc-1 ; b for pb-1,pc-1 ; c for a or b(full) ; d=c(not full)
	if(pa<0 || pb<0 || pc<0)return 0;
	if(pc==pa+pb && pa+pb>=c && pa<=a+c+d && pb<=b+c+d && pa+pb<=a+b+c+d)return 1;
	return 0;
}
class TheBoringGameDivOne {
public:
	vector <int> find(int scoreJ, int killedJ, int scoreB, int killedB, int scoreF, int killedF) {
		int minn=1e9,maxx=-1e9;
		for(x=0;x<=1000;++x){
			A=killedB-x;
			B=killedJ-x;
			C=killedF-A-B;
			if(A<0 || B<0 || C<0)continue;
			pf=A+B+C+x*2;
			pj=A+C;
			pb=B+C;
			if(check(pj-scoreJ,pb-scoreB,pf-scoreF,A,B,C,x))minn=min(minn,x+killedF),maxx=max(maxx,x+killedF);
		}
		vector <int> ans;
		if(minn==1e9)return ans;
		ans.push_back(minn);
		ans.push_back(maxx);
		return ans;
	}
};


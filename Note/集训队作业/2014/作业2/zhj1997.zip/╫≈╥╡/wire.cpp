#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cstdio>
#include<assert.h>
#include<map>
#define int64 long long
#define N 110
#define M 1410
using namespace std;
const int64 inf=1ll<<60;
struct ppp{
	int64 x,y,z;
	friend bool operator <(const ppp &a,const ppp &b){
		if(a.x==b.x){
			if(a.y==b.y)return a.z<b.z;
			return a.y<b.y;
		}
		return a.x<b.x;
	}
	friend ppp operator -(const ppp &a,const ppp &b){
		ppp res={a.x-b.x,a.y-b.y,a.z-b.z};
		return res;
	}
	void print(){
		printf("%I64d %I64d %I64d\n",x,y,z);
	}
/*	friend bool operator ==(const ppp &a,const ppp &b){
		return a.x==b.x && a.y==b.y && a.z==b.z;
	}*/
};
int64 next[M*2],e[M*2],c[M*2],len,head[N],bfs[N*100],dis[N],X[M],Y[M],A[M],B[M],C[M],
	s,t,m,n,fans,cnt,V[M],tim;
map<pair<ppp,ppp> ,bool>MAP;
int64 dot(const ppp &a,const ppp &b){
	return a.x*b.x+a.y*b.y+a.z*b.z;
}
ppp det(const ppp &a,const ppp &b){
	ppp res={a.y*b.z-a.z*b.y , a.z*b.x-a.x*b.z , a.x*b.y-a.y*b.x};
	return res;
}
ppp mk(int64 x_,int64 y_,int64 z_){
	ppp res={x_,y_,z_};
	return res;
}
void addedge(int64 x,int64 y,int64 k){
	next[++len]=head[x]; head[x]=len; e[len]=y; c[len]=k;
	next[++len]=head[y]; head[y]=len; e[len]=x; c[len]=k;
}
bool build(){
	int64 l,r,x,i;
	memset(dis,0,sizeof(dis));
	dis[s]=1;
	bfs[l=r=1]=s;
	while(l<=r){
		x=bfs[l++];
		for(i=head[x];i;i=next[i])if(!dis[e[i]] && c[i]){
			dis[e[i]]=dis[x]+1;
			if(e[i]==t)return 1;
			bfs[++r]=e[i];
		}
	}
	return 0;
}
int64 dinic(int64 x,int64 v){
	int64 flow=0,i;
	if(x==t)return v;
	for(i=head[x];i;i=next[i])if(dis[e[i]]==dis[x]+1 && c[i]){
		int64 tmp=dinic(e[i],min(v-flow,c[i]));
		c[i]-=tmp;		c[i^1]+=tmp;
		flow+=tmp;
		if(flow==v)return flow;
	}
	dis[x]=-1;
	return flow;
}
void calc(ppp v,ppp &ans){
	int64 i,j;
	memset(head,0,sizeof(head));
	len=1;
	ans.x=ans.y=ans.z=0;
	for(i=1;i<=m;++i){
		V[i]=dot(v,mk(A[i],B[i],C[i]));
		if(V[i]>=0)addedge(X[i],Y[i],V[i]);
		else{
			ans.x+=A[i];
			ans.y+=B[i];
			ans.z+=C[i];
		}
	}
	while(build()) dinic(s,inf);
	for(i=1;i<=m;++i)if(V[i]>=0 &&  ((dis[X[i]]>0)^(dis[Y[i]]>0)==1) ){
		ans.x+=A[i];
		ans.y+=B[i];
		ans.z+=C[i];
	}
//	if(ans.x*ans.y*ans.z==1125899906842624ll)printf("*");
	fans=min(fans,ans.x*ans.y*ans.z);
/*	if(ans.x*ans.y*ans.z==0){
		printf("%d %d %d\n",ans.x,ans.y,ans.z);
		for(i=1;i<=n;++i)printf("%d ",dis[i]);
		puts("");
	}*/
	return;
}
/*bool check(ppp a,ppp b,ppp c,ppp d){	//���d��a,b,cƽ���ͶӰ�Ƿ���a,b,c�������� 
	ppp bb=b-a,dd=d-a,aa=det(bb,c);
	if(1ll*aa.x*dd.x+1ll*aa.y*dd.y+1ll*aa.z*dd.z>0){
		return 1;
	}
	return 0;
}*/
void work(ppp r1,ppp r2,ppp r3){
	if(MAP[make_pair(r1,r2)])return;
	ppp tmp,vf;
	int flag=0;
	for(;;){
		vf=det(r2-r1,r3-r1);
		calc(vf,tmp);
		if(dot(vf,r3)==dot(vf,tmp))break;
		r3=tmp;
		flag++;
	}
	if(!flag)return;
/*	r1.print();
	r2.print();
	r3.print();
	puts("*****");*/
	MAP[make_pair(r1,r2)]=1;
	MAP[make_pair(r2,r3)]=1;
	MAP[make_pair(r3,r1)]=1;
	cnt++;
	work(r3,r2,r1);
	work(r1,r3,r2);
}
int main(){
	freopen("wire.in","r",stdin);
	freopen("wire.out","w",stdout);
	while(scanf("%I64d%I64d%I64d%I64d",&n,&m,&s,&t)!=EOF){
		for(int i=1;i<=m;++i)scanf("%I64d%I64d%I64d%I64d%I64d",&X[i],&Y[i],&A[i],&B[i],&C[i]);
		MAP.clear();
		fans=inf;
		ppp r1,r2,r3;
		r1=mk(0,0,1000001);
		r2=mk(1000001,0,1000001);
		r3=mk(1000001,1000001,1000001);
	/*	r1=mk(0,0,1000001);
		r2=mk(0,1000001,0);
		r3=mk(1000001,0,0);*/
		work(r1,r2,r3);
		printf("%I64d\n",fans);
	}
}

#include <cstdio>

const int MAXN = 1111;

bool a[MAXN][MAXN], b[MAXN], c[MAXN];
int n, cnt[2];

int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        scanf(" ");
        for (int j = 0; j < n; ++j) {
            b[i] ^= a[i][j] = getchar() - 48;
            c[j] ^= a[i][j];
        }
    }
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            ++cnt[b[i] ^ c[j] ^ a[i][j]];
    printf("%d\n", cnt[0] < cnt[1] ? cnt[0] : cnt[1]);
    return 0;
}

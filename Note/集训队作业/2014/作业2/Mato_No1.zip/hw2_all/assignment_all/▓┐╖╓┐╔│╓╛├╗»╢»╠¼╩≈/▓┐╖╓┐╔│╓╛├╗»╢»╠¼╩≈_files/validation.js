﻿var Validation = {};
Validation.refresh = function () {
    $('span.field-validation-valid').each(function () {
        var cgroup = $(this);
        while (cgroup.length > 0 && !cgroup.hasClass('control-group'))
            cgroup = cgroup.parent();
        if (cgroup.hasClass('control-group')) {
            cgroup.removeClass('error');
        }
    })
    $('span.field-validation-error').each(function () {
        var cgroup = $(this);
        while (cgroup.length > 0 && !cgroup.hasClass('control-group'))
            cgroup = cgroup.parent();
        if (cgroup.hasClass('control-group')) {
            cgroup.addClass('error');
        }
    })
};

Validation.init = function () {
    $('span.field-validation-valid, span.field-validation-error').each(function () {
        if ($(this).prev().hasClass('input-block-level')) {
            $(this).addClass('help-block');
        } else {
            $(this).addClass('help-inline');
        }
    });
    Validation.refresh();
};

$(Validation.init);
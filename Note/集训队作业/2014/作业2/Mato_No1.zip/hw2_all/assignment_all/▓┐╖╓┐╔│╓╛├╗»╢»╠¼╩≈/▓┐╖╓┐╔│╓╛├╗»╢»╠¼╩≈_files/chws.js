"use strict";
function CHWS(arg) {
	if (!window.WebSocket) {
		console.warn('No Web Socket Support');
		return;
	}

	console.assert(arg);
	console.assert(arg.channel);

	this.sock = new WebSocket(CHWS.SOCKET_URL + '?channel='
			+ encodeURIComponent(arg.channel));
	if (arg.onopen)
		this.sock.onopen = arg.onopen;
	if (arg.onclose)
		this.sock.onclose = arg.onclose;

	if (arg.onmessage)
		this.sock.onmessage = function(msg) {
			var data = JSON.parse(msg.data);
			arg.onmessage(data);
		};
	if (arg.onerror)
		this.sock.onerror = arg.onerror;
}

CHWS.SOCKET_URL = location.protocol.replace(/^http/, 'ws') + '//'
		+ location.host + $('meta[name=ch-root]').attr('content')
		+ '/api/websocket';

CHWS.prototype.send = function(data) {
	this.sock.send(data);
};
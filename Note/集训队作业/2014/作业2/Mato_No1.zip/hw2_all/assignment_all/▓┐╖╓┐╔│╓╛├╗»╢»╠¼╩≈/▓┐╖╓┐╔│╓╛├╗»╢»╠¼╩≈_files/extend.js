var CHListLink={};
CHListLink.reload=function(){
	$('.ch-list-link > li[data-href]').each(function(){
		var link=$(this).attr('data-href');
		$(this).click(function(){
			location.href=link;
		});
		$(this).removeAttr('data-href');
	})
};

$(CHListLink.reload);
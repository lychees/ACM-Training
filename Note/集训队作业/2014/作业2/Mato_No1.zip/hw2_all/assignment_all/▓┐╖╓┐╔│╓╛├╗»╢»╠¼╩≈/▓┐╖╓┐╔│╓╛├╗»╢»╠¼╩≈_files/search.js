$('#frm-global-search').submit(function(){
    var link=$('meta[name=ch-root]').attr('content')+'/search?q='+encodeURIComponent($('input',this).val());
    var modal=$('<div class="modal" style="bottom:10%; overflow:hidden;"/>')
	        .append($('<iframe style="border:none; width:100%; height:100%;" />')
	            .attr('src',link));
    $('body').append(modal);
    modal.modal();
    return false;
});
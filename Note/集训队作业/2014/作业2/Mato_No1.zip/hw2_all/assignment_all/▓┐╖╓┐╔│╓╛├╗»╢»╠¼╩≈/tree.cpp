#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <set>
#include <algorithm>
using namespace std;
#define re(i, n) for (int i=0; i<n; i++)
#define re1(i, n) for (int i=1; i<=n; i++)
#define re2(i, l, r) for (int i=l; i<r; i++)
#define re3(i, l, r) for (int i=l; i<=r; i++)
#define rre(i, n) for (int i=n-1; i>=0; i--)
#define rre1(i, n) for (int i=n; i>0; i--)
#define rre2(i, r, l) for (int i=r-1; i>=l; i--)
#define rre3(i, r, l) for (int i=r; i>=l; i--)
#define ll long long
const int MAXN = 100010, MAXS = 17, INF = ~0U >> 2;
struct sss2 {
	int x, y;
	sss2 () {}
	sss2 (int _x, int _y): x(_x), y(_y) {}
	bool operator< (sss2 s0) const {return x < s0.x || x == s0.x && y < s0.y;}
};
struct sss3 {
	int x, y, z;
	sss3 () {}
	sss3 (int _x, int _y, int _z): x(_x), y(_y), z(_z) {}
	bool operator< (sss3 s0) const {return x < s0.x || x == s0.x && y < s0.y || x == s0.x && y == s0.y && z < s0.z;}
};
typedef set <sss2>::iterator s2i;
typedef set <sss3>::iterator s3i;
set <sss2> A[MAXN], RC0[MAXN];
set <sss3> RC1[MAXN];
int n, DT[MAXN], B[MAXN], D[MAXN], UP[MAXN][MAXS][2], res;
void prepare()
{
	re(i, n) {B[i] = UP[i][0][0] = i; D[i] = DT[i] = UP[i][0][1] = 0; re2(j, 1, MAXS) UP[i][j][0] = -1; A[i].insert((sss2) {0, i});}
}
void opr0(int u, int v, int tm)
{
	int u_s = B[u], v_s = B[v], sz0 = A[u_s].size(), sz1 = A[v_s].size(), _, No, dep_v = D[v] + DT[v_s] + 1, dep0;
	if (sz0 <= sz1) {
        s2i _j, i_end = A[u_s].end(); UP[u][1][0] = v; UP[u][1][1] = tm;
        re2(i, 2, MAXS) {
            _j = A[u_s].lower_bound((sss2) {(1 << i - 1) - DT[u_s] - dep_v, 0});
            while (_j != i_end && UP[No = _j->y][i][0] == -1) {UP[No][i][0] = UP[UP[No][i - 1][0]][i - 1][0]; UP[No][i][1] = tm; _j++;}
        }
		for (s2i i=A[u_s].begin(); i!=i_end; ) {
			No = i->y; dep0 = i->x + DT[u_s] + dep_v;
			D[No] = _ = dep0 - DT[v_s]; B[No] = v_s; RC1[No].insert((sss3) {tm, v_s, _}); A[v_s].insert((sss2) {_, i->y}); A[u_s].erase(i++);
		}
	} else {
		s2i _j, i_end = A[u_s].end(); UP[u][1][0] = v; UP[u][1][1] = tm; RC0[u_s].insert((sss2) {tm, DT[u_s] += dep_v});
		re2(i, 2, MAXS) {
			_j = A[u_s].lower_bound((sss2) {(1 << i - 1) - DT[u_s], 0});
            while (_j != i_end && UP[No = _j->y][i][0] == -1) {UP[No][i][0] = UP[UP[No][i - 1][0]][i - 1][0]; UP[No][i][1] = tm; _j++;}
        }
		i_end=A[v_s].end();
		for (s2i i=A[v_s].begin(); i!=i_end; ) {
			No = i->y; D[No] = _ = i->x + DT[v_s] - DT[u_s]; B[No] = u_s;
			RC1[No].insert((sss3) {tm, u_s, _}); A[u_s].insert((sss2) {_, i->y}); A[v_s].erase(i++);
		}
	}
}
void opr1(int u, int k, int tm)
{
	res = u;
	rre2(i, MAXS, 1) if (k >= 1 << i - 1) {
		if (UP[res][i][0] == -1 || UP[res][i][1] > tm) {res = -1; return;} else {res = UP[res][i][0]; k -= 1 << i - 1;}
	}
}
void opr2(int u, int tm)
{
	int v0, v1;
	if (RC1[u].empty() || tm < RC1[u].begin()->x) {v0 = u; v1 = 0;} else {
		s3i i = RC1[u].upper_bound((sss3) {tm, INF, INF}); i--;
		v0 = i->y; v1 = i->z;
	}
	if (RC0[v0].empty() || tm < RC0[v0].begin()->x) res = v1; else {
		s2i i = RC0[v0].upper_bound((sss2) {tm, INF}); i--;
		res = v1 + i->y;
	}
}
int main()
{
	int m, __, FF, x, y, z; scanf("%d%d%d", &n, &m, &__); prepare(); res = 0;
	re1(i, m) {
		scanf("%d", &FF); FF = (FF + res) % 3;
		if (!FF) {
			scanf("%d%d", &x, &y); x = (x + res) % n + 1; y = (y + res) % n + 1;
			opr0(--x, --y, i);
		} else if (FF == 1) {
			scanf("%d%d%d", &x, &y, &z); x = (x + res) % m; y = (y + res) % n + 1; z = (z + res) % n;
			opr1(--y, z, x); printf("%d\n", ++res); res *= __;
		} else {
			scanf("%d%d", &x, &y); x = (x + res) % m; y = (y + res) % n + 1;
			opr2(--y, x); printf("%d\n", res); res *= __;
		}
	}
	return 0;
}


﻿(function () {
    function to2bit(num) {
        if (num < 10) return '0' + String(num);
        else return String(num);
    }
    Date.prototype.toHumanString = function () {
        var now = new Date();

        var timePart;
        if (this.getSeconds() == 0 && this.getMinutes() == 0) {
            timePart = to2bit(this.getHours()) + '时';
        } else if (this.getSeconds() == 0) {
            timePart = to2bit(this.getHours()) + ':' + to2bit(this.getMinutes());
        } else {
            timePart = to2bit(this.getHours()) + ':' + to2bit(this.getMinutes()) + ':' + to2bit(this.getSeconds());
        }
        if (this.getYear() != now.getYear()) {
            return this.getFullYear() + '-' + (this.getMonth()+1) + '-' + this.getDate() + ' ' + timePart;
        } else if (this.getMonth() != now.getMonth()) {
            return (this.getMonth()+1) + '月' + this.getDate() + '日 ' + timePart;
        } else if (this.getDate() != now.getDate()) {
            if (this.getDate() == now.getDate() + 1) {
                return '明日 ' + timePart;
            } else if (this.getDate() == now.getDate() - 1) {
                return '昨日 ' + timePart;
            } else {
                return (this.getMonth()+1) + '月' + this.getDate() + '日 ' + timePart;
            }
        } else {
            return timePart;
        }
    };
})();
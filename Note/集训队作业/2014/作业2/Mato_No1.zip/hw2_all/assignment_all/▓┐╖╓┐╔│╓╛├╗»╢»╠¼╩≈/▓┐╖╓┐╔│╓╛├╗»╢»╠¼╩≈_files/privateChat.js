(function () {
    var INITIAL_MSG_COUNT = 20, EACH_SCROLL_COUNT = 10;

    var chatWith;
    var latest, earliest;
    var noEarlier, gettingEarlier;
    var windowFocus = true;

    window.PrivateChat = {
        startChatWith: function (who) {
            if (!$('#privateChatContacts li').filter(function () {
                        return $(this).attr('data-user') == who;
            }).length) {
                var contact;
                $('#privateChatContacts').prepend(contact = user2Contact(who));
                $.getJSON('/api/user/'+encodeURIComponent(who)+'?isOnline', function (data) {
                    if (data) {
                        contact.addClass('online');
                        $('#privateChatDialogTitle').removeClass('offline').addClass('online');
                    }
                });
            }
            return startChatWith(who);
        }
    };

    $(function () {
        registerEvents();
        fetchInitialContacts();
        var chws = new CHWS({
            channel: 'LoginLogout,PrivateChat',
            onopen: setOnline,
            onclose: setOffline,
            onmessage: dealMessage
        });
    });
    function dealMessage(msg) {
        switch (msg.type) {
            case 'login':
                $('#privateChatContacts li').filter(function () {
                    return $(this).attr('data-user') == msg.user
                }).addClass('online');
                if (chatWith == msg.user)
                    $('#privateChatDialogTitle').removeClass('offline').addClass('online');
                break;
            case 'logout':
                $('#privateChatContacts li').filter(function () {
                    return $(this).attr('data-user') == msg.user
                }).removeClass('online');
                if (chatWith == msg.user)
                    $('#privateChatDialogTitle').removeClass('online').addClass('offline');
                break;
            case 'newPrivateMessage':
            	$.getJSON($('meta[name=ch-root]').attr('content')+'/api/chat/private/'+msg.message,function(message){
                    var canShowMsg = chatWith == message.sender || $('meta[name=ch-user]').attr('content') == message.sender;
                    var userKnow = canShowMsg
                            && ($('#privateChat').hasClass('normal') || $('#privateChat').hasClass('large'))
                            && $('#privateChatDialog').hasClass('normal')
                            && windowFocus;
                    if (canShowMsg) {
                        var newLi = msg2Li(message);
                        $('#privateChatMsgs').prepend(newLi);
                        newLi.hide().slideDown();
                    }
                    if (message.sender != $('meta[name=ch-user]').attr('content') && !userKnow) {
                        if (!$('#privateChatContacts li').filter(function () {
                            return $(this).attr('data-user') == message.sender;
                        }).length) {
                            $('#privateChatContacts').prepend(user2Contact(message.sender).addClass('online'));
                        }
                        addNewNotify(message.sender);
                    }
            	});
                break;
        }
    }
    function msg2Li(msg) {
        if (msg.sender == $('meta[name=ch-user]').attr('content')) {
            return $('<li class="me"/>')
                .append($('<div class="privateChatMsgInfo"/>')
                    .append('<span class="privateChatMsgFrom">Me</span> ')
                    .append(formatDate(new Date(msg.time))))
                .append($('<div class="privateChatMsgContent"/>')
                    .html(msg.content));
        } else {
            return $('<li/>')
                .append($('<div class="privateChatMsgInfo"/>')
                    .append('<span class="privateChatMsgFrom">Ta</span> ')
                    .append(formatDate(new Date(msg.time))))
                .append($('<div class="privateChatMsgContent"/>')
                    .html(msg.content));
        }
    }
    function user2Contact(user) {
        var ret = $('<li/>')
                    .attr('data-user', user)
                    .append($('<a href="#"/>')
                        .text(user)
                        .append($('<a style="float:right;" class="close" href="#">&times;</a>')
                            .click(function () {
                                ret.remove();
                                return false;
                            }))
                        .click(startChatWith.bind(null, user)));
        $.getJSON($('meta[name=ch-root]').attr('content')+'/api/user/' + encodeURIComponent(user) , function (data) {
            $('a:first', ret)
                .css('color', data.color)
                .attr('title', data.caption)
                .prepend(' ')
                .prepend($('<img alt="" style="width:20px;height:20px;"/>')
                    .attr('src', data.image + '&s=20'));
        });
        return ret;
    }
    function formatDate(a) {
        return a.toHumanString();
    }

    function registerEvents() {
        // View Control
        $('#lnkHidePrivateChat').click(hidePrivateChat);
        $('#lnkShowPrivateChat').click(showPrivateChat);
        $('#lnkHidePrivateChatDialog').click(hidePrivateChatDialog);
        $('#lnkMaximizePrivateChatDialog').click(maximizePrivateChatDialog);
        $('#lnkNormalizePrivateChatDialog').click(normalizePrivateChatDialog);

        $('#txtPrivateChatMsg').keypress(function (e) {
            if (e.ctrlKey && (e.keyCode == 10 || e.keyCode == 13)) {
                postPrivateChat();
                return false;
            }
        });
        $('#txtPrivateChatSearchContact').keypress(function (e) {
            if (e.keyCode == 10 || e.keyCode == 13) {
                searchContact();
                return false;
            }
        });
        $('#privateChatMsgs').scroll(function () {
            var sumHeight = 0;
            $('#privateChatMsgs > li').each(function () {
                sumHeight += $(this).height();
            });
            if (sumHeight - $('#privateChatMsgs').height() - $('#privateChatMsgs').scrollTop() <= 50) {
                fetchPrivateChatMsg();
            }
        });
        $(window).focus(function () {
            windowFocus = true;
            if (chatWith && ($('#privateChat').hasClass('normal') || $('#privateChat').hasClass('large')))
                removeNotify(chatWith);
        }).blur(function () {
            windowFocus = false;
        });
    }

    // Notify Center
    var notifies = {};
    function addNewNotify(user) {
        if (!Object.keys(notifies).length) {
            setHasNewMsg();
            shakeTitle();
        }
        if (!notifies.hasOwnProperty(user)) {
            playMsgSound();
        }
        notifies[user] = true;
        $('#privateChatContacts li').filter(function () {
            return $(this).attr('data-user') == user;
        }).addClass('newMsg');
    }

    function removeNotify(user) {
        delete notifies[user];
        $('#privateChatContacts li').filter(function () {
            return $(this).attr('data-user') == user;
        }).removeClass('newMsg');
        if (!Object.keys(notifies).length) {
            setHasNotNewMsg();
            stopShakingTitle();
        }
    }

    // View Control
    function hidePrivateChat() {
        $('#privateChat').switchClass('normal', 'hidden', 'slow', function () {
            $('#lnkShowPrivateChat').show();
            $('#privateChatTitle').switchClass('short', 'long');
        });
        return false;
    }
    function showPrivateChat(callback) {
        $('#privateChatTitle').switchClass('long', 'short', function () {
            $('#lnkShowPrivateChat').hide();
            $('#privateChat').switchClass('hidden', 'normal', 'slow', function () {
                if (callback instanceof Function) {
                    callback();
                }
            });
        });
        if (chatWith)
            removeNotify(chatWith);
        return false;
    }
    function hidePrivateChatDialog() {
        $('#privateChatDialog').switchClass('normal', 'hidden');
        chatWith = undefined;
        return false;
    }
    function showPrivateChatDialog(callback) {
        $('#privateChatDialog').switchClass('hidden', 'normal', function () {
            if (callback instanceof Function) {
                callback();
            }
        });
        return false;
    }
    function maximizePrivateChatDialog() {
        $('#privateChat').fadeOut('slow', function () {
            $('#privateChat').removeClass('normal').addClass('large');
            $('#privateChatDialog').css('height', $(window).height() - 100);
            $('#lnkMaximizePrivateChatDialog').hide();
            $('#lnkHidePrivateChat').hide();
            $('#lnkHidePrivateChatDialog').hide();
            $('#lnkNormalizePrivateChatDialog').show();
            $('#privateChat').fadeIn('slow');
        });
        return false;
    }
    function normalizePrivateChatDialog() {
        $('#privateChat').fadeOut('slow', function () {
            $('#privateChat').addClass('normal').removeClass('large');
            $('#privateChatDialog').attr('style', '');
            $('#lnkMaximizePrivateChatDialog').show();
            $('#lnkHidePrivateChat').show();
            $('#lnkHidePrivateChatDialog').show();
            $('#lnkNormalizePrivateChatDialog').hide();
            $('#privateChat').fadeIn('slow');
        });
        return false;
    }
    function setOnline() {
        $('#privateChatTitle').addClass('online').removeClass('offline');
    }
    function setOffline() {
        $('#privateChatTitle').addClass('offline').removeClass('online');
    }
    function setHasNewMsg() {
        $('#privateChatTitle').addClass('newMsg');
    }
    function setHasNotNewMsg() {
        $('#privateChatTitle').removeClass('newMsg');
    }
    function playMsgSound() {
        $('#privateChatMsgSound')[0].play();
    }
    var titleShakeHandle;
    function shakeTitle() {
        if (titleShakeHandle === undefined) {
            titleShakeHandle = setInterval(function () {
                var oldTitle = document.title;
                document.title = '您有新消息了';
                setTimeout(function () { document.title = oldTitle; }, 1000);
            }, 2000);
        }
    }
    function stopShakingTitle() {
        if (titleShakeHandle !== undefined) {
            clearInterval(titleShakeHandle);
            titleShakeHandle = undefined;
        }
    }
    // Actions
    function startChatWith(who, notFirst) {
        if (who == $('meta[name=ch-user]').attr('content')) {
            return;
        }
        if ($('#privateChat').hasClass('hidden')) {
            showPrivateChat(startChatWith.bind(null, who, true));
        } else if ($('#privateChatDialog').hasClass('hidden')) {
            showPrivateChatDialog(startChatWith.bind(null, who, true));
        } else {
            chatWith = who;
            latest = earliest = undefined;
            noEarlier = gettingEarlier = false;
            $('#privateChatDialogTitle span').text(chatWith);
            fetchInitialMsg();
            $('#txtPrivateChatMsg').focus();
        }
        if (notFirst !== true) {
            removeNotify(who);
            if ($('#privateChatContacts li').filter(function () {
                return $(this).attr('data-user') == who;
            }).hasClass('online')) {
                $('#privateChatDialogTitle').removeClass('offline').addClass('online');
            } else {
                $('#privateChatDialogTitle').removeClass('online').addClass('offline');
            }
        }
        return false;
    }
    function searchContact() {
        var toSearch = $('#txtPrivateChatSearchContact').val().trim();
        if (!toSearch) {
            $('#txtPrivateChatSearchContact').val('');
            return;
        }
        if(toSearch.toLowerCase()==$('meta[name=ch-user]').attr('content').toLowerCase()){
        	alert('您好像试图和自己聊天……');
        	return;
        }
        var inList = $('#privateChatContacts li').filter(function () {
            return $(this).attr('data-user').toLowerCase() == toSearch.toLowerCase();
        });
        if (inList.length) {
            $('#txtPrivateChatSearchContact').val('');
            $('a', inList).click();
        } else {
            $('#txtPrivateChatSearchContact').attr('disabled', 'disabled');
            $.getJSON($('meta[name=ch-root]').attr('content')+'/api/user/' + encodeURIComponent(toSearch), function (data) {
                var contact;
                $('#txtPrivateChatSearchContact').removeAttr('disabled');
                $('#privateChatContacts').prepend(contact = user2Contact(data.name));
                $.getJSON($('meta[name=ch-root]').attr('content')+'/api/user/'+encodeURIComponent(data.name)+'?isOnline' , function (data) {
                    if (data) {
                        contact.addClass('online');
                        $('#privateChatDialogTitle').addClass('online').removeClass('offline');
                    }
                });
                startChatWith(data.name);
            }).error(function(){
            	$('#txtPrivateChatSearchContact').removeAttr('disabled');
            	alert('找不到用户' + toSearch + '，请检查用户名是否正确。');
            });
        }
    }
    function postPrivateChat() {
        if (!$('#txtPrivateChatMsg').val().trim()) return;
        $('#txtPrivateChatMsg').attr('disabled', true);
        $.ajax({
            url: $('meta[name=ch-root]').attr('content')+'/api/chat/private',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                content: $('#txtPrivateChatMsg').val(),
                receiver: chatWith
            }),
            success: function () {
                $('#txtPrivateChatMsg').val('');
                $('#txtPrivateChatMsg').removeAttr('disabled');
            },
            error: function () {
                alert('发送消息时出错');
            }
        });
    }
    function fetchInitialContacts() {
        $.getJSON($('meta[name=ch-root]').attr('content')+'/api/chat/private?unread', function (data) {
            data.forEach(function (line) {
                var contact;
                $('#privateChatContacts')
                    .append(contact = user2Contact(line.first));
                for (var i = 0; i < line.second; i++)
                    addNewNotify(line.first);
                $.getJSON($('meta[name=ch-root]').attr('content')+'/api/user/'+encodeURIComponent(line.first)+'?isOnline'  , function (data) {
                    if (data)
                        contact.addClass('online');
                });
            });
        });
    }
    function fetchInitialMsg() {
        $('#privateChatMsgs').html('<li><progress style="width:100%;"/></li>');
        getPrivateChatMsg(0, INITIAL_MSG_COUNT, function (data) {
            $('#privateChatMsgs').html('');
            if (data.length) {
                latest = new Date(data[0].Time);
                earliest = new Date(data[data.length - 1].Time);

                data = data.map(msg2Li);
                $('#privateChatMsgs')
                    .append($('<li style="text-align:center; color:gray;"/>')
                        .text('以下是历史信息'));
                data.forEach(function (line) {
                    $('#privateChatMsgs').append(line);
                });
            } else {
                $('#privateChatMsgs')
                    .html($('<li style="text-align:center; color:gray;"/>')
                        .text('您与Ta没有来往信息'));
            }
        });
    }
    function fetchPrivateChatMsg() {
        if (noEarlier || gettingEarlier) {
            return;
        }
        $('#privateChatMsgs').append('<li><progress style="width:100%;"/></li>');
        gettingEarlier = true;
        getPrivateChatMsg($('#privateChatMsgs > li').length-1, EACH_SCROLL_COUNT, function (data) {
            if (EACH_SCROLL_COUNT != data.length)
                noEarlier = true;
            $('#privateChatMsgs li:last').remove();
            if (data.length) {
                earliest = new Date(data[data.length - 1].Time);
                data = data.map(msg2Li);

                data.forEach(function (line) {
                    $('#privateChatMsgs').append(line);
                    line.hide().slideDown();
                });
            }
            gettingEarlier = false;
        });
    }
    // Server API
    function getPrivateChatMsg(skip, top, callback) {
        $.getJSON($('meta[name=ch-root]').attr('content')+'/api/chat/private',{
        	'with': chatWith,
        	'skip':skip,
        	'top': top,
        	'timestamp': new Date().getTime()
        } , callback);
    }
})();
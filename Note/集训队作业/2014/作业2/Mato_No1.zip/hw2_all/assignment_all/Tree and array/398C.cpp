#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;
#define re(i, n) for (int i=0; i<n; i++)
#define re1(i, n) for (int i=1; i<=n; i++)
#define re2(i, l, r) for (int i=l; i<r; i++)
#define re3(i, l, r) for (int i=l; i<=r; i++)
#define rre(i, n) for (int i=n-1; i>=0; i--)
#define rre1(i, n) for (int i=n; i>0; i--)
#define rre2(i, r, l) for (int i=r-1; i>=l; i--)
#define rre3(i, r, l) for (int i=r; i>=l; i--)
#define ll long long
const int MAXN = 10000, INF = ~0U >> 2;
int n, res = 0;
void init()
{
	scanf("%d", &n);
}
void pri()
{
	if (n == 5) {
		puts("1 2 5\n2 3 4\n1 4 2\n4 5 3\n3 4\n3 5");
	} else if (n == 6) {
		puts("1 2 5\n2 3 1\n1 4 3\n3 5 1\n5 6 5\n3 4\n4 5\n4 6");
	} else if (n & 1) {
		int m = n >> 1;
		printf("1 %d 3\n", m + 1);
		re3(i, 2, m) printf("%d %d 1\n", i, m + i);
		printf("%d %d 2\n%d %d 1\n", m + 1, n, m + 2, n);
		re3(i, 3, m) printf("%d %d %d\n", m + i, n, (i & 1 ? i + 3 : i - 1));
		puts("1 3");
		re2(i, 1, m) printf("%d %d\n", i, i + 1);
	} else {
		int m = n >> 1;
		puts("1 2 1");
		printf("2 %d 3\n", m + 1);
		re2(i, 2, m) printf("%d %d 1\n", i + 1, i + m, 1);
		printf("%d %d 3\n%d %d 1\n", m + 1, n, m + 2, n);
		re2(i, 3, m) printf("%d %d %d\n", m + i, n, (i & 1 ? i + 3 : i - 1));
		puts("1 3\n1 4");
		re2(i, 2, m) printf("%d %d\n", i, i + 1);
	}
}
int main()
{
	init();
	pri();
	return 0;
}


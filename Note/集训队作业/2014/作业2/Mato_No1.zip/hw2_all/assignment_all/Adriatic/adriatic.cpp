#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <map>
#include <utility>
using namespace std;
#define re(i, n) for (int i=0; i<n; i++)
#define re1(i, n) for (int i=1; i<=n; i++)
#define re2(i, l, r) for (int i=l; i<r; i++)
#define re3(i, l, r) for (int i=l; i<=r; i++)
#define rre(i, n) for (int i=n-1; i>=0; i--)
#define rre1(i, n) for (int i=n; i>0; i--)
#define rre2(i, r, l) for (int i=r-1; i>=l; i--)
#define rre3(i, r, l) for (int i=r; i>=l; i--)
#define ll long long
const int MAXN = 250010, m = 2500;
const short INF = 16383;
struct sss {
    short xl, yl, xr, yr;
    bool operator< (sss s0) const {return xl < s0.xl || xl == s0.xl && yl < s0.yl || xl == s0.xl && yl == s0.yl && xr < s0.xr || xl == s0.xl && yl == s0.yl && xr == s0.xr && yr < s0.yr;}
};
typedef map <sss, int>::iterator mi;
map <sss, int> S;
int n, A[MAXN][2], SL[m][m], SR[m][m], SUM[m << 1], res[MAXN];
short L[m][m][2], R[m][m][2], Z[m << 1][4];
void init()
{
	freopen("adriatic.in", "r", stdin);
	scanf("%d", &n);
	re(i, n) {scanf("%d%d", &A[i][0], &A[i][1]); A[i][0]--; A[i][1]--;}
	fclose(stdin);
}
void prepare()
{
    re(i, m) re(j, m) {L[i][j][0] = L[i][j][1] = INF; R[i][j][0] = R[i][j][1] = -INF;}
    int x, y, _;
    re(i, n) {
        L[x = A[i][0]][y = A[i][1]][0] = x;
        L[x][y][1] = y;
        R[x][y][0] = x;
        R[x][y][1] = y;
        SL[x][y]++; SR[x][y]++;
    }
    re(i, m) re(j, m) {
        if (i && (_ = L[i - 1][j][0]) < L[i][j][0]) L[i][j][0] = _;
        if (j && (_ = L[i][j - 1][0]) < L[i][j][0]) L[i][j][0] = _;
        if (i && (_ = L[i - 1][j][1]) < L[i][j][1]) L[i][j][1] = _;
        if (j && (_ = L[i][j - 1][1]) < L[i][j][1]) L[i][j][1] = _;
        if (i && j) SL[i][j] += SL[i - 1][j] + SL[i][j - 1] - SL[i - 1][j - 1];
        else if (i) SL[i][j] += SL[i - 1][j]; else if (j) SL[i][j] += SL[i][j - 1];
    }
    rre(i, m) rre(j, m) {
        if (i < m - 1 && (_ = R[i + 1][j][0]) > R[i][j][0]) R[i][j][0] = _;
        if (j < m - 1 && (_ = R[i][j + 1][0]) > R[i][j][0]) R[i][j][0] = _;
        if (i < m - 1 && (_ = R[i + 1][j][1]) > R[i][j][1]) R[i][j][1] = _;
        if (j < m - 1 && (_ = R[i][j + 1][1]) > R[i][j][1]) R[i][j][1] = _;
        if (i < m - 1 && j < m - 1) SR[i][j] += SR[i + 1][j] + SR[i][j + 1] - SR[i + 1][j + 1];
        else if (i < m - 1) SR[i][j] += SR[i + 1][j]; else if (j < m - 1) SR[i][j] += SR[i][j + 1];
    }
}
void solve()
{
    int _, _1, _2; short x01, y01, x02, y02, _x, _y; sss _s0; mi i0;
    re(i, n) {
        res[i] = n - 1; _ = 0; _1 = 1; x01 = A[i][0] - 1; y01 = A[i][1] - 1; x02 = x01 + 2; y02 = y01 + 2;
        while (1) {
            _s0.xl = x01; _s0.yl = y01; _s0.xr = x02; _s0.yr = y02;
            i0 = S.find(_s0); if (i0 != S.end()) {res[i] += i0->second; break;}
            _++; if (x02 < m && y02 < m) _2 = SR[x02][y02]; else _2 = 0;
            if (x01 >= 0 && y01 >= 0) {
                if (x01 < x02 || y01 < y02) _2 += SL[x01][y01]; else _2 += SL[x01][y02 - 1] + SL[x02 - 1][y01] - SL[x02 - 1][y02 - 1];
            } else _2;
            if (_ == 1) _2++;
            res[i] += n - _2; Z[_][0] = x01; Z[_][1] = y01; Z[_][2] = x02; Z[_][3] = y02; SUM[_] = n - _2; _1 = _2;
            if (_1 == n) break; else {
                if (x01 >= 0 && y01 >= 0 && L[x01][y01][0] < INF) {_x = L[x01][y01][0] + 1; _y = L[x01][y01][1] + 1;} else {_x = x02; _y = y02;}
                if (x02 < m && y02 < m && R[x02][y02][0] > -INF) {x01 = R[x02][y02][0] - 1; y01 = R[x02][y02][1] - 1;}
                x02 = _x; y02 = _y;
            }
        }
        _1 = res[i] - n + 1;
        re2(i, 1, _) {
            _s0.xl = Z[i][0]; _s0.yl = Z[i][1]; _s0.xr = Z[i][2]; _s0.yr = Z[i][3];
            S.insert(make_pair(_s0, _1)); _1 -= SUM[i];
        }
    }
}
void pri()
{
    freopen("adriatic.out", "w", stdout);
    re(i, n) printf("%d\n", res[i]);
    fclose(stdout);
}
int main()
{
	init();
	prepare();
	solve();
	pri();
	return 0;
}

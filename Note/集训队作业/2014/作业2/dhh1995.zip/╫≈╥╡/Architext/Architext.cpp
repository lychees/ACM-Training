#include<cstdio>
#include<map>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
#define rep(i,a,b) for (int i=a;i<b;++i)
typedef long long ll;
#define mk make_pair
const int N=50005,M=400005;
int n,m,R,l,Q,T,son[N],st[M],ed[M],next[M],id[M],num[M],b[M];
int k[N],in[N],c[N],u[N],s[N],f[N],ans[N],ma[N],r[N],q[N],o[M],ox[M],oy[M],oz[M]; bool flag[M];
int *d[N],dd[M],*D=dd,*e[N],ee[M],*E=ee;
bool ask[N]; char opr[5]; double ang[M];
struct node{
	int x,y,z; node(){}
	node(int _x,int _y,int _z):x(_x),y(_y),z(_z){}
	node operator -(const node &A){return node(x-A.x,y-A.y,z);}
	double angle(){return atan2(y+0.,x+0.);}
	void read(){scanf("%d%d%d",&x,&y,&z);}
}a[N];
map<pair<int,int>,int> B;
bool cmp(const int i,const int j){return ang[i]<ang[j];}
int edge(int x,int y)
{
	if (x>y) swap(x,y);
	if (!B.count(mk(x,y))) B[mk(x,y)]=l,st[l]=x,ed[l++]=y,B[mk(y,x)]=l,st[l]=y,ed[l++]=x;
	return B[mk(x,y)];
}
void reg(int i)
{
	int p=i; c[R]=1;
	do{
		if (r[st[p]]<0) r[st[p]]=R;
		b[p]=1,num[p]=R,p^=1,p=next[p]<1?son[-next[p]]:next[p];
	}while (p!=i);
	++R;
}
int get(int x){return f[x]==x?x:get(f[x]);}
void add(int x,int y)
{
	x=get(x),y=get(y);
	if (u[x]>u[y]) swap(x,y);
	if (x!=y) ox[++T]=x,oy[T]=y,oz[T]=c[y],flag[T]=0,
		u[y]+=u[x],f[x]=y,s[y]+=s[x],c[y]=max(c[y],c[x]);
}
void back(int last)
{
	for (int i=T;i>last;--i){
		int x=ox[i],y=oy[i],z=oz[i];
		if (flag[i]) s[y]-=x,c[y]=z;
		else f[x]=x,u[y]-=u[x],s[y]-=s[x],c[y]=z;
	}
	T=last;
}
void ins(int x)
{
	int y=get(r[x]); x=a[x].z,ox[++T]=x,oy[T]=y,oz[T]=c[y],flag[T]=1;
	s[y]+=x,c[y]=max(c[y],x);
}
void work(int,int);
void deal(int l,int r,int l1,int r1,int last)
{
	rep(i,l,r)
		if (!ask[i]){if (!--q[k[i]]) ins(k[i]);}
		else rep(j,0,k[i]){
			if (!--q[d[i][j]]) ins(d[i][j]);
			if (!--o[e[i][j]]) add(st[e[i][j]],ed[e[i][j]]);
		}
	work(l1,r1); back(last);
	rep(i,l,r) if (!ask[i]) ++q[k[i]]; else rep(j,0,k[i]) ++q[d[i][j]],++o[e[i][j]];
}
void work(int l,int r)
{
	if (l+1==r){
		int i=l,x;
		if (ask[i]){
			if (k[i]>2) x=get(in[i]),ans[i]=s[x],ma[i]=c[x]; else ans[i]=ma[i]=0;
			rep(j,0,k[i]) ans[i]+=a[d[i][j]].z,ma[i]=max(ma[i],a[d[i][j]].z);
		}else a[k[i]].z+=*d[i];
		return;
	}
	int mid=l+r>>1,last=T;
	deal(mid,r,l,mid,last),deal(l,mid,mid,r,last);
}
int main()
{
	scanf("%*d%d",&n),l=2; rep(i,0,n) a[i].read(),son[i]=-i; scanf("%d",&Q);
	rep(i,0,Q){
		scanf("%s%d",opr,k+i);
		if (*opr=='A'){
			e[i]=E,d[i]=D,ask[i]=1;
			rep(j,0,k[i]) scanf("%d",D+j),--D[j]; D[k[i]]=*D;
			rep(j,0,k[i]) E[j]=edge(D[j],D[j+1]),++o[E[j]],++q[D[j]];
			E+=k[i],D+=k[i];
		}else ++q[--k[i]],d[i]=D,scanf("%d",D),++D;
	}
	memset(r,-1,sizeof(r));
	rep(i,2,l) ang[i]=(a[ed[i]]-a[st[i]]).angle(),id[i]=i;
	sort(id+2,id+l,cmp); rep(j,2,l){int i=id[j],x=st[i]; next[i]=son[x],son[x]=i;}
	rep(i,2,l) if (!b[i]) reg(i); rep(i,2,l) st[i]=num[i],ed[i]=num[i^1];
	rep(i,0,Q) if (ask[i]) in[i]=ed[B[mk(d[i][0],d[i][1])]];
	rep(i,0,R) u[i]=1,f[i]=i; rep(i,2,l) if (!(i&1) && !o[i]) add(st[i],ed[i]);
	rep(i,0,n) if (!q[i]) ins(i); work(0,Q);
	rep(i,0,Q) if (ask[i]) printf("%d %d\n",ans[i],ma[i]); return 0;
}

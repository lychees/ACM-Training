#include<cstdio>
#define rep(i,n) for (int i=1;i<=n;++i)
int main()
{
	int n,m; scanf("%d",&n),m=n/2;
	rep(i,m-1) printf("%d %d %d\n",i,i+1,(m-i)*2-(i+(n&1)<m));
	rep(i,m) printf("%d %d %d\n",i,i+m,1);
	if (n&1) printf("%d %d %d\n",n-1,n,1);
	rep(i,m-1) printf("%d %d\n",m+i,m+i+1);
	printf("%d %d\n",n-2,n); return 0;
}
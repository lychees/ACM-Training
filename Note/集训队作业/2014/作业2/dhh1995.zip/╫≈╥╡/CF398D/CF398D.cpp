#include<cstdio>
#include<map>
#include<algorithm>
using namespace std;
#define rep(i,n) for (int i=1;i<=n;++i)
#define mk make_pair
const int N=400005;
int n,m,Q,O,p,ans,x[N],y[N],next[N],son[N],d[N],c[N],t[N];
bool o[N]; char opr[5],s[N]; map<pair<int,int>,int> E;
int main()
{
	scanf("%d%d%d",&n,&m,&Q),Q+=m;
	scanf("%d",&O); rep(i,O) scanf("%d",&p),o[p]=1;
	rep(i,Q){
		if (i<=m) s[i]='A'; else scanf("%s",opr),s[i]=*opr;
		if (s[i]=='A' || s[i]=='D')
			scanf("%d%d",x+i,y+i),++d[x[i]],++d[y[i]],t[i]=s[i]=='A'?1:-1;
		else scanf("%d",x+i);
	}
	rep(i,Q){
		if (s[i]=='O'){o[x[i]]=1; for (p=son[x[i]];p;p=next[p]) c[y[p]]+=t[p];}
		else if (s[i]=='F'){o[x[i]]=0; for (p=son[x[i]];p;p=next[p]) c[y[p]]-=t[p];}
		else if (s[i]=='C'){
			for (ans=c[x[i]],p=son[x[i]];p;p=next[p]) ans+=o[y[p]]*t[p];
			printf("%d\n",ans);
		}else{
			if (d[x[i]]>d[y[i]]) swap(x[i],y[i]); c[y[i]]+=o[x[i]]*t[i];
			map<pair<int,int>,int> :: iterator it=E.find(mk(x[i],y[i]));
			if (it==E.end()) E[mk(x[i],y[i])]=i,next[i]=son[x[i]],son[x[i]]=i;
			else t[it->second]+=t[i];
		}
	}
	return 0;
}

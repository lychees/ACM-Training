#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define rep(i,n) for (int i=0;i<n;++i)
const int N=300005;
int f[N],g[N],h[N],n,m,t,x,y,z,v; long long c; bool ans; char opr[5];
int get(int x,int t){while (f[x]>=0 && g[x]<=t) x=f[x]; return x;}
void merge(int x,int y,int t)
{
	x=get(x,t),y=get(y,t);
	if (x!=y){
		if (h[x]>h[y]) swap(x,y);
		f[x]=y,g[x]=t,h[y]+=h[x]==h[y];
	}
}
int main()
{
//	freopen("history.in","r",stdin);
//	freopen("history.out","w",stdout);
	while (scanf("%d%d",&n,&m)!=EOF){
		rep(i,n) h[i]=1,f[i]=-1; t=c=ans=0;
		while (m--){
			scanf("%s",opr);
			if (*opr=='K') scanf("%d",&v),c=c*ans+v,ans=0;
			else{
				scanf("%d%d",&x,&y),x=(c*ans+x)%n,y=(c*ans+y)%n;
				if (*opr=='R') merge(x,y,++t);
				else scanf("%d",&z),z=ans?(c+z)%n:z,
					ans=(get(x,t)==get(y,t))==(get(x,t-z)==get(y,t-z)),puts(ans?"N":"Y");
			}
		}
	}
	return 0;
}

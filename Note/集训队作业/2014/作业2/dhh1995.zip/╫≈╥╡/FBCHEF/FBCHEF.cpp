#include <stdio.h>
#include <stdlib.h>
#define inf 1000000000
#define bit 15
using namespace std;

int opt[100005],a[100005],x[100005];
int w[100005],son[100005],next[200005],ed[200005],fa[100005];
int st[100005],en[100005],dfn;
int n,q,i,j,k,u,v,c,tot,ans,sum;
bool vis[100005];
int l[100005],r[100005],mid[100005],destroyed[100005],now[100005];
int Q[100005],Qnext[100005],Sum[100005];

void dfs(int x)
{
	st[x]=++dfn;
	for(int i=son[x];i;i=next[i])
	if(!st[ed[i]])fa[ed[i]]=x,dfs(ed[i]);
	en[x]=dfn;
}

int head[100005],tail[100005];
struct Link
{
	int next,t;
	int w[bit];
}link[1000005];
int link_tot;

bool finished;

char ch;
void read(int &a)
{
    ch=getchar();while(ch<'0'||ch>'9')ch=getchar();a=ch-'0';
    while(((ch=getchar())>='0')&&(ch<='9'))a*=10,a+=ch-'0';
}

int main()
{
	//freopen("fbchef.in","r",stdin);
	//freopen("fbchef.out","w",stdout);
	read(n);
	for(i=1;i<=n;++i)read(w[i]);
	for(i=1;i<n;++i)
	{
		read(u),read(v);
		++tot;next[tot]=son[u];son[u]=tot;ed[tot]=v;
		++tot;next[tot]=son[v];son[v]=tot;ed[tot]=u;
	}
	read(q);
	for(i=1;i<=q;++i)
	{
		read(opt[i]);
		if(opt[i]==1)read(a[i]),read(x[i]);
		else read(a[i]);
	}
	dfs(1);
	for(i=1;i<=q;++i)
	if(opt[i]==1)
	{
		u=a[i];v=x[i];
		for(;v;v>>=1,u=fa[u])
		{
			++link_tot;
			link[link_tot]=link[tail[u]];
			if(!head[u])head[u]=link_tot;
			else link[tail[u]].next=link_tot;
			tail[u]=link_tot;
			link[link_tot].t=i;
			for(j=0,c=v;c;c>>=1,++j)
			{
				link[link_tot].w[j]+=c;
				if(link[link_tot].w[j]>inf)link[link_tot].w[j]=inf;
			}
		}
	}
	for(i=1;i<=n;++i)l[i]=1,r[i]=q,destroyed[i]=q+1;
	for(;;)
	{
		finished=true;
		for(i=1;i<=q;++i)Q[i]=0;
		for(i=1;i<=n;++i)now[i]=0;
		for(i=1;i<=n;++i)
		if(l[i]<=r[i])
		{
			mid[i]=l[i]+r[i]>>1;
			Qnext[i]=Q[mid[i]];
			Q[mid[i]]=i;
			finished=false;
		}
		if(finished)break;
		for(i=1;i<=q;++i)
		{
			if(opt[i]==1)
			{
				u=a[i];
				for(;u;u=fa[u])
				{
					if(now[u])
					{
						if(link[link[now[u]].next].t==i)
						now[u]=link[now[u]].next;else break;
					}
					else
					{
						if(link[head[u]].t==i)now[u]=head[u];
						else break;
					}
				}
			}
			for(j=Q[i];j;j=Qnext[j])
			{
				sum=0;
				for(u=j,k=0;k<bit;++k,u=fa[u])
				{
					sum+=link[now[u]].w[k];
					if(fa[u]&&k+2<bit)sum-=link[now[u]].w[k+2];
					if(sum>w[j])break;
				}
				if(sum>=w[j])destroyed[j]=mid[j],r[j]=mid[j]-1;
				else l[j]=mid[j]+1;
			}
		}
	}
	for(i=1;i<=q;++i)Q[i]=0;
	for(i=1;i<=n;++i)Qnext[i]=Q[destroyed[i]],Q[destroyed[i]]=i;
	for(i=1;i<=q;++i)
	{
		if(opt[i]==2)
		{
			u=a[i];ans=0;
			for(j=en[u];j>0;j-=j&-j)ans+=Sum[j];
			for(j=st[u]-1;j>0;j-=j&-j)ans-=Sum[j];
			printf("%d\n",ans);
		}
		for(u=Q[i];u;u=Qnext[u])
		for(j=st[u];j<=n;j+=j&-j)
		++Sum[j];
	}
}
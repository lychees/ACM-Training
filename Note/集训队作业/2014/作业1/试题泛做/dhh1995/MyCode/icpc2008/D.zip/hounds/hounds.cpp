#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cstdio>
#include<queue>
#define N 210
using namespace std;
int cp[N],bo[N][370],ncp,nroad,s,t,sd,maxdis,tot,ans[N*1000],ans1,ans2,ncm,
	tim,x,y,dx,dy,i,l,id,k,j,debug[N][370],mark[N][370];
struct ppp{
	int y,dy,l,id;
	void mk(int y_,int dy_,int l_,int id_){
		y=y_; dy=dy_; l=l_; id=id_;
	}
}e[N][370],etmp[N][N];
int getdir(int x,int d){
	int l=d,r=d;
	while(l!=r || l==d){
		if(!bo[x][r] && e[x][r].y)return r;
		if(!bo[x][l] && e[x][l].y)return l;
		l=(l+359)%360;
		r=(r+1)%360;
	}
	if(!bo[x][l] && e[x][l].y)return l;
	return -1;
}
	
	
void work2(int &sx,int &sd){
	int x,d,i,ftot=tot,dis=0,fans1=ans1;
	for(;;){
		x=sx; dis=0;
		sd=getdir(x,sd);	bo[x][sd]=1;  d=sd;
		tot=ftot;  ans1=fans1;
		for(;;){
			if(dis+mark[x][d]<=maxdis){
				ans[++tot]=e[x][d].id;
				ans1+=e[x][d].l;
				ans2+=dis+e[x][d].l;
				sx=e[x][d].y;
				sd=(e[x][d].dy+180)%360;
				return;
			}else dis+=e[x][d].l;
			if(dis>maxdis)break;
			ans[++tot]=e[x][d].id;
			ans1+=e[x][d].l;
			int tmp=(e[x][d].dy+180)%360;
			x=e[x][d].y;
			d=getdir(x,tmp);
			if(d==-1 || (d+180)%360==tmp)break;
			if(cp[x])break;
		}
		sd=(sd+180)%360;
		ans2+=2*min(maxdis,dis);
	}
}
void work1(){
	int i,j,x=s,d=sd,k,l,y;
	for(;;){
		if(cp[x]){
			bo[x][(d+180)%360]=1;
			int res=x;
			work2(x,d);
			memset(bo[res],0,sizeof(bo[res]));
		//	continue;
		}else{
			d=getdir(x,d);
			ans[++tot]=e[x][d].id;
			ans1+=e[x][d].l;
			ans2+=e[x][d].l;
			int tmp=(e[x][d].dy+180)%360;
			x=e[x][d].y;
			d=tmp;
		}
		if(x==t)break;
	}
}
int main(){
for(int o=1;o<=20;++o){
	char ct[20];
	sprintf(ct,"hounds%d.in",o);
	freopen(ct,"r",stdin);
	sprintf(ct,"hounds%d.out",o);
	freopen(ct,"w",stdout);
		//clear
		ans1=ans2=0;
		tot=0;
		memset(cp,0,sizeof(cp));
		memset(e,0,sizeof(e));
		memset(etmp,0,sizeof(etmp));
		memset(mark,3,sizeof(mark));
		//
		scanf("%d%d%d%d%d%d%d",&ncp,&nroad,&ncm,&maxdis,&s,&t,&sd);
		tim++;
	//	printf("Case %d:\n",tim);
		for(i=1;i<=ncp;++i){
			scanf("%d",&x);
			cp[x]=1;
		}
	//	if(cp[t])puts("*");
		for(i=1;i<=nroad;++i){
			scanf("%d%d%d%d%d",&x,&y,&dx,&dy,&l);
			e[x][dx].mk(y,dy,l,i);
			e[y][dy].mk(x,dx,l,i);
			etmp[x][i].mk(y,dx,0,0);
			etmp[y][i].mk(x,dy,0,0);
		}
		for(i=1;i<=ncm;++i){
			scanf("%d%d%d",&x,&id,&k);
			y=etmp[x][id].y;
			dx=etmp[x][id].dy;  dy=etmp[y][id].dy;
			mark[x][dx]=min(mark[x][dx],k);
			mark[y][dy]=min(mark[y][dy],e[y][dy].l-k);
		}
		work1();
		printf("Length of hare's route is %d\n",ans1);
		printf("Length of hound's search is %d\n",ans2);
		printf("Route:");
		for(i=1;i<=tot;++i)printf(" %d",ans[i]);
		puts("\n");
}
}


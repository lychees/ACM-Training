#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define rep(i,n) for (int i=0;i<n;++i)
int R(int x){return rand()%x;}
int main()
{
	freopen("C.in","w",stdout); srand(time(0));
	int T=1000;
	while (T--){
		int n=R(10)+1; printf("%d\n",n);
		rep(i,n) printf("%d %d %c\n",R(12),R(12),R(2)?'D':'A');
		rep(i,n+1){
			int L=R(11)+1;
			rep(i,L) printf("%c",R(26)+65);
			puts("");
		}
	}
	puts("0");
	return 0;
}

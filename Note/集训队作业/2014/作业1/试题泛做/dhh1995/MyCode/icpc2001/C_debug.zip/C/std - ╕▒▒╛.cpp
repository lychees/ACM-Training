#include <ctime>
#include <cstdio>
#include <cstring>

#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;

namespace CrosswordPuzzle
{
	const int N = 150, R = 13, T = 200000;

	bool massert (bool stmt)
	{
		if (! stmt)
			throw;
	}

	int n_slot;
	struct slot {
		int x, y, down;
		bool operator< (const slot &b) const { return x == b.x ? y == b.y ? down < b.down : y < b.y : x < b.x; } 
		bool operator== (const slot &b) const { return x == b.x && y == b.y && down == b.down; }
	} slots[N];
	string _words[N];
	const char *words[N];
	int len[N], counter;
	
	struct node { bool fl; int cnt; node *f, *n[26]; } buff[T], *root = buff, *ncur = buff + 1;
	inline node* new_node () {
//		massert(!(ncur - buff > T / 2));
		return ncur++;
	}
	void expand (node *c, const char *s)
	{
		++c->cnt;
		if (!*s) { c->fl = true; return; }
		int p = *s - 'A';
		if (!(p >= 0 && p < 26))
			while (1);
		expand(c->n[p] ? c->n[p] : (c->n[p] = new_node()), s + 1);
	}

	vector<string> answer;
	char board[R][R];
	int slotType[R][R], slotID[R][R], plan[N]; // -1 : null; 0 : across; 1 : down
	
	const int dx[2] = {0, 1}, dy[2] = {1, 0};

	inline bool test (int x, int y, int id, bool down)
	{
		int len = CrosswordPuzzle::len[id], dx = down, dy = !down;

		if (x < 1 || y < 1
				|| x + dx * (len - 1) > 10 || y + dy * (len - 1) > 10)
			return false;

//		massert(! board[x - dx][y - dy]); // the other case should have been eliminated.
		if (board[x + dx * len][y + dy * len])
			return false;

		for (int j = 1, cx = x + dx, cy = y + dy; j <= len; ++j, cx += dx, cy += dy)
			if (slotType[cx][cy] == down || slotType[cx][cy] == 2)
				return false;
				
		for (int j = 0; j < len; ++j, x += dx, y += dy)
			if (board[x][y] && board[x][y] != words[id][j])
				return false;
		
		return true;
	}
	inline void insertWord (int x, int y, int id, int down, char bak[])
	{
		node *t = root;
		for (int j = 0; j < len[id]; ++j)
		{
			t->cnt --;
//			massert(t->cnt >= 0);
			t = t->n[words[id][j] - 'A'];
		}
		for (int j = 0, dx = down, dy = !down; j < len[id]; ++j, x += dx, y += dy)
		{
			bak[j] = board[x][y];
			board[x][y] = words[id][j];
		}
	}
	inline void removeWord (int x, int y, int id, int down, char bak[])
	{
		node *t = root;
		for (int j = 0; j < len[id]; ++j)
		{
			t->cnt ++;
			t = t->n[words[id][j] - 'A'];
		}
		for (int j = 0, dx = down, dy = !down; j < len[id]; ++j, x += dx, y += dy)
		{
			board[x][y] = bak[j];
		}
	}
	inline bool checkSlots (int s)
	{
		for (int i = 1; i + 1 < s; ++i)
		{
			int tx = slots[i].x + len[plan[i]] * slots[i].down,
				ty = slots[i].y + len[plan[i]] *!slots[i].down;
			if (board[tx][ty])
				return false;
		}
		for (int i = s; i <= n_slot; ++i)
		{
			int x = slots[i].x, y = slots[i].y, d = slots[i].down;
			node *tmp = root;
			int px = x - d, py = y - !d;
			if (px > 0 && py > 0 && board[px][py])
				return false;
			for (; board[x][y]; x += d, y += !d)
			{
				tmp = tmp->n[board[x][y] - 'A'];
				if (!tmp || tmp->cnt == 0)
					break;
			}
			if (! tmp || tmp->cnt == 0)
				return false;
		}
		return true;
	}

	int invalid[N];
	bool search (int cnt)
	{
#ifdef DDDEBUG
		puts("-header-");
		for (int i = 1; i <= 10; ++i)
		{
			for (int j = 1; j <= 10; ++j)
				if (board[i][j])
					cout << board[i][j];
				else
					cout << ' ';
			cout << endl;
		}
		cout << endl;
#endif


		++counter;
		if (cnt == n_slot + 1)
			return true;
		
		slot &cslot = slots[cnt];

		for (int i = 1; i <= n_slot + 1; ++i)
			if (!invalid[i] && test(cslot.x, cslot.y, i, cslot.down))
			{
				char bak[R];
				insertWord(cslot.x, cslot.y, i, cslot.down, bak);
				invalid[i] = 1;
				plan[cnt] = i;
				if (checkSlots(cnt + 1))
					if (search(cnt + 1))
					{
						removeWord(cslot.x, cslot.y, i, cslot.down, bak);
						return true;
					}

				removeWord(cslot.x, cslot.y, i, cslot.down, bak);
//				massert(invalid[i] == 1);
				invalid[i] = 0;
			}

		return false;
	}

	bool byLength (const string &a, const string &b)
	{
		return a.length() > b.length();
	}

	bool solve ()
	{
		cin >> n_slot;
		if (! n_slot)
			return false;
		
		massert(n_slot < N);

		memset(slotType, -1, sizeof slotType);
		memset(slotID, 0, sizeof slotID);

		for (int i = 1; i <= n_slot; ++i)
		{
			string tmp;
			cin >> slots[i].x >> slots[i].y >> tmp;
			massert(tmp[0] == 'A' || tmp[0] == 'D');
			slots[i].down = (tmp[0] == 'D');
		}

		for (int i = 1; i <= n_slot + 1; ++i)
		{
			cin >> _words[i];
		}

		sort(slots + 1, slots + 1 + n_slot);

		for (int i = 1; i <= n_slot; ++i)
		{
			if (slotType[slots[i].x][slots[i].y] >= 0)
				slotType[slots[i].x][slots[i].y] = 2;
			else
				slotType[slots[i].x][slots[i].y] = slots[i].down;
			slotID[slots[i].x][slots[i].y] = i;
		}

		sort(_words + 1, _words + 1 + (n_slot + 1), byLength);

		root = new_node();
		for (int i = 1; i <= n_slot + 1; ++i)
		{
			words[i] = _words[i].c_str();
			len[i] = _words[i].length();
			expand(root, words[i]);
		}

		answer.clear();
		for (int i = 1; i <= n_slot + 1; ++i)
		{
			memset(board, 0, sizeof board);
			memset(invalid, 0, sizeof invalid);
			invalid[i] = 1;
			if (search(1))
				answer.push_back(_words[i]);
		}

		static int cases = 0;
		cout << "Trial " << ++cases << ":";
		
		if (answer.empty())
		{
			cout << " Impossible";
			goto end;
		}

		sort(answer.begin(), answer.end());
//		random_shuffle(answer.begin(), answer.end());
		for (size_t i = 0; i < answer.size(); ++i)
			cout << ' ' << answer[i];

end:
		cout << endl << endl;
//		cout << counter << endl;
		return true;
	}
}

int main ()
{
//#ifdef LOCAL
//	freopen("C.in", "r", stdin);
//	freopen("std.out", "w", stdout);
//#endif
//	srand(time(0));
	while (CrosswordPuzzle::solve()) ;
	return 0;
}
